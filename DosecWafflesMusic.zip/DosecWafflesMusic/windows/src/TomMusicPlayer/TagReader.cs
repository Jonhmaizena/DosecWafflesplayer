using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32.SafeHandles;

namespace TomMusic;

/// <summary>Tudo o que foi lido de um arquivo: tags, letra, capa e formato do áudio.</summary>
public sealed class FileTags
{
    public List<KeyValuePair<string, string>> Fields { get; } = new();
    public string Vendor { get; set; } = "";
    public Lyrics? Lyrics { get; set; }
    public bool HasPicture { get; set; }
    public byte[]? Picture { get; set; }
    public string PictureMime { get; set; } = "";
    public int PictureType { get; set; } = -1;

    public string Codec { get; set; } = "";
    public int SampleRate { get; set; }
    public int Bits { get; set; }
    public int Channels { get; set; }
    public long DurationMs { get; set; }
    public int BitrateKbps { get; set; }

    public string Get(params string[] keys)
    {
        foreach (var k in keys)
            foreach (var f in Fields)
                if (f.Key == k && !string.IsNullOrWhiteSpace(f.Value)) return f.Value.Trim();
        return "";
    }
}

/// <summary>
/// Leitor de tags feito à mão (sem bibliotecas), para FLAC, OGG Vorbis/Opus, MP3 (ID3v2/ID3v1),
/// M4A/ALAC/AAC (MP4), WAV e AIFF. Lê só o começo (e às vezes o fim) do arquivo.
/// </summary>
public static class TagReader
{
    static readonly Encoding Utf8 = new UTF8Encoding(false);
    static readonly Encoding Latin1 = Encoding.Latin1;

    static readonly HashSet<string> LyricKeys = new()
    {
        "LYRICS", "UNSYNCEDLYRICS", "UNSYNCED LYRICS", "SYNCEDLYRICS", "LYRIC", "©LYR", "TXXX:LYRICS", "TXXX:USLT",
    };

    sealed class Ctx
    {
        public readonly FileTags T = new();
        public readonly bool WantPicture;
        public List<LyricLine>? Synced;
        public string? Plain;
        public Ctx(bool wantPicture) { WantPicture = wantPicture; }

        public void Field(string key, string value)
        {
            var k = key.ToUpperInvariant();
            if (k is "METADATA_BLOCK_PICTURE" or "COVERART") { VorbisPicture(this, k, value); return; }
            T.Fields.Add(new(k, value));
            if (LyricKeys.Contains(k)) LyricsCandidate(value);
        }

        public void LyricsCandidate(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            var parsed = Lrc.Parse(text);
            if (parsed != null) Synced ??= parsed;
            else Plain ??= text.Trim();
        }

        public void SyncedLines(List<LyricLine> lines)
        {
            if (Synced == null && lines.Count > 0) Synced = lines;
        }

        /// <summary>Guarda a capa: a frontal (tipo 3) tem preferência.</summary>
        public void Picture(int type, string mime, Func<byte[]> data)
        {
            T.HasPicture = true;
            if (!WantPicture) return;
            bool better = T.Picture == null || (type == 3 && T.PictureType != 3);
            if (!better) return;
            try
            {
                var d = data();
                if (d.Length < 16) return;
                T.Picture = d;
                T.PictureType = type;
                T.PictureMime = SniffMime(d, mime);
            }
            catch { }
        }
    }

    public static FileTags Read(string path, bool wantPicture = false)
    {
        var c = new Ctx(wantPicture);
        try
        {
            using var h = File.OpenHandle(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            long size = RandomAccess.GetLength(h);
            var head = ReadAt(h, 0, 12);
            if (head.Length >= 12)
            {
                var tag = Latin1.GetString(head, 0, 4);
                if (tag == "fLaC") ParseFlac(h, 4, c);
                else if (tag.StartsWith("ID3"))
                {
                    long end = ParseId3(h, 0, c);
                    if (end + 4 <= size && Latin1.GetString(ReadAt(h, end, 4)) == "fLaC") ParseFlac(h, end + 4, c);
                    else ParseMp3(h, end, size, c);
                }
                else if (tag == "OggS") ParseOgg(h, size, c);
                else if (Latin1.GetString(head, 4, 4) == "ftyp") ParseMp4(h, size, c);
                else if (tag == "RIFF" && Latin1.GetString(head, 8, 4) == "WAVE") ParseRiff(h, size, c);
                else if (tag == "FORM") ParseAiff(h, size, c);
                else if (head[0] == 0xFF && (head[1] & 0xE0) == 0xE0) ParseMp3(h, 0, size, c);
            }
            if (size > 128)
            {
                var v1 = ReadAt(h, size - 128, 128);
                if (v1.Length == 128 && Latin1.GetString(v1, 0, 3) == "TAG")
                {
                    string S(int o, int n) => Latin1.GetString(v1, o, n).Trim('\0', ' ');
                    if (c.T.Get("TITLE") == "" && S(3, 30) != "") c.Field("TITLE", S(3, 30));
                    if (c.T.Get("ARTIST") == "" && S(33, 30) != "") c.Field("ARTIST", S(33, 30));
                    if (c.T.Get("ALBUM") == "" && S(63, 30) != "") c.Field("ALBUM", S(63, 30));
                    if (c.T.Get("DATE") == "" && S(93, 4) != "") c.Field("DATE", S(93, 4));
                    var comment = S(97, 30);
                    if (comment != "") c.Field("COMMENT", comment);
                }
            }
            if (c.T.BitrateKbps == 0 && c.T.DurationMs > 0)
                c.T.BitrateKbps = (int)(size * 8 / c.T.DurationMs);
        }
        catch { }

        // Letra em arquivo .lrc ao lado da música
        if (c.Synced == null)
        {
            try
            {
                var lrc = System.IO.Path.ChangeExtension(path, ".lrc");
                if (File.Exists(lrc))
                {
                    var text = File.ReadAllText(lrc);
                    var parsed = Lrc.Parse(text);
                    if (parsed != null) c.Synced = parsed;
                    else c.Plain ??= text.Trim();
                }
            }
            catch { }
        }

        if (c.Synced != null) c.T.Lyrics = new Lyrics { Synced = true, Lines = c.Synced };
        else if (c.Plain != null) c.T.Lyrics = new Lyrics { Synced = false, Text = c.Plain };
        return c.T;
    }

    // ---- utilidades -----------------------------------------------------------------------

    static byte[] ReadAt(SafeFileHandle h, long pos, int len)
    {
        if (len <= 0 || pos < 0) return Array.Empty<byte>();
        var buf = new byte[len];
        int total = 0;
        while (total < len)
        {
            int n = RandomAccess.Read(h, buf.AsSpan(total), pos + total);
            if (n <= 0) break;
            total += n;
        }
        return total == len ? buf : buf[..total];
    }

    static uint U32Le(byte[] b, int o) => (uint)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24));
    static uint U32Be(byte[] b, int o) => (uint)((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]);
    static int U16Be(byte[] b, int o) => (b[o] << 8) | b[o + 1];
    static int U16Le(byte[] b, int o) => b[o] | (b[o + 1] << 8);
    static int Syncsafe(byte[] b, int o) => ((b[o] & 0x7F) << 21) | ((b[o + 1] & 0x7F) << 14) | ((b[o + 2] & 0x7F) << 7) | (b[o + 3] & 0x7F);

    static string SniffMime(byte[] d, string fallback)
    {
        if (d.Length > 3 && d[0] == 0xFF && d[1] == 0xD8) return "image/jpeg";
        if (d.Length > 8 && d[0] == 0x89 && d[1] == 0x50) return "image/png";
        if (d.Length > 12 && d[0] == 'R' && d[8] == 'W') return "image/webp";
        if (d.Length > 3 && d[0] == 'G' && d[1] == 'I') return "image/gif";
        if (d.Length > 2 && d[0] == 'B' && d[1] == 'M') return "image/bmp";
        return string.IsNullOrEmpty(fallback) ? "image/jpeg" : fallback;
    }

    // ---- FLAC ------------------------------------------------------------------------------

    static void ParseFlac(SafeFileHandle h, long start, Ctx c)
    {
        long pos = start;
        for (int i = 0; i < 128; i++)
        {
            var hd = ReadAt(h, pos, 4);
            if (hd.Length < 4) return;
            bool last = (hd[0] & 0x80) != 0;
            int type = hd[0] & 0x7F;
            int len = (hd[1] << 16) | (hd[2] << 8) | hd[3];
            long body = pos + 4;
            if (type == 0 && len >= 18) StreamInfo(ReadAt(h, body, len), 0, c);
            else if (type == 4 && len > 0 && len < (16 << 20)) VorbisComment(ReadAt(h, body, len), 0, c);
            else if (type == 6 && len > 32)
            {
                c.T.HasPicture = true;
                if (c.WantPicture) FlacPicture(ReadAt(h, body, len), c);
            }
            pos = body + len;
            if (last) return;
        }
    }

    static void StreamInfo(byte[] b, int o, Ctx c)
    {
        if (b.Length < o + 18) return;
        int rate = (b[o + 10] << 12) | (b[o + 11] << 4) | (b[o + 12] >> 4);
        int ch = ((b[o + 12] >> 1) & 0x7) + 1;
        int bps = (((b[o + 12] & 1) << 4) | (b[o + 13] >> 4)) + 1;
        long total = ((long)(b[o + 13] & 0x0F) << 32) | ((long)b[o + 14] << 24) | ((long)b[o + 15] << 16) | ((long)b[o + 16] << 8) | b[o + 17];
        c.T.Codec = c.T.Codec == "" ? "FLAC" : c.T.Codec;
        c.T.SampleRate = rate;
        c.T.Channels = ch;
        c.T.Bits = bps;
        if (rate > 0 && total > 0) c.T.DurationMs = total * 1000 / rate;
    }

    /// <summary>Estrutura de imagem do FLAC (também usada em METADATA_BLOCK_PICTURE).</summary>
    static void FlacPicture(byte[] b, Ctx c)
    {
        if (b.Length < 32) return;
        int o = 0;
        int type = (int)U32Be(b, o); o += 4;
        int mimeLen = (int)U32Be(b, o); o += 4;
        if (mimeLen < 0 || o + mimeLen > b.Length) return;
        var mime = Latin1.GetString(b, o, mimeLen); o += mimeLen;
        int descLen = (int)U32Be(b, o); o += 4;
        if (descLen < 0 || o + descLen + 20 > b.Length) return;
        o += descLen + 16;
        int dataLen = (int)U32Be(b, o); o += 4;
        if (dataLen <= 0 || o + dataLen > b.Length) return;
        int start = o;
        c.Picture(type, mime, () => b.AsSpan(start, dataLen).ToArray());
    }

    static void VorbisPicture(Ctx c, string key, string value)
    {
        c.T.HasPicture = true;
        if (!c.WantPicture) return;
        try
        {
            var raw = Convert.FromBase64String(value.Trim());
            if (key == "COVERART") c.Picture(3, "", () => raw);
            else FlacPicture(raw, c);
        }
        catch { }
    }

    /// <summary>Bloco de comentários Vorbis (FLAC, OGG Vorbis, Opus).</summary>
    static void VorbisComment(byte[] b, int start, Ctx c)
    {
        int o = start;
        if (o + 4 > b.Length) return;
        int vendorLen = (int)U32Le(b, o); o += 4;
        if (vendorLen < 0 || o + vendorLen > b.Length) return;
        c.T.Vendor = Utf8.GetString(b, o, vendorLen); o += vendorLen;
        if (o + 4 > b.Length) return;
        int count = (int)U32Le(b, o); o += 4;
        for (int i = 0; i < Math.Min(count, 8192); i++)
        {
            if (o + 4 > b.Length) return;
            int len = (int)U32Le(b, o); o += 4;
            if (len < 0 || o + len > b.Length) return;
            var entry = Utf8.GetString(b, o, len); o += len;
            int eq = entry.IndexOf('=');
            if (eq > 0) c.Field(entry[..eq], entry[(eq + 1)..]);
        }
    }

    // ---- OGG Vorbis / Opus -------------------------------------------------------------------

    /// <summary>Junta os primeiros pacotes lógicos (cabeçalhos) a partir das páginas OGG.</summary>
    static List<byte[]> OggHeaderPackets(SafeFileHandle h, long size, int wanted)
    {
        var packets = new List<byte[]>();
        var current = new MemoryStream();
        long pos = 0;
        int pages = 0;
        while (pos + 27 <= size && packets.Count < wanted && pages++ < 4096 && current.Length < (24 << 20))
        {
            var hd = ReadAt(h, pos, 27);
            if (hd.Length < 27 || Latin1.GetString(hd, 0, 4) != "OggS") break;
            int nseg = hd[26];
            var segs = ReadAt(h, pos + 27, nseg);
            if (segs.Length < nseg) break;
            int dataLen = 0;
            foreach (var s in segs) dataLen += s;
            var data = ReadAt(h, pos + 27 + nseg, dataLen);
            int o = 0;
            for (int i = 0; i < nseg && o <= data.Length; i++)
            {
                int n = Math.Min(segs[i], data.Length - o);
                current.Write(data, o, n);
                o += n;
                if (segs[i] < 255)
                {
                    packets.Add(current.ToArray());
                    current = new MemoryStream();
                    if (packets.Count >= wanted) break;
                }
            }
            pos += 27 + nseg + dataLen;
        }
        return packets;
    }

    static void ParseOgg(SafeFileHandle h, long size, Ctx c)
    {
        var pk = OggHeaderPackets(h, size, 2);
        if (pk.Count == 0) return;
        var id = pk[0];
        int preSkip = 0;
        bool opus = false;
        if (id.Length >= 30 && id[0] == 1 && Latin1.GetString(id, 1, 6) == "vorbis")
        {
            c.T.Codec = "Vorbis";
            c.T.Channels = id[11];
            c.T.SampleRate = (int)U32Le(id, 12);
            int nominal = (int)U32Le(id, 20);
            if (nominal > 0) c.T.BitrateKbps = nominal / 1000;
        }
        else if (id.Length >= 19 && Latin1.GetString(id, 0, 8) == "OpusHead")
        {
            opus = true;
            c.T.Codec = "Opus";
            c.T.Channels = id[9];
            preSkip = U16Le(id, 10);
            c.T.SampleRate = 48000;
        }
        if (pk.Count > 1)
        {
            var cm = pk[1];
            if (cm.Length > 7 && cm[0] == 3 && Latin1.GetString(cm, 1, 6) == "vorbis") VorbisComment(cm, 7, c);
            else if (cm.Length > 8 && Latin1.GetString(cm, 0, 8) == "OpusTags") VorbisComment(cm, 8, c);
        }
        // Duração: posição (granule) da última página
        int tailLen = (int)Math.Min(size, 128 * 1024);
        var tail = ReadAt(h, size - tailLen, tailLen);
        for (int i = tail.Length - 27; i >= 0; i--)
        {
            if (tail[i] == 'O' && tail[i + 1] == 'g' && tail[i + 2] == 'g' && tail[i + 3] == 'S')
            {
                long granule = BitConverter.ToInt64(tail, i + 6);
                if (granule > 0 && c.T.SampleRate > 0)
                    c.T.DurationMs = (opus ? granule - preSkip : granule) * 1000 / (opus ? 48000 : c.T.SampleRate);
                break;
            }
        }
    }

    // ---- ID3v2 -------------------------------------------------------------------------------

    static long ParseId3(SafeFileHandle h, long start, Ctx c)
    {
        var hd = ReadAt(h, start, 10);
        if (hd.Length < 10 || Latin1.GetString(hd, 0, 3) != "ID3") return start;
        int size = Syncsafe(hd, 6);
        var body = ReadAt(h, start + 10, Math.Min(size, 64 << 20));
        Id3Body(body, hd[3], hd[5], c);
        return start + 10 + size + ((hd[5] & 0x10) != 0 ? 10 : 0);
    }

    static void Id3Bytes(byte[] b, Ctx c)
    {
        if (b.Length < 10 || Latin1.GetString(b, 0, 3) != "ID3") return;
        int size = Math.Min(Syncsafe(b, 6), b.Length - 10);
        Id3Body(b.AsSpan(10, size).ToArray(), b[3], b[5], c);
    }

    static void Id3Body(byte[] b, int version, int flags, Ctx c)
    {
        if (version < 2) return;
        if ((flags & 0x80) != 0 && version < 4) b = Unsync(b);
        int o = 0;
        if (version == 2)
        {
            // ID3v2.2: identificadores de 3 letras
            while (o + 6 <= b.Length)
            {
                var id3 = Latin1.GetString(b, o, 3);
                if (id3[0] == '\0') break;
                int len = (b[o + 3] << 16) | (b[o + 4] << 8) | b[o + 5];
                o += 6;
                if (len <= 0 || o + len > b.Length) break;
                var f = b.AsSpan(o, len).ToArray();
                o += len;
                var mapped = V22.TryGetValue(id3, out var v4) ? v4 : null;
                try
                {
                    if (id3 == "PIC" && f.Length > 6)
                    {
                        int enc = f[0];
                        int type = f[4];
                        var (_, next) = ReadString(f, 5, enc);
                        int s = next;
                        c.Picture(type, "", () => f.AsSpan(s).ToArray());
                    }
                    else if (mapped != null) Id3Frame(mapped, f, c);
                }
                catch { }
            }
            return;
        }
        if ((flags & 0x40) != 0 && b.Length >= 4)
            o = version == 4 ? Syncsafe(b, 0) : (int)U32Be(b, 0) + 4;
        while (o + 10 <= b.Length)
        {
            var id = Latin1.GetString(b, o, 4);
            if (id[0] == '\0') break;
            int len = version == 4 ? Syncsafe(b, o + 4) : (int)U32Be(b, o + 4);
            int fflags = U16Be(b, o + 8);
            o += 10;
            if (len <= 0 || o + len > b.Length) break;
            var f = b.AsSpan(o, len).ToArray();
            o += len;
            if (version == 4)
            {
                if ((fflags & 0x0001) != 0 && f.Length > 4) f = f[4..];      // indicador de tamanho
                if ((fflags & 0x0002) != 0) f = Unsync(f);
            }
            try { Id3Frame(id, f, c); } catch { }
        }
    }

    static byte[] Unsync(byte[] b)
    {
        var o = new List<byte>(b.Length);
        for (int i = 0; i < b.Length; i++)
        {
            o.Add(b[i]);
            if (b[i] == 0xFF && i + 1 < b.Length && b[i + 1] == 0) i++;
        }
        return o.ToArray();
    }

    static readonly Dictionary<string, string> V22 = new()
    {
        ["TT2"] = "TIT2", ["TP1"] = "TPE1", ["TP2"] = "TPE2", ["TAL"] = "TALB", ["TRK"] = "TRCK", ["TPA"] = "TPOS",
        ["TYE"] = "TYER", ["TCO"] = "TCON", ["TCM"] = "TCOM", ["TEN"] = "TENC", ["TSS"] = "TSSE", ["COM"] = "COMM",
        ["ULT"] = "USLT", ["TXX"] = "TXXX", ["TPB"] = "TPUB", ["TCR"] = "TCOP",
    };

    static readonly Dictionary<string, string> Id3Names = new()
    {
        ["TSSE"] = "ENCODER", ["TENC"] = "ENCODED-BY", ["TPUB"] = "PUBLISHER", ["TCOP"] = "COPYRIGHT",
        ["TMED"] = "MEDIA", ["TIT2"] = "TITLE", ["TPE1"] = "ARTIST", ["TALB"] = "ALBUM", ["TOWN"] = "OWNER",
        ["TPE2"] = "ALBUMARTIST", ["TRCK"] = "TRACKNUMBER", ["TPOS"] = "DISCNUMBER", ["TYER"] = "DATE",
        ["TDRC"] = "DATE", ["TCON"] = "GENRE", ["TCOM"] = "COMPOSER",
    };

    static void Id3Frame(string id, byte[] f, Ctx c)
    {
        if (f.Length == 0) return;
        if (id == "TXXX")
        {
            int enc = f[0];
            var (desc, next) = ReadString(f, 1, enc);
            var value = Decode(f, next, f.Length, enc);
            c.Field("TXXX:" + desc.ToUpperInvariant(), value);
            if (desc.Contains("lyric", StringComparison.OrdinalIgnoreCase)) c.LyricsCandidate(value);
        }
        else if (id[0] == 'T')
        {
            var value = Decode(f, 1, f.Length, f[0]).Replace('\0', '/');
            if (id == "TCON") value = Genre(value);
            c.Field(Id3Names.TryGetValue(id, out var n) ? n : id, value);
        }
        else if (id == "COMM" && f.Length > 4)
        {
            int enc = f[0];
            var (_, next) = ReadString(f, 4, enc);
            c.Field("COMMENT", Decode(f, next, f.Length, enc));
        }
        else if (id == "USLT" && f.Length > 4)
        {
            int enc = f[0];
            var (_, next) = ReadString(f, 4, enc);
            c.LyricsCandidate(Decode(f, next, f.Length, enc));
        }
        else if (id == "SYLT" && f.Length > 6)
        {
            int enc = f[0];
            int tsFormat = f[4];
            var (_, o) = ReadString(f, 6, enc);
            if (tsFormat != 2) return;
            var lines = new List<LyricLine>();
            while (o < f.Length)
            {
                var (text, next) = ReadString(f, o, enc);
                if (next + 4 > f.Length) break;
                lines.Add(new LyricLine(U32Be(f, next), text.Trim('\n', '\r', ' ')));
                o = next + 4;
            }
            c.SyncedLines(lines.Where(l => l.Text.Length > 0).OrderBy(l => l.TimeMs).ToList());
        }
        else if (id == "APIC" && f.Length > 4)
        {
            int enc = f[0];
            int i = 1;
            while (i < f.Length && f[i] != 0) i++;
            var mime = Latin1.GetString(f, 1, i - 1);
            int type = i + 1 < f.Length ? f[i + 1] : 0;
            var (_, next) = ReadString(f, i + 2, enc);
            int s = next;
            if (s < f.Length) c.Picture(type, mime, () => f.AsSpan(s).ToArray());
        }
        else if (id == "WXXX")
        {
            int enc = f[0];
            var (_, next) = ReadString(f, 1, enc);
            c.Field("URL", Latin1.GetString(f, next, f.Length - next).Trim('\0'));
        }
        else if (id[0] == 'W') c.Field("URL", Latin1.GetString(f).Trim('\0'));
        else if (id == "PRIV")
        {
            int end = Array.IndexOf(f, (byte)0);
            if (end > 0) c.Field("PRIV", Latin1.GetString(f, 0, end));
        }
    }

    static readonly string[] Genres =
    {
        "Blues","Classic Rock","Country","Dance","Disco","Funk","Grunge","Hip-Hop","Jazz","Metal","New Age","Oldies","Other",
        "Pop","R&B","Rap","Reggae","Rock","Techno","Industrial","Alternative","Ska","Death Metal","Pranks","Soundtrack",
        "Euro-Techno","Ambient","Trip-Hop","Vocal","Jazz+Funk","Fusion","Trance","Classical","Instrumental","Acid","House",
        "Game","Sound Clip","Gospel","Noise","AlternRock","Bass","Soul","Punk","Space","Meditative","Instrumental Pop",
        "Instrumental Rock","Ethnic","Gothic","Darkwave","Techno-Industrial","Electronic","Pop-Folk","Eurodance","Dream",
        "Southern Rock","Comedy","Cult","Gangsta","Top 40","Christian Rap","Pop/Funk","Jungle","Native American","Cabaret",
        "New Wave","Psychadelic","Rave","Showtunes","Trailer","Lo-Fi","Tribal","Acid Punk","Acid Jazz","Polka","Retro",
        "Musical","Rock & Roll","Hard Rock",
    };

    static string Genre(string v)
    {
        var m = Regex.Match(v.Trim(), @"^\((\d+)\)(.*)$");
        if (m.Success)
        {
            if (m.Groups[2].Value.Trim().Length > 0) return m.Groups[2].Value.Trim();
            int n = int.Parse(m.Groups[1].Value);
            return n < Genres.Length ? Genres[n] : v;
        }
        if (int.TryParse(v.Trim(), out var k) && k >= 0 && k < Genres.Length) return Genres[k];
        return v;
    }

    static Encoding Charset(int enc) => enc switch
    {
        1 => Encoding.Unicode,      // UTF-16 com BOM (o decodificador respeita o BOM abaixo)
        2 => Encoding.BigEndianUnicode,
        3 => Utf8,
        _ => Latin1,
    };

    static string DecodeWide(byte[] b, int start, int len, int enc)
    {
        if (len <= 0) return "";
        if (enc == 1 && len >= 2)
        {
            if (b[start] == 0xFE && b[start + 1] == 0xFF) return Encoding.BigEndianUnicode.GetString(b, start + 2, len - 2);
            if (b[start] == 0xFF && b[start + 1] == 0xFE) return Encoding.Unicode.GetString(b, start + 2, len - 2);
        }
        return Charset(enc).GetString(b, start, len);
    }

    static (string, int) ReadString(byte[] b, int start, int enc)
    {
        bool wide = enc == 1 || enc == 2;
        int i = start;
        if (wide)
        {
            while (i + 1 < b.Length && !(b[i] == 0 && b[i + 1] == 0)) i += 2;
            return (DecodeWide(b, start, Math.Max(0, i - start), enc), Math.Min(i + 2, b.Length));
        }
        while (i < b.Length && b[i] != 0) i++;
        return (Charset(enc).GetString(b, start, i - start), Math.Min(i + 1, b.Length));
    }

    static string Decode(byte[] b, int start, int end, int enc) =>
        start >= end ? "" : DecodeWide(b, start, end - start, enc).TrimEnd('\0');

    // ---- MP3 (formato e duração) -------------------------------------------------------------

    static readonly int[] BrV1 = { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320 };
    static readonly int[] BrV2 = { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160 };

    static void ParseMp3(SafeFileHandle h, long start, long size, Ctx c)
    {
        var b = ReadAt(h, start, (int)Math.Min(256 * 1024, Math.Max(0, size - start)));
        for (int i = 0; i + 4 < b.Length; i++)
        {
            if (b[i] != 0xFF || (b[i + 1] & 0xE0) != 0xE0) continue;
            int ver = (b[i + 1] >> 3) & 3;     // 3 = MPEG1, 2 = MPEG2, 0 = MPEG2.5
            int layer = (b[i + 1] >> 1) & 3;   // 1 = Layer III
            int bri = b[i + 2] >> 4;
            int sri = (b[i + 2] >> 2) & 3;
            if (ver == 1 || layer != 1 || bri == 0 || bri == 15 || sri == 3) continue;
            int[] rates = { 44100, 48000, 32000 };
            int rate = rates[sri] / (ver == 3 ? 1 : ver == 2 ? 2 : 4);
            int kbps = (ver == 3 ? BrV1 : BrV2)[bri];
            bool mono = (b[i + 3] >> 6) == 3;
            int spf = ver == 3 ? 1152 : 576;
            // Confere o quadro seguinte para não cair num falso sincronismo
            int pad = (b[i + 2] >> 1) & 1;
            int frameLen = (ver == 3 ? 144 : 72) * kbps * 1000 / rate + pad;
            if (i + frameLen + 2 < b.Length && !(b[i + frameLen] == 0xFF && (b[i + frameLen + 1] & 0xE0) == 0xE0)) continue;

            c.T.Codec = "MP3";
            c.T.SampleRate = rate;
            c.T.Channels = mono ? 1 : 2;
            int side = ver == 3 ? (mono ? 17 : 32) : (mono ? 9 : 17);
            int xo = i + 4 + side;
            long frames = 0;
            if (xo + 12 < b.Length)
            {
                var tag = Latin1.GetString(b, xo, 4);
                if ((tag == "Xing" || tag == "Info") && (U32Be(b, xo + 4) & 1) != 0) frames = U32Be(b, xo + 8);
            }
            int vo = i + 4 + 32;
            if (frames == 0 && vo + 18 < b.Length && Latin1.GetString(b, vo, 4) == "VBRI") frames = U32Be(b, vo + 14);
            long audioBytes = size - start - i - 128;
            if (frames > 0)
            {
                c.T.DurationMs = frames * spf * 1000 / rate;
                if (c.T.DurationMs > 0) c.T.BitrateKbps = (int)(audioBytes * 8 / c.T.DurationMs);
            }
            else
            {
                c.T.BitrateKbps = kbps;
                c.T.DurationMs = audioBytes * 8 / kbps;
            }
            return;
        }
    }

    // ---- MP4 / M4A ---------------------------------------------------------------------------

    static void ParseMp4(SafeFileHandle h, long size, Ctx c)
    {
        long pos = 0;
        while (pos + 8 <= size)
        {
            var hd = ReadAt(h, pos, 16);
            if (hd.Length < 8) return;
            long boxSize = U32Be(hd, 0);
            var type = Latin1.GetString(hd, 4, 4);
            int header = 8;
            if (boxSize == 1 && hd.Length >= 16) { boxSize = ((long)U32Be(hd, 8) << 32) | U32Be(hd, 12); header = 16; }
            else if (boxSize == 0) boxSize = size - pos;
            if (boxSize < header) return;
            if (type == "moov")
            {
                if (boxSize > (96 << 20)) return;
                var moov = ReadAt(h, pos + header, (int)(boxSize - header));
                Mp4Walk(moov, 0, moov.Length, "moov", c);
                return;
            }
            pos += boxSize;
        }
    }

    static void Mp4Walk(byte[] b, int start, int end, string parent, Ctx c)
    {
        int o = start;
        while (o + 8 <= end)
        {
            int size = (int)U32Be(b, o);
            if (size < 8 || o + size > end) return;
            var type = Latin1.GetString(b, o + 4, 4);
            switch (type)
            {
                case "trak": case "mdia": case "minf": case "stbl": case "udta": case "ilst":
                    Mp4Walk(b, o + 8, o + size, type, c);
                    break;
                case "meta":
                    // 'meta' normalmente é um "full box" (4 bytes de versão/flags)
                    Mp4Walk(b, o + (U32Be(b, o + 8) == 0 ? 12 : 8), o + size, type, c);
                    break;
                case "mvhd":
                    if (size >= 32)
                    {
                        int v = b[o + 8];
                        long scale = v == 1 ? U32Be(b, o + 28) : U32Be(b, o + 20);
                        long dur = v == 1 ? ((long)U32Be(b, o + 32) << 32) | U32Be(b, o + 36) : U32Be(b, o + 24);
                        if (scale > 0 && c.T.DurationMs == 0) c.T.DurationMs = dur * 1000 / scale;
                    }
                    break;
                case "stsd":
                    if (c.T.Codec == "" && size > 16 + 36) SampleEntry(b, o + 16, o + size, c);
                    break;
                default:
                    if (parent == "ilst") Mp4Item(type, b, o + 8, o + size, c);
                    break;
            }
            o += size;
        }
    }

    static void SampleEntry(byte[] b, int e, int end, Ctx c)
    {
        int size = (int)U32Be(b, e);
        if (size < 36 || e + size > end) return;
        var fmt = Latin1.GetString(b, e + 4, 4);
        int version = U16Be(b, e + 16);
        c.T.Channels = U16Be(b, e + 24);
        c.T.Bits = U16Be(b, e + 26);
        c.T.SampleRate = (int)(U32Be(b, e + 32) >> 16);
        c.T.Codec = fmt switch
        {
            "mp4a" => "AAC", "alac" => "ALAC", "fLaC" => "FLAC", "Opus" => "Opus", "ac-3" => "AC-3", "ec-3" => "E-AC-3",
            ".mp3" => "MP3", _ => fmt.Trim(),
        };
        int child = e + (version == 1 ? 52 : version == 2 ? 72 : 36);
        while (child + 8 <= e + size)
        {
            int cs = (int)U32Be(b, child);
            if (cs < 8 || child + cs > e + size) break;
            var ct = Latin1.GetString(b, child + 4, 4);
            if (ct == "alac" && cs >= 36)
            {
                int a = child + 12;
                c.T.Bits = b[a + 5];
                c.T.Channels = b[a + 9];
                c.T.SampleRate = (int)U32Be(b, a + 20);
            }
            else if (ct == "dfLa" && cs >= 12 + 4 + 18)
            {
                StreamInfo(b, child + 16, c);
                c.T.Codec = "FLAC";
            }
            child += cs;
        }
        if (c.T.Codec == "AAC") c.T.Bits = 0;
    }

    static void Mp4Item(string type, byte[] b, int start, int end, Ctx c)
    {
        string name = type;
        int o = start;
        while (o + 8 <= end)
        {
            int size = (int)U32Be(b, o);
            if (size < 8 || o + size > end) return;
            var bt = Latin1.GetString(b, o + 4, 4);
            if (bt == "name" && size > 12) name = "----:" + Utf8.GetString(b, o + 12, size - 12);
            else if (bt == "data" && size >= 16)
            {
                int dataType = (int)(U32Be(b, o + 8) & 0xFFFFFF);
                int ds = o + 16, dl = size - 16;
                if (type == "covr")
                {
                    int s = ds, l = dl;
                    c.Picture(3, dataType == 14 ? "image/png" : "image/jpeg", () => b.AsSpan(s, l).ToArray());
                }
                else if (type is "trkn" or "disk" && dl >= 4)
                {
                    c.Field(type == "trkn" ? "TRACKNUMBER" : "DISCNUMBER", U16Be(b, ds + 2).ToString());
                }
                else if (type == "gnre" && dl >= 2)
                {
                    int g = U16Be(b, ds) - 1;
                    if (g >= 0 && g < Genres.Length) c.Field("GENRE", Genres[g]);
                }
                else if (dataType is 1 or 2 or 0)
                {
                    var value = Utf8.GetString(b, ds, dl);
                    var key = type switch
                    {
                        "©lyr" => "LYRICS", "©too" => "ENCODER", "©cmt" => "COMMENT", "©nam" => "TITLE",
                        "cprt" => "COPYRIGHT", "©pub" => "PUBLISHER", "©ART" => "ARTIST", "©alb" => "ALBUM",
                        "aART" => "ALBUMARTIST", "©day" => "DATE", "©gen" => "GENRE", "©wrt" => "COMPOSER",
                        _ => name,
                    };
                    if (dataType == 0 && type is "apID" or "purd" or "sonm") c.Field(type, "presente");
                    else c.Field(key, value);
                }
                else if (type is "apID" or "purd" or "sonm") c.Field(type, "presente");
            }
            o += size;
        }
        if (type is "apID" or "purd") c.Field("ITUNES_PURCHASE", type);
    }

    // ---- WAV e AIFF --------------------------------------------------------------------------

    static readonly Dictionary<string, string> RiffNames = new()
    {
        ["ISFT"] = "ENCODER", ["ICMT"] = "COMMENT", ["ICOP"] = "COPYRIGHT", ["ISRC"] = "SOURCE", ["INAM"] = "TITLE",
        ["IART"] = "ARTIST", ["IPRD"] = "ALBUM", ["ICRD"] = "DATE", ["IGNR"] = "GENRE", ["ITRK"] = "TRACKNUMBER",
        ["IPRT"] = "TRACKNUMBER",
    };

    static void ParseRiff(SafeFileHandle h, long size, Ctx c)
    {
        long pos = 12;
        int byteRate = 0;
        for (int guard = 0; pos + 8 <= size && guard < 4096; guard++)
        {
            var hd = ReadAt(h, pos, 12);
            if (hd.Length < 8) break;
            var id = Latin1.GetString(hd, 0, 4);
            long len = U32Le(hd, 4);
            if (id == "fmt " && len >= 16)
            {
                var f = ReadAt(h, pos + 8, (int)Math.Min(len, 64));
                int tag = U16Le(f, 0);
                c.T.Channels = U16Le(f, 2);
                c.T.SampleRate = (int)U32Le(f, 4);
                byteRate = (int)U32Le(f, 8);
                c.T.Bits = U16Le(f, 14);
                if (tag == 0xFFFE && f.Length >= 26) c.T.Bits = U16Le(f, 18) > 0 ? U16Le(f, 18) : c.T.Bits;
                c.T.Codec = "WAV";
            }
            else if (id == "data")
            {
                if (byteRate > 0) c.T.DurationMs = len * 1000 / byteRate;
            }
            else if (id == "LIST" && hd.Length >= 12 && Latin1.GetString(hd, 8, 4) == "INFO" && len < (4 << 20))
            {
                var body = ReadAt(h, pos + 12, (int)(len - 4));
                int o = 0;
                while (o + 8 <= body.Length)
                {
                    var sid = Latin1.GetString(body, o, 4);
                    int sl = (int)U32Le(body, o + 4);
                    if (sl < 0 || o + 8 + sl > body.Length) break;
                    var v = DecodeInfo(body, o + 8, sl);
                    c.Field(RiffNames.TryGetValue(sid, out var n) ? n : sid, v);
                    o += 8 + sl + (sl & 1);
                }
            }
            else if ((id == "id3 " || id == "ID3 ") && len < (64 << 20)) Id3Bytes(ReadAt(h, pos + 8, (int)len), c);
            pos += 8 + len + (len & 1);
        }
    }

    static string DecodeInfo(byte[] b, int o, int len)
    {
        var raw = b.AsSpan(o, len).ToArray();
        try
        {
            var s = new UTF8Encoding(false, true).GetString(raw);
            return s.Trim('\0', ' ');
        }
        catch { return Latin1.GetString(raw).Trim('\0', ' '); }
    }

    static void ParseAiff(SafeFileHandle h, long size, Ctx c)
    {
        long pos = 12;
        for (int guard = 0; pos + 8 <= size && guard < 4096; guard++)
        {
            var hd = ReadAt(h, pos, 8);
            if (hd.Length < 8) break;
            var id = Latin1.GetString(hd, 0, 4);
            long len = U32Be(hd, 4);
            if (id == "COMM" && len >= 18)
            {
                var f = ReadAt(h, pos + 8, (int)Math.Min(len, 64));
                c.T.Codec = "AIFF";
                c.T.Channels = U16Be(f, 0);
                long frames = U32Be(f, 2);
                c.T.Bits = U16Be(f, 6);
                double rate = Extended(f, 8);
                c.T.SampleRate = (int)Math.Round(rate);
                if (rate > 0) c.T.DurationMs = (long)(frames * 1000 / rate);
            }
            else if ((id == "ID3 " || id == "id3 ") && len < (64 << 20)) Id3Bytes(ReadAt(h, pos + 8, (int)len), c);
            else if (id == "NAME" && len < 4096) c.Field("TITLE", Latin1.GetString(ReadAt(h, pos + 8, (int)len)).Trim('\0', ' '));
            else if (id == "AUTH" && len < 4096) c.Field("ARTIST", Latin1.GetString(ReadAt(h, pos + 8, (int)len)).Trim('\0', ' '));
            pos += 8 + len + (len & 1);
        }
    }

    /// <summary>Número de 80 bits (IEEE estendido) usado pela taxa de amostragem do AIFF.</summary>
    static double Extended(byte[] b, int o)
    {
        int exp = ((b[o] & 0x7F) << 8) | b[o + 1];
        ulong mant = 0;
        for (int i = 0; i < 8; i++) mant = (mant << 8) | b[o + 2 + i];
        if (exp == 0 && mant == 0) return 0;
        return mant * Math.Pow(2, exp - 16383 - 63);
    }

    // ---- Montagem da faixa ----------------------------------------------------------------------

    public static Track ToTrack(string path, FileTags t, FileInfo fi)
    {
        static int Num(string s)
        {
            var m = Regex.Match(s, @"\d+");
            return m.Success && int.TryParse(m.Value, out var n) ? n : 0;
        }
        var year = Regex.Match(t.Get("DATE", "YEAR", "ORIGINALDATE", "TYER", "ORIGINALYEAR"), @"\d{4}");
        var title = t.Get("TITLE");
        if (title == "") title = System.IO.Path.GetFileNameWithoutExtension(path);
        var codec = t.Codec;
        if (codec == "")
            codec = System.IO.Path.GetExtension(path).ToLowerInvariant() switch
            {
                ".flac" => "FLAC", ".mp3" => "MP3", ".wav" => "WAV", ".aif" or ".aiff" or ".aifc" => "AIFF",
                ".ogg" or ".oga" => "Vorbis", ".opus" => "Opus", ".m4a" or ".mp4" or ".aac" => "AAC", _ => "",
            };
        return new Track
        {
            Id = Library.IdFor(path),
            Path = path,
            Title = title,
            Artist = t.Get("ARTIST", "PERFORMER", "ALBUMARTIST", "ALBUM ARTIST") is var a && a != "" ? a : "Artista desconhecido",
            Album = t.Get("ALBUM") is var al && al != "" ? al : "Álbum desconhecido",
            AlbumArtist = t.Get("ALBUMARTIST", "ALBUM ARTIST", "ALBUM_ARTIST"),
            Genre = t.Get("GENRE"),
            Composer = t.Get("COMPOSER"),
            Year = year.Success ? int.Parse(year.Value) : 0,
            TrackNo = Num(t.Get("TRACKNUMBER", "TRACK")),
            DiscNo = Num(t.Get("DISCNUMBER", "DISC")),
            DurationMs = t.DurationMs,
            Codec = codec,
            SampleRate = t.SampleRate,
            Bits = codec is "MP3" or "AAC" or "Vorbis" or "Opus" ? 0 : t.Bits,
            Channels = t.Channels,
            BitrateKbps = t.BitrateKbps,
            HasCover = t.HasPicture,
            Folder = System.IO.Path.GetDirectoryName(path) ?? "",
            Size = fi.Length,
            Modified = fi.LastWriteTimeUtc.Ticks,
        };
    }

    // ---- Origem -------------------------------------------------------------------------------

    sealed record Rule(string Name, string[] Needles);

    static readonly Rule[] Rules =
    {
        new("Qobuz (loja de música em alta resolução)", new[] { "qobuz" }),
        new("Tidal", new[] { "tidal" }),
        new("Deezer", new[] { "deezer", "deemix" }),
        new("Bandcamp", new[] { "bandcamp" }),
        new("HDtracks", new[] { "hdtracks" }),
        new("7digital", new[] { "7digital" }),
        new("Amazon Music", new[] { "amazon.com", "amazon music", "amazon song id" }),
        new("Apple Music / iTunes Store", new[] { "itunes_purchase", "itunes store", "apple music" }),
        new("Beatport", new[] { "beatport" }),
        new("Bleep", new[] { "bleep.com" }),
        new("Spotify (gravado da plataforma, com perdas na origem)", new[] { "spotify", "spotdl" }),
        new("YouTube (baixado, com perdas na origem)", new[] { "youtube", "yt-dlp", "youtube-dl", "youtu.be" }),
        new("SoundCloud", new[] { "soundcloud" }),
        new("CD original (extraído com Exact Audio Copy)", new[] { "exact audio copy", "eac " }),
        new("CD original (extraído com XLD)", new[] { "x lossless decoder", "xld " }),
        new("CD original (extraído com dBpoweramp)", new[] { "dbpoweramp" }),
        new("CD original (extraído com CUETools)", new[] { "cuetools" }),
        new("CD original (extraído com fre:ac)", new[] { "fre:ac" }),
    };

    static readonly HashSet<string> MediaKeys = new() { "SOURCEMEDIA", "MEDIA", "SOURCE", "MEDIATYPE", "TXXX:SOURCE", "TXXX:MEDIA" };

    /// <summary>Descobre a origem pelas tags; sem pistas, a origem é "Desconhecida".</summary>
    public static FileOrigin Origin(FileTags tags)
    {
        var all = tags.Fields.Select(f => (f.Key, f.Value)).ToList();
        all.Add(("VENDOR", tags.Vendor));
        foreach (var rule in Rules)
            foreach (var (k, v) in all)
            {
                var hay = (k + " " + v).ToLowerInvariant() + " ";
                if (rule.Needles.Any(n => hay.Contains(n))) return new FileOrigin(rule.Name, Evidence(k, v));
            }
        foreach (var (k, v) in all)
        {
            if (!MediaKeys.Contains(k)) continue;
            var lv = v.ToLowerInvariant();
            string? name =
                lv.Contains("sacd") ? "SACD" :
                lv.Contains("cd") ? "CD" :
                lv.Contains("vinyl") || lv.Contains("vinil") || lv.Trim() == "lp" ? "Disco de vinil (digitalizado)" :
                lv.Contains("web") || lv.Contains("digital") ? "Loja digital (WEB)" :
                lv.Contains("cassette") || lv.Contains("tape") ? "Fita cassete (digitalizada)" :
                lv.Contains("dvd") ? "DVD" : null;
            if (name != null) return new FileOrigin(name, Evidence(k, v));
            break;
        }
        foreach (var (k, v) in all)
        {
            var lv = v.ToLowerInvariant();
            if (lv.Contains("lavf") || lv.Contains("lavc") || lv.Contains("ffmpeg"))
                return new FileOrigin("Convertido com FFmpeg (origem anterior desconhecida)", Evidence(k, v));
        }
        var encoder = all.FirstOrDefault(f => f.Key is "ENCODER" or "ENCODED-BY").Value;
        if (string.IsNullOrWhiteSpace(encoder)) encoder = string.IsNullOrWhiteSpace(tags.Vendor) ? null : tags.Vendor;
        return new FileOrigin(FileOrigin.Unknown,
            encoder != null
                ? "Nenhuma tag indica a origem. Software que gravou o arquivo: " + (encoder.Length > 60 ? encoder[..60] : encoder)
                : "Nenhuma tag indica a origem do arquivo");
    }

    static string Evidence(string key, string value)
    {
        var v = value.Replace('\n', ' ').Trim();
        if (v.Length > 70) v = v[..67] + "…";
        var k = key.StartsWith("TXXX:") ? key[5..] : key.StartsWith("----:") ? key[5..] : key;
        return $"Encontrado na tag {k}: \"{v}\"";
    }
}

/// <summary>Leitor de letras no formato LRC: "[01:23.45]texto".</summary>
public static class Lrc
{
    static readonly Regex Time = new(@"\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]", RegexOptions.Compiled);
    static readonly Regex Offset = new(@"\[offset:\s*([+-]?\d+)\s*\]", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public static List<LyricLine>? Parse(string text)
    {
        var om = Offset.Match(text);
        long offset = om.Success && long.TryParse(om.Groups[1].Value, out var ov) ? ov : 0;
        var lines = new List<LyricLine>();
        foreach (var raw in text.Split('\n'))
        {
            var stamps = Time.Matches(raw);
            if (stamps.Count == 0) continue;
            var last = stamps[^1];
            var lyric = raw[(last.Index + last.Length)..].Trim();
            foreach (Match m in stamps)
            {
                long min = long.Parse(m.Groups[1].Value);
                long sec = long.Parse(m.Groups[2].Value);
                var frac = m.Groups[3].Value;
                long ms = frac.Length switch { 0 => 0, 1 => long.Parse(frac) * 100, 2 => long.Parse(frac) * 10, _ => long.Parse(frac[..3]) };
                lines.Add(new LyricLine(Math.Max(0, min * 60_000 + sec * 1000 + ms - offset), lyric));
            }
        }
        if (lines.Count < 3) return null;
        return lines.OrderBy(l => l.TimeMs).ToList();
    }
}
