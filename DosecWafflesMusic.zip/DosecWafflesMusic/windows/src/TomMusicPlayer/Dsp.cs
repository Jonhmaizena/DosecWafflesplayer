using NAudio.Wave;

namespace TomMusic;

/// <summary>Bandas ISO de 2/3 de oitava, de 25 Hz a 16 kHz (as mesmas do app Android).</summary>
public static class EqBands
{
    public static readonly float[] Centers =
    {
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f, 1000f, 1600f, 2500f, 4000f, 6300f, 10000f, 16000f,
    };
    public const int Count = 15;
    public const float MaxDb = 15f;
    public const float PreampMin = -12f;
    public const float PreampMax = 6f;
}

public sealed record EqPreset(string Name, float[] Gains);

public static class EqPresets
{
    //                                         25  40  63 100 160 250 400 630  1k 1.6k 2.5k 4k 6.3k 10k 16k
    public static readonly EqPreset[] All =
    {
        new("Plano", new[] { 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f }),
        new("Graves", new[] { 7f, 6.5f, 6f, 4.5f, 3f, 1.5f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f }),
        new("Sub-grave", new[] { 9f, 8f, 5f, 2f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f }),
        new("Agudos", new[] { 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0.5f, 1.5f, 3f, 4.5f, 5.5f, 6f, 6f }),
        new("Vocal", new[] { -3f, -3f, -2f, -1f, 0f, 1f, 2.5f, 3.5f, 4f, 3.5f, 2.5f, 1f, 0f, -0.5f, -1f }),
        new("Rock", new[] { 5f, 4.5f, 4f, 2.5f, 0.5f, -1f, -1.5f, -1f, 0.5f, 2f, 3.5f, 4.5f, 5f, 5f, 4.5f }),
        new("Pop", new[] { -1f, -0.5f, 0.5f, 2f, 3.5f, 4f, 3f, 1.5f, 0f, -0.5f, -0.5f, 0f, 1f, 1.5f, 2f }),
        new("Jazz", new[] { 3f, 3f, 2.5f, 2f, 1f, -1f, -1.5f, -1f, 0f, 1f, 2f, 2.5f, 3f, 3f, 3f }),
        new("Clássica", new[] { 4f, 3.5f, 3f, 2f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 2.5f, 3.5f, 4f }),
        new("Eletrônica", new[] { 6f, 5.5f, 5f, 3f, 0.5f, -1f, -2f, -1f, 0f, 1f, 2f, 3.5f, 4.5f, 5f, 5f }),
        new("Loudness", new[] { 6f, 5f, 4f, 2.5f, 1f, 0f, -0.5f, -1f, -1f, -0.5f, 0.5f, 2f, 3.5f, 4.5f, 5f }),
        new("Fone Hi-Fi", new[] { 2f, 2f, 1.5f, 1f, 0.5f, 0f, 0f, -0.5f, 0f, 0.5f, 1f, 0.5f, -1f, 0f, 1f }),
        new("60+", new[] { -2f, -1.5f, -1f, 0f, 0f, 0f, 0.5f, 1f, 1.5f, 2.5f, 3.5f, 4.5f, 5f, 4.5f, 3f }),
        new("Jovens", new[] { 6f, 6f, 5f, 3.5f, 1.5f, 0f, -1f, -1.5f, -1f, 0f, 1.5f, 3f, 4f, 4.5f, 5f }),
        new("Estilo Qobuz", new[] { 0.5f, 0.5f, 0.5f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0.5f, 1f, 1.5f, 2f, 2.5f }),
        new("Estilo Tidal", new[] { 1.5f, 1.5f, 1.5f, 1f, 0.5f, 0.5f, 0f, 0f, 0f, 0f, 0.5f, 0.5f, 1f, 1.5f, 1.5f }),
        new("Carro 4T+2F", new[] { 1f, 3f, 4f, 3f, 0.5f, -2f, -2f, -1f, 0f, 0.5f, -1f, -1.5f, -1f, 0.5f, 1f }),
        new("Carro 2V+2T+1S", new[] { 0f, 2f, 2.5f, 1f, -1f, -2f, -1.5f, -0.5f, 0f, 1f, 0.5f, -1f, -1f, 0.5f, 1f }),
        new("Carro 2V+2T", new[] { 1f, 3f, 4.5f, 3.5f, 1f, -1.5f, -2f, -1f, 0f, 1.5f, 1f, -1f, -1.5f, 0f, 1f }),
    };
}

/// <summary>Estado do processamento compartilhado entre a interface e o áudio (mudanças valem na hora).</summary>
public sealed class DspState
{
    volatile int version;
    public int Version => version;

    public bool EqOn { get; private set; }
    public float Preamp { get; private set; }
    public float[] Gains { get; private set; } = new float[EqBands.Count];
    public bool PalcoOn { get; private set; }
    public float PalcoAmount { get; private set; } = 1.4f;
    public float Volume { get; private set; } = 1f;

    public bool Active => EqOn || PalcoOn;

    public void Set(EqSettings eq, bool palcoOn, float palcoAmount, float volume)
    {
        EqOn = eq.Enabled;
        Preamp = eq.Preamp;
        Gains = (float[])eq.Gains.Clone();
        PalcoOn = palcoOn;
        PalcoAmount = Math.Clamp(palcoAmount, 0.5f, 2f);
        Volume = Math.Clamp(volume, 0f, 1f);
        version++;
    }
}

/// <summary>
/// Equalizador de 15 bandas (filtros biquad "peaking", 2/3 de oitava), pré-amplificação,
/// limitador em −1 dBFS e Palco (largura estéreo com graves no centro). Tudo em ponto flutuante.
/// </summary>
public sealed class DspProvider : ISampleProvider
{
    readonly ISampleProvider src;
    readonly DspState state;
    readonly int rate, ch;
    int seenVersion = -1;

    // Equalizador
    bool eqOn;
    float preGain = 1f;
    readonly double[,] coef = new double[EqBands.Count, 5]; // b0 b1 b2 a1 a2
    readonly bool[] bandOn = new bool[EqBands.Count];
    double[,,] z = new double[1, 1, 2];

    // Limitador
    float env = 1f;
    readonly float attack, release;

    // Palco
    bool palcoOn;
    float width = 1f;
    float sideLow;
    readonly float lowCoef;

    public DspProvider(ISampleProvider source, DspState state)
    {
        src = source;
        this.state = state;
        rate = source.WaveFormat.SampleRate;
        ch = source.WaveFormat.Channels;
        z = new double[ch, EqBands.Count, 2];
        attack = (float)(1 - Math.Exp(-1.0 / (0.001 * rate)));
        release = (float)(1 - Math.Exp(-1.0 / (0.060 * rate)));
        lowCoef = (float)(1 - Math.Exp(-2 * Math.PI * 150.0 / rate));
    }

    public WaveFormat WaveFormat => src.WaveFormat;

    void Update()
    {
        seenVersion = state.Version;
        eqOn = state.EqOn;
        palcoOn = state.PalcoOn && ch == 2;
        width = state.PalcoAmount;
        preGain = (float)Math.Pow(10, state.Preamp / 20.0);
        var gains = state.Gains;
        for (int b = 0; b < EqBands.Count; b++)
        {
            double f0 = EqBands.Centers[b];
            double g = b < gains.Length ? gains[b] : 0;
            bandOn[b] = Math.Abs(g) > 0.01 && f0 < rate * 0.45;
            if (!bandOn[b]) continue;
            // Filtro "peaking" (RBJ), Q de 2/3 de oitava
            double A = Math.Pow(10, g / 40.0);
            double w0 = 2 * Math.PI * f0 / rate;
            double alpha = Math.Sin(w0) / (2 * 2.145);
            double cos = Math.Cos(w0);
            double a0 = 1 + alpha / A;
            coef[b, 0] = (1 + alpha * A) / a0;
            coef[b, 1] = -2 * cos / a0;
            coef[b, 2] = (1 - alpha * A) / a0;
            coef[b, 3] = -2 * cos / a0;
            coef[b, 4] = (1 - alpha / A) / a0;
        }
    }

    public int Read(float[] buffer, int offset, int count)
    {
        int n = src.Read(buffer, offset, count);
        if (state.Version != seenVersion) Update();
        if (n <= 0) return n;

        if (palcoOn) Palco(buffer, offset, n);
        if (eqOn) Eq(buffer, offset, n);
        return n;
    }

    void Palco(float[] buf, int offset, int n)
    {
        float w = width;
        float gain = w > 1f ? 1f / (1f + 0.25f * (w - 1f)) : 1f;
        float a = lowCoef, low = sideLow;
        for (int i = offset; i + 1 < offset + n; i += 2)
        {
            float l = buf[i], r = buf[i + 1];
            float mid = (l + r) * 0.5f, side = (l - r) * 0.5f;
            low += a * (side - low);
            float s = low + w * (side - low);
            buf[i] = SoftClip((mid + s) * gain);
            buf[i + 1] = SoftClip((mid - s) * gain);
        }
        sideLow = Math.Abs(low) < 1e-20f ? 0f : low;
    }

    void Eq(float[] buf, int offset, int n)
    {
        const float threshold = 0.891f; // −1 dBFS
        int frames = n / ch;
        for (int f = 0; f < frames; f++)
        {
            int baseIdx = offset + f * ch;
            float peak = 0f;
            for (int c = 0; c < ch; c++)
            {
                double x = buf[baseIdx + c] * preGain;
                for (int b = 0; b < EqBands.Count; b++)
                {
                    if (!bandOn[b]) continue;
                    // Forma direta transposta II
                    double y = coef[b, 0] * x + z[c, b, 0];
                    z[c, b, 0] = coef[b, 1] * x - coef[b, 3] * y + z[c, b, 1];
                    z[c, b, 1] = coef[b, 2] * x - coef[b, 4] * y;
                    x = y;
                }
                float v = (float)x;
                buf[baseIdx + c] = v;
                float av = Math.Abs(v);
                if (av > peak) peak = av;
            }
            float target = peak > threshold ? threshold / peak : 1f;
            env += (target < env ? attack : release) * (target - env);
            if (env < 1f || peak > threshold)
                for (int c = 0; c < ch; c++) buf[baseIdx + c] = SoftClip(buf[baseIdx + c] * env);
        }
        // Evita números subnormais no silêncio
        for (int c = 0; c < ch; c++)
            for (int b = 0; b < EqBands.Count; b++)
            {
                if (Math.Abs(z[c, b, 0]) < 1e-25) z[c, b, 0] = 0;
                if (Math.Abs(z[c, b, 1]) < 1e-25) z[c, b, 1] = 0;
            }
    }

    static float SoftClip(float x)
    {
        float a = Math.Abs(x);
        if (a <= 0.9f) return x;
        float y = 0.9f + 0.1f * (float)Math.Tanh((a - 0.9f) / 0.1f);
        return x < 0 ? -y : y;
    }
}
