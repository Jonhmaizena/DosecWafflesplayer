namespace TomMusic;

/// <summary>Fila de reprodução, aleatório, repetir e a ponte com o motor de áudio.</summary>
public sealed class Player
{
    readonly AudioEngine engine;
    readonly Library library;
    readonly Settings settings;
    readonly SemaphoreSlim op = new(1, 1);   // uma operação de cada vez
    readonly object state = new();           // estado da fila (leituras rápidas)

    List<Track> queue = new();
    List<Track> original = new();
    int index = -1;
    bool shuffle;
    int repeat;              // 0 = não repetir, 1 = repetir todas, 2 = repetir uma
    bool loaded;             // o motor está com a faixa aberta
    long resumeMs;           // posição para retomar quando a faixa ainda não foi aberta
    string error = "";
    DateTime lastSave = DateTime.MinValue;

    public event Action? Changed;

    public Player(AudioEngine engine, Library library, Settings settings)
    {
        this.engine = engine;
        this.library = library;
        this.settings = settings;
        engine.NextAfter = NextAfter;
        engine.Advanced += OnAdvanced;
        engine.Ended += () => Task.Run(OnEnded);
        engine.Failed += (t, msg) => { lock (state) error = msg; Changed?.Invoke(); };
        engine.InfoChanged += () => Changed?.Invoke();
    }

    // ---- estado ----------------------------------------------------------------------------------

    public sealed record Snapshot(
        Track? Track, List<string> QueueIds, int Index, bool Playing, long PositionMs, bool Shuffle, int Repeat, string Error);

    // Nunca chamamos o motor segurando a trava da fila: a linha de áudio também consulta a fila.
    public Snapshot Get()
    {
        Track? t;
        List<string> ids;
        int idx, rep;
        bool sh, isLoaded;
        long resume;
        string err;
        lock (state)
        {
            t = index >= 0 && index < queue.Count ? queue[index] : null;
            ids = queue.Select(x => x.Id).ToList();
            idx = index; sh = shuffle; rep = repeat; err = error; isLoaded = loaded; resume = resumeMs;
        }
        bool playing = isLoaded && engine.IsPlaying;
        long pos = isLoaded ? engine.PositionMs : resume;
        if (t != null && t.DurationMs > 0) pos = Math.Min(pos, t.DurationMs);
        return new Snapshot(t, ids, idx, playing, pos, sh, rep, err);
    }

    int NextIndex()
    {
        if (queue.Count == 0) return -1;
        if (repeat == 2) return index;
        if (index + 1 < queue.Count) return index + 1;
        return repeat == 1 ? 0 : -1;
    }

    /// <summary>A faixa que vem depois de <paramref name="t"/> (usada pelo motor para emendar sem pausa).</summary>
    Track? NextAfter(Track t)
    {
        lock (state)
        {
            if (queue.Count == 0) return null;
            if (repeat == 2) return t;
            int i = index >= 0 && index < queue.Count && queue[index] == t ? index : queue.IndexOf(t);
            if (i < 0) return null;
            if (i + 1 < queue.Count) return queue[i + 1];
            return repeat == 1 ? queue[0] : null;
        }
    }

    void OnAdvanced(Track t)
    {
        lock (state)
        {
            int n = NextIndex();
            if (n >= 0 && queue[n] == t) index = n;
            else
            {
                int i = queue.IndexOf(t);
                if (i >= 0) index = i;
            }
            loaded = true;
            error = "";
        }
        SaveQueue(force: true);
        Changed?.Invoke();
    }

    async Task OnEnded()
    {
        await op.WaitAsync();
        try
        {
            int n;
            lock (state)
            {
                loaded = false;
                n = NextIndex();
            }
            // Fim natural da fila: volta ao começo da última faixa, pausado
            if (n < 0)
            {
                lock (state) resumeMs = 0;
            }
            else
            {
                // A próxima faixa falhou ao abrir antes (ou tem formato que exige reabrir a saída)
                lock (state) index = n;
                PlayCurrent(0, true);
            }
        }
        finally { op.Release(); }
        SaveQueue(force: true);
        Changed?.Invoke();
    }

    /// <summary>Abre a faixa atual; se falhar, pula para as seguintes (até dar certo ou acabar a fila).</summary>
    void PlayCurrent(long startMs, bool autoplay)
    {
        for (int attempt = 0; attempt < 50; attempt++)
        {
            Track t;
            lock (state)
            {
                if (index < 0 || index >= queue.Count) { loaded = false; return; }
                t = queue[index];
            }
            if (engine.Play(t, startMs, autoplay))
            {
                lock (state) { loaded = true; error = ""; }
                return;
            }
            lock (state)
            {
                loaded = false;
                int n = index + 1 < queue.Count ? index + 1 : -1;
                if (n < 0 || attempt + 1 >= queue.Count) return;
                index = n;
            }
            startMs = 0;
        }
    }

    async Task Do(Action action)
    {
        await op.WaitAsync();
        try { action(); }
        finally { op.Release(); }
        SaveQueue(force: true);
        Changed?.Invoke();
    }

    // ---- comandos --------------------------------------------------------------------------------

    public Task PlayList(List<Track> list, int start) => Do(() =>
    {
        if (list.Count == 0) return;
        lock (state)
        {
            original = list.ToList();
            queue = list.ToList();
            index = Math.Clamp(start, 0, list.Count - 1);
            if (shuffle) ShuffleAround(index);
            resumeMs = 0;
        }
        PlayCurrent(0, true);
    });

    public Task Toggle() => Do(() =>
    {
        bool isLoaded, isPlaying;
        long resume;
        lock (state) { isLoaded = loaded; resume = resumeMs; }
        isPlaying = isLoaded && engine.IsPlaying;
        if (!isLoaded) { PlayCurrent(resume, true); return; }
        if (isPlaying) engine.Pause(); else engine.Resume();
    });

    public Task Pause() => Do(() => { if (engine.IsPlaying) engine.Pause(); });

    public Task Next() => Do(() =>
    {
        lock (state)
        {
            if (queue.Count == 0) return;
            index = index + 1 < queue.Count ? index + 1 : 0;
            resumeMs = 0;
        }
        PlayCurrent(0, true);
    });

    public Task Previous() => Do(() =>
    {
        bool wasLoaded;
        long resumeAt;
        lock (state) { wasLoaded = loaded; resumeAt = resumeMs; }
        long pos = wasLoaded ? engine.PositionMs : resumeAt;
        if (pos > 3000)
        {
            bool isLoaded;
            lock (state) { isLoaded = loaded; resumeMs = 0; }
            if (isLoaded) engine.Seek(0);
            return;
        }
        lock (state)
        {
            if (queue.Count == 0) return;
            index = index > 0 ? index - 1 : (repeat == 1 ? queue.Count - 1 : 0);
            resumeMs = 0;
        }
        PlayCurrent(0, true);
    });

    public Task Seek(long ms) => Do(() =>
    {
        bool isLoaded;
        lock (state) { isLoaded = loaded; if (!isLoaded) resumeMs = Math.Max(0, ms); }
        if (isLoaded) engine.Seek(ms);
    });

    public Task JumpTo(int i) => Do(() =>
    {
        lock (state)
        {
            if (i < 0 || i >= queue.Count) return;
            index = i;
            resumeMs = 0;
        }
        PlayCurrent(0, true);
    });

    public Task PlayNextInQueue(List<Track> tracks) => Do(() =>
    {
        lock (state)
        {
            if (queue.Count == 0) { queue = tracks.ToList(); original = tracks.ToList(); index = 0; return; }
            queue.InsertRange(index + 1, tracks);
            original.AddRange(tracks);
        }
        engine.InvalidateNext();
    });

    public Task AddToQueue(List<Track> tracks) => Do(() =>
    {
        lock (state)
        {
            if (queue.Count == 0) { queue = tracks.ToList(); original = tracks.ToList(); index = 0; return; }
            queue.AddRange(tracks);
            original.AddRange(tracks);
        }
        engine.InvalidateNext();
    });

    public Task RemoveAt(int i) => Do(() =>
    {
        bool removedCurrent = false;
        lock (state)
        {
            if (i < 0 || i >= queue.Count) return;
            var t = queue[i];
            queue.RemoveAt(i);
            original.Remove(t);
            if (i < index) index--;
            else if (i == index)
            {
                removedCurrent = true;
                if (index >= queue.Count) index = queue.Count - 1;
            }
        }
        if (removedCurrent)
        {
            bool wasPlaying = engine.IsPlaying;
            engine.Stop();
            lock (state) { loaded = false; resumeMs = 0; }
            if (wasPlaying) PlayCurrent(0, true);
        }
        else engine.InvalidateNext();
    });

    public Task Move(int from, int to) => Do(() =>
    {
        lock (state)
        {
            if (from < 0 || from >= queue.Count || to < 0 || to >= queue.Count) return;
            var t = queue[from];
            queue.RemoveAt(from);
            queue.Insert(to, t);
            if (index == from) index = to;
            else if (from < index && to >= index) index--;
            else if (from > index && to <= index) index++;
        }
        engine.InvalidateNext();
    });

    public Task SetShuffle(bool on) => Do(() =>
    {
        lock (state)
        {
            if (on == shuffle) return;
            shuffle = on;
            if (queue.Count == 0) return;
            var cur = index >= 0 && index < queue.Count ? queue[index] : null;
            if (on)
            {
                original = queue.ToList();
                ShuffleAround(index);
            }
            else
            {
                queue = original.ToList();
                index = cur != null ? Math.Max(0, queue.IndexOf(cur)) : 0;
            }
        }
        engine.InvalidateNext();
    });

    public Task SetRepeat(int mode) => Do(() =>
    {
        lock (state) repeat = Math.Clamp(mode, 0, 2);
        engine.InvalidateNext();
    });

    /// <summary>Embaralha mantendo a faixa atual em primeiro lugar.</summary>
    void ShuffleAround(int keep)
    {
        var cur = keep >= 0 && keep < queue.Count ? queue[keep] : null;
        var rest = queue.Where((_, i) => i != keep).OrderBy(_ => Random.Shared.Next()).ToList();
        queue = cur != null ? new List<Track> { cur }.Concat(rest).ToList() : rest;
        index = cur != null ? 0 : -1;
    }

    /// <summary>Reabre a saída (bit-perfect, dispositivo, EQ ou Palco mudou).</summary>
    public Task ReopenOutput() => Do(() =>
    {
        bool isLoaded;
        lock (state) isLoaded = loaded;
        if (isLoaded) engine.Reopen();
    });

    // ---- fila salva ------------------------------------------------------------------------------

    public void Restore()
    {
        var q = settings.Queue;
        lock (state)
        {
            queue = q.Ids.Select(library.Get).Where(t => t != null).Select(t => t!).ToList();
            original = q.Original.Select(library.Get).Where(t => t != null).Select(t => t!).ToList();
            if (original.Count == 0) original = queue.ToList();
            index = queue.Count == 0 ? -1 : Math.Clamp(q.Index, 0, queue.Count - 1);
            resumeMs = q.PositionMs;
            shuffle = q.Shuffle;
            repeat = q.Repeat;
            loaded = false;
        }
        Changed?.Invoke();
    }

    /// <summary>Atualiza faixas da fila depois de uma nova leitura da biblioteca.</summary>
    public void Relink()
    {
        lock (state)
        {
            queue = queue.Select(t => library.Get(t.Id) ?? t).ToList();
            original = original.Select(t => library.Get(t.Id) ?? t).ToList();
        }
    }

    public void SaveQueue(bool force = false)
    {
        if (!force && (DateTime.UtcNow - lastSave).TotalSeconds < 10) return;
        lastSave = DateTime.UtcNow;
        bool isLoaded;
        long resume;
        SavedQueue q;
        lock (state)
        {
            isLoaded = loaded;
            resume = resumeMs;
            q = new SavedQueue
            {
                Ids = queue.Select(t => t.Id).ToList(),
                Original = original.Select(t => t.Id).ToList(),
                Index = index,
                Shuffle = shuffle,
                Repeat = repeat,
            };
        }
        q.PositionMs = isLoaded ? engine.PositionMs : resume;
        settings.Queue = q;
        settings.Save();
    }
}
