using System.Text.Json.Serialization;

namespace TomMusic;

/// <summary>Uma música da biblioteca, com o que foi lido das tags e do cabeçalho do arquivo.</summary>
public sealed class Track
{
    public string Id { get; set; } = "";
    public string Path { get; set; } = "";
    public string Title { get; set; } = "";
    public string Artist { get; set; } = "";
    public string Album { get; set; } = "";
    public string AlbumArtist { get; set; } = "";
    public string Genre { get; set; } = "";
    public string Composer { get; set; } = "";
    public int Year { get; set; }
    public int TrackNo { get; set; }
    public int DiscNo { get; set; }
    public long DurationMs { get; set; }
    public string Codec { get; set; } = "";
    public int SampleRate { get; set; }
    public int Bits { get; set; }
    public int Channels { get; set; }
    public int BitrateKbps { get; set; }
    public bool HasCover { get; set; }
    public string Folder { get; set; } = "";
    public long Size { get; set; }
    public long Modified { get; set; }

    [JsonIgnore] public bool Lossless => Codec is "FLAC" or "ALAC" or "WAV" or "AIFF";
}

public sealed record LyricLine(long TimeMs, string Text);

/// <summary>Letra: sincronizada (linhas com tempo) ou texto simples.</summary>
public sealed class Lyrics
{
    public bool Synced { get; init; }
    public List<LyricLine> Lines { get; init; } = new();
    public string Text { get; init; } = "";
    public string Source { get; init; } = "";
}

public sealed record FileOrigin(string Name, string Evidence)
{
    public const string Unknown = "Desconhecida";
    public bool Known => Name != Unknown;
}

public sealed class Playlist
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..12];
    public string Name { get; set; } = "";
    public List<string> TrackIds { get; set; } = new();
}

public static class Fmt
{
    public static string Rate(int hz)
    {
        if (hz <= 0) return "";
        double k = hz / 1000.0;
        return (k % 1 == 0 ? ((int)k).ToString() : k.ToString("0.#", System.Globalization.CultureInfo.GetCultureInfo("pt-BR"))) + " kHz";
    }
}
