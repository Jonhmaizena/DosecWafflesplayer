using System.Collections.Concurrent;
using NAudio.CoreAudioApi;
using NAudio.CoreAudioApi.Interfaces;
using NAudio.Wave;

namespace TomMusic;

/// <summary>Saídas de áudio do Windows pelo WASAPI.</summary>
public sealed class WasapiBackend : IDeviceBackend, IMMNotificationClient
{
    readonly MMDeviceEnumerator enumerator = new();
    readonly ConcurrentDictionary<string, DeviceCaps> capsCache = new();
    readonly ConcurrentDictionary<string, OutputDevice> infoCache = new();
    public event Action? DevicesChanged;
    Timer? debounce;

    static readonly PropertyKey EnumeratorName =
        new(new Guid(unchecked((int)0xa45c254e), unchecked((short)0xdf1c), 0x4efd, 0x80, 0x20, 0x67, 0xd1, 0x46, 0xa8, 0x50, 0xe0), 24);

    public WasapiBackend()
    {
        try { enumerator.RegisterEndpointNotificationCallback(this); } catch { }
    }

    MMDevice? DefaultDevice()
    {
        try { return enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia); } catch { return null; }
    }

    public List<OutputDevice> List()
    {
        var list = new List<OutputDevice>();
        var def = DefaultDevice()?.ID ?? "";
        try
        {
            foreach (var d in enumerator.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
                list.Add(Describe(d, d.ID == def));
        }
        catch { }
        return list;
    }

    OutputDevice Describe(MMDevice d, bool isDefault)
    {
        string name = Safe(() => d.FriendlyName);
        string adapter = Safe(() => d.DeviceFriendlyName);
        string enumName = "";
        int formFactor = -1;
        try
        {
            var props = d.Properties;
            if (props.Contains(EnumeratorName)) enumName = props[EnumeratorName].Value as string ?? "";
            if (props.Contains(PropertyKeys.PKEY_AudioEndpoint_FormFactor))
                formFactor = Convert.ToInt32(props[PropertyKeys.PKEY_AudioEndpoint_FormFactor].Value);
        }
        catch { }
        var all = (name + " " + adapter + " " + enumName).ToUpperInvariant();
        string kind =
            enumName.Equals("USB", StringComparison.OrdinalIgnoreCase) || all.Contains("USB") ? "DAC USB" :
            enumName.StartsWith("BTH", StringComparison.OrdinalIgnoreCase) || all.Contains("BLUETOOTH") ? "Bluetooth" :
            formFactor == 9 || all.Contains("HDMI") || all.Contains("DISPLAY") ? "HDMI / monitor" :
            formFactor == 8 || all.Contains("SPDIF") || all.Contains("S/PDIF") || all.Contains("OPTICAL") ? "Saída digital (S/PDIF)" :
            formFactor == 3 ? "Headset" :
            formFactor == 2 ? "Fone de ouvido (placa de som interna)" :
            "Placa de som interna";
        return new OutputDevice { Id = d.ID, Name = name, Adapter = adapter, Kind = kind, IsDefault = isDefault };
    }

    static string Safe(Func<string> f) { try { return f() ?? ""; } catch { return ""; } }

    MMDevice? Find(string id)
    {
        if (!string.IsNullOrEmpty(id))
        {
            try
            {
                var d = enumerator.GetDevice(id);
                if (d.State == DeviceState.Active) return d;
            }
            catch { }
        }
        return DefaultDevice();
    }

    public OutputDevice? Resolve(string id)
    {
        var d = Find(id);
        if (d == null) return null;
        var def = DefaultDevice()?.ID ?? "";
        return Describe(d, d.ID == def);
    }

    public WaveFormat MixFormat(OutputDevice od)
    {
        var d = Find(od.Id) ?? throw new InvalidOperationException("Dispositivo indisponível");
        var ac = d.AudioClient;
        try
        {
            var mix = ac.MixFormat;
            bool isFloat = mix.Encoding == WaveFormatEncoding.IeeeFloat ||
                           (mix is WaveFormatExtensible e && e.SubFormat == NAudio.Dmo.AudioMediaSubtypes.MEDIASUBTYPE_IEEE_FLOAT);
            if (isFloat && mix.BitsPerSample == 32) return mix;
            return WaveFormat.CreateIeeeFloatWaveFormat(mix.SampleRate, mix.Channels);
        }
        finally { ac.Dispose(); }
    }

    public bool SupportsExclusive(OutputDevice od, WaveFormat f)
    {
        var d = Find(od.Id);
        if (d == null) return false;
        var ac = d.AudioClient;
        try { return ac.IsFormatSupported(AudioClientShareMode.Exclusive, f); }
        catch { return false; }
        finally { ac.Dispose(); }
    }

    public IWavePlayer Create(OutputDevice od, bool exclusive)
    {
        var d = Find(od.Id) ?? throw new InvalidOperationException("Dispositivo indisponível");
        return exclusive
            ? new WasapiOut(d, AudioClientShareMode.Exclusive, true, 60)
            : new WasapiOut(d, AudioClientShareMode.Shared, true, 100);
    }

    /// <summary>Descobre as taxas e bits que o DAC aceita no modo exclusivo.</summary>
    public DeviceCaps Caps(OutputDevice od)
    {
        return capsCache.GetOrAdd(od.Id, _ =>
        {
            int[] rates = { 44100, 48000, 88200, 96000, 176400, 192000, 352800, 384000, 705600, 768000 };
            var ok = new List<int>();
            int maxBits = 0;
            var d = Find(od.Id);
            if (d != null)
            {
                // Um só AudioClient para todas as consultas (IsFormatSupported não exige inicializar)
                var ac = d.AudioClient;
                try
                {
                    bool Test(WaveFormat f) { try { return ac.IsFormatSupported(AudioClientShareMode.Exclusive, f); } catch { return false; } }
                    foreach (var r in rates)
                    {
                        int best = 0;
                        foreach (var (c, v) in new[] { (32, 32), (32, 24), (24, 24), (16, 16) })
                        {
                            if (v <= best) continue;
                            if (Test(new WaveFormatExtensible(r, c, v, 2, false)) || (c == v && c <= 24 && Test(new WaveFormat(r, c, 2))))
                                best = v;
                        }
                        if (best > 0) { ok.Add(r); maxBits = Math.Max(maxBits, best); }
                    }
                }
                finally { ac.Dispose(); }
            }
            int maxRate = ok.Count > 0 ? ok.Max() : 0;
            var summary = ok.Count == 0
                ? "O dispositivo não aceita o modo exclusivo (talvez esteja bloqueado nas propriedades de som do Windows)"
                : $"Aceita no modo exclusivo: até {maxBits}-bit / {Fmt.Rate(maxRate)} ({string.Join(", ", ok.Select(Fmt.Rate))})";
            return new DeviceCaps { MaxRate = maxRate, MaxBits = maxBits, Rates = ok, Summary = summary };
        });
    }

    void Changed()
    {
        capsCache.Clear();
        debounce?.Dispose();
        debounce = new Timer(_ => DevicesChanged?.Invoke(), null, 600, Timeout.Infinite);
    }

    // IMMNotificationClient
    public void OnDeviceStateChanged(string deviceId, DeviceState newState) => Changed();
    public void OnDeviceAdded(string pwstrDeviceId) => Changed();
    public void OnDeviceRemoved(string deviceId) => Changed();
    public void OnDefaultDeviceChanged(DataFlow flow, Role role, string defaultDeviceId)
    {
        if (flow == DataFlow.Render && role == Role.Multimedia) Changed();
    }
    public void OnPropertyValueChanged(string pwstrDeviceId, PropertyKey key) { }
}

/// <summary>Saída simulada (para testar o app fora do Windows). Consome o áudio em tempo real.</summary>
public sealed class FakeBackend : IDeviceBackend
{
    public event Action? DevicesChanged { add { } remove { } }
    public double Speed { get; set; } = 1.0;
    static readonly OutputDevice Dev = new() { Id = "fake", Name = "Saída de teste", Adapter = "Simulador", Kind = "DAC USB", IsDefault = true };

    public List<OutputDevice> List() => new() { Dev };
    public OutputDevice? Resolve(string id) => Dev;
    public WaveFormat MixFormat(OutputDevice d) => WaveFormat.CreateIeeeFloatWaveFormat(48000, 2);
    public bool SupportsExclusive(OutputDevice d, WaveFormat f) =>
        f.SampleRate is 44100 or 48000 or 96000 && (f.BitsPerSample is 16 or 24 || (f is WaveFormatExtensible x && x.ValidBitsPerSample == 24 && f.BitsPerSample == 32));
    public IWavePlayer Create(OutputDevice d, bool exclusive) => new FakePlayer(Speed);
    public DeviceCaps Caps(OutputDevice d) => new() { MaxRate = 96000, MaxBits = 24, Rates = new() { 44100, 48000, 96000 }, Summary = "Simulado: até 24-bit / 96 kHz" };

    sealed class FakePlayer : IWavePlayer
    {
        IWaveProvider? src;
        Thread? thread;
        volatile PlaybackState state = PlaybackState.Stopped;
        readonly double speed;
        public FakePlayer(double speed) { this.speed = speed; }
        public float Volume { get; set; } = 1;
        public PlaybackState PlaybackState => state;
        public WaveFormat OutputWaveFormat => src!.WaveFormat;
        public event EventHandler<StoppedEventArgs>? PlaybackStopped;
        public long BytesConsumed;

        public void Init(IWaveProvider waveProvider) { src = waveProvider; }

        public void Play()
        {
            if (state == PlaybackState.Playing) return;
            bool start = state == PlaybackState.Stopped;
            state = PlaybackState.Playing;
            if (!start) return;
            thread = new Thread(Run) { IsBackground = true };
            thread.Start();
        }

        void Run()
        {
            var f = src!.WaveFormat;
            int chunk = f.AverageBytesPerSecond / 50;
            chunk -= chunk % f.BlockAlign;
            var buf = new byte[chunk];
            Exception? err = null;
            try
            {
                while (state != PlaybackState.Stopped)
                {
                    if (state == PlaybackState.Paused) { Thread.Sleep(10); continue; }
                    int n = src.Read(buf, 0, chunk);
                    if (n == 0) break;
                    BytesConsumed += n;
                    Thread.Sleep(Math.Max(1, (int)(20 / speed)));
                }
            }
            catch (Exception e) { err = e; }
            bool natural = state != PlaybackState.Stopped;
            state = PlaybackState.Stopped;
            if (natural || err != null) PlaybackStopped?.Invoke(this, new StoppedEventArgs(err));
            else PlaybackStopped?.Invoke(this, new StoppedEventArgs());
        }

        public void Stop() { state = PlaybackState.Stopped; }
        public void Pause() { if (state == PlaybackState.Playing) state = PlaybackState.Paused; }
        public void Dispose() { Stop(); }
    }
}
