'use strict';
// Tom Music Player — interface. O áudio é tocado pelo programa; esta página só envia comandos.

const TOKEN = new URLSearchParams(location.search).get('t') || '';
const ROW = 54;
const DEFAULT_COVER = 'default_cover.jpg';

// ---- utilidades ------------------------------------------------------------------------------------
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = n => `<svg><use href="#i-${n}"/></svg>`;
const cover = id => `/api/cover/${encodeURIComponent(id)}?t=${TOKEN}`;
const imgFallback = `onerror="this.onerror=null;this.src='${DEFAULT_COVER}';this.classList.add('fallback')"`;
const collator = new Intl.Collator('pt-BR', { sensitivity: 'base', numeric: true });

async function api(path, body) {
  const opts = { method: body === undefined ? 'GET' : 'POST', headers: { 'X-Tom': TOKEN } };
  if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  const r = await fetch('/api/' + path, opts);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const ct = r.headers.get('content-type') || '';
  return ct.includes('json') ? r.json() : null;
}

function fmtTime(ms) {
  if (!ms || ms < 0) ms = 0;
  const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`;
}
function fmtRate(hz) {
  if (!hz) return '';
  const k = hz / 1000;
  return (Number.isInteger(k) ? k : k.toLocaleString('pt-BR', { maximumFractionDigits: 1 })) + ' kHz';
}
function quality(t) {
  if (!t) return '';
  const k = t.sampleRate ? (t.sampleRate / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) : '';
  if (t.bits) return `${t.codec} ${t.bits}/${k}`;
  if (t.bitrateKbps) return `${t.codec} ${t.bitrateKbps} kbps`;
  return t.codec || '';
}
const isHiRes = t => t && (t.bits > 16 || t.sampleRate > 48000);
const plural = (n, one, many) => `${n.toLocaleString('pt-BR')} ${n === 1 ? one : many}`;

function toast(msg, ms = 3200) {
  let el = $('#toast');
  if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => el.classList.add('hidden'), ms);
}

function setRangeFill(r) {
  const min = +r.min || 0, max = +r.max || 100;
  r.style.setProperty('--p', ((r.value - min) / (max - min) * 100) + '%');
}

// ---- estado ----------------------------------------------------------------------------------------
let S = null;                // estado vindo do programa
let receivedAt = 0;
let tracks = [], byId = new Map(), libVersion = -1, libLoading = false;
let favorites = new Set(), favList = [], playlists = [];
let route = { name: 'songs' }, stack = [];
let query = '', sortBy = 'artist';
let currentList = null;      // lista virtual em exibição
let seeking = false;
let extras = null, extrasFor = null;
let npTab = null;

const viewEl = $('#view');

async function loadLibrary() {
  if (libLoading) return;
  libLoading = true;
  try {
    const d = await api('library');
    tracks = d.tracks;
    byId = new Map(tracks.map(t => [t.id, t]));
    libVersion = d.version;
    render();
    updateBar();
  } catch (e) { console.error(e); }
  libLoading = false;
}

async function loadStore(d) {
  try {
    d = d || await api('store');
    favList = d.favorites;
    favorites = new Set(favList);
    playlists = d.playlists;
  } catch (e) { console.error(e); }
}

// ---- eventos do programa (SSE) -------------------------------------------------------------------------
function connect() {
  const es = new EventSource('/api/events?t=' + TOKEN);
  es.onmessage = e => onState(JSON.parse(e.data));
}

let lastError = '';
function onState(s) {
  const prevTrack = S?.trackId;
  const qkey = x => x ? x.queue.join() + '|' + x.index : '';
  const prevQueue = qkey(S);
  S = s;
  receivedAt = performance.now();
  document.documentElement.dataset.theme = s.dark ? 'dark' : 'light';
  $('#nav-theme').innerHTML = s.dark ? `${icon('sun')}<span>Tema claro</span>` : `${icon('moon')}<span>Tema escuro</span>`;
  if (s.libraryVersion !== libVersion && !s.scanning) loadLibrary();
  if (tracks.length === 0 && s.scanning && !libLoading && s.scanDone === s.scanTotal) loadLibrary();
  updateScan();
  updateBar();
  if (s.error && s.error !== lastError) toast(s.error, 6000);
  lastError = s.error;
  if (prevTrack !== s.trackId) { extras = null; loadExtras(); if (currentList) currentList.render(true); }
  if ($('#np')) renderNowPlaying(prevTrack !== s.trackId);
  if ($('#queue') && prevQueue !== qkey(s)) renderQueue();
  if ($('#eqv') && !eqDragging) renderEq(false);
  if ($('#settings')) renderSettingsLive();
}

function updateScan() {
  const el = $('#scan');
  if (S.scanning) {
    el.classList.remove('hidden');
    $('span', el).textContent = S.scanTotal ? `Lendo músicas: ${S.scanDone.toLocaleString('pt-BR')} de ${S.scanTotal.toLocaleString('pt-BR')}` : 'Procurando músicas…';
    $('i', el).style.width = S.scanTotal ? (S.scanDone / S.scanTotal * 100) + '%' : '5%';
  } else el.classList.add('hidden');
}

function positionNow() {
  if (!S) return 0;
  let p = S.positionMs + (S.playing ? performance.now() - receivedAt : 0);
  if (S.durationMs) p = Math.min(p, S.durationMs);
  return p;
}

// ---- barra do player ----------------------------------------------------------------------------------
function updateBar() {
  if (!S) return;
  const t = byId.get(S.trackId);
  $('#bar-title').textContent = t ? t.title : 'Nada tocando';
  $('#bar-artist').textContent = t ? `${t.artist} · ${t.album}` : 'Escolha uma música';
  const art = $('#bar-art');
  const src = t ? cover(t.id) : DEFAULT_COVER;
  if (art.dataset.src !== src) {
    art.dataset.src = src;
    art.classList.remove('disc');
    art.onerror = () => { art.onerror = null; art.src = DEFAULT_COVER; art.classList.add('disc'); };
    art.src = src;
  }
  $('#bar-fav').innerHTML = icon(t && favorites.has(t.id) ? 'heart' : 'heart-o');
  $('#bar-fav').classList.toggle('on', !!(t && favorites.has(t.id)));
  $('#b-play').innerHTML = icon(S.playing ? 'pause' : 'play');
  $('#b-shuffle').classList.toggle('on', S.shuffle);
  $('#b-repeat').classList.toggle('on', S.repeat > 0);
  $('#b-repeat').innerHTML = icon(S.repeat === 2 ? 'repeat-one' : 'repeat');
  $('#b-repeat').title = ['Repetir: desligado', 'Repetir: todas', 'Repetir: esta'][S.repeat];
  $('#t-dur').textContent = fmtTime(S.durationMs);

  const c = S.chain || {};
  const badge = $('#badge');
  badge.className = 'badge';
  if (!t) badge.textContent = '—';
  else if (c.bitPerfect) {
    badge.textContent = `BIT-PERFECT ${t.bits ? t.bits + '/' + (t.sampleRate / 1000).toLocaleString('pt-BR') : fmtRate(t.sampleRate)}`;
    badge.classList.add('bp');
  } else {
    const fx = [S.eq?.enabled ? 'EQ' : '', S.palcoOn ? 'Palco' : ''].filter(Boolean).join(' + ');
    badge.textContent = `MIXER${c.mixRate ? ' ' + fmtRate(c.mixRate) : ''}${fx ? ' · ' + fx : ''}`;
    if (isHiRes(t)) badge.classList.add('hires');
  }
  badge.title = c.path || 'Cadeia de áudio';

  const vol = $('#vol');
  if (document.activeElement !== vol) vol.value = Math.round((S.volume ?? 1) * 100);
  vol.disabled = !!c.exclusive;
  vol.title = c.exclusive ? 'No bit-perfect o volume do app fica em 100%. Ajuste no DAC ou no volume do Windows.' : 'Volume';
  $('#b-vol').innerHTML = icon((S.volume ?? 1) === 0 ? 'vol-off' : 'vol');
  setRangeFill(vol);
  document.title = t ? `${t.title} — ${t.artist} · Tom Music Player` : 'Tom Music Player';
}

function tick() {
  if (S && !seeking) {
    const p = positionNow();
    const seek = $('#seek');
    seek.value = S.durationMs ? Math.round(p / S.durationMs * 1000) : 0;
    setRangeFill(seek);
    $('#t-pos').textContent = fmtTime(p);
    if ($('#np')) syncLyrics(p);
  }
  requestAnimationFrame(tick);
}

// ---- navegação ---------------------------------------------------------------------------------------
function go(r, push = true) {
  if (push) stack.push({ ...route, scroll: viewEl.scrollTop });
  route = r;
  render();
  viewEl.scrollTop = r.scroll || 0;
}
function back() {
  const r = stack.pop();
  if (r) { route = r; render(); viewEl.scrollTop = r.scroll || 0; }
}

$$('.nav[data-view]').forEach(b => b.onclick = () => { closeOverlays(); stack = []; query = ''; $('#q').value = ''; go({ name: b.dataset.view }, false); });
$('#back').onclick = back;
$('#q').oninput = e => { query = e.target.value.trim().toLowerCase(); render(true); };
$('#sort').onchange = e => { sortBy = e.target.value; render(true); };

function matches(t) {
  if (!query) return true;
  return (t.title + ' ' + t.artist + ' ' + t.album + ' ' + t.albumArtist + ' ' + t.genre).toLowerCase().includes(query);
}

function sorted(list) {
  const l = list.slice();
  if (sortBy === 'title') l.sort((a, b) => collator.compare(a.title, b.title));
  else if (sortBy === 'recent') l.sort((a, b) => b.modified - a.modified);
  else if (sortBy === 'quality') l.sort((a, b) => (b.bits * 1e6 + b.sampleRate) - (a.bits * 1e6 + a.sampleRate) || collator.compare(a.title, b.title));
  return l;
}

const albumKey = t => (t.albumArtist || t.artist) + '\u0001' + t.album;

function albums() {
  const m = new Map();
  for (const t of tracks) {
    const k = albumKey(t);
    let a = m.get(k);
    if (!a) { a = { key: k, name: t.album, artist: t.albumArtist || t.artist, year: t.year, tracks: [] }; m.set(k, a); }
    a.tracks.push(t);
    if (t.year && (!a.year || t.year < a.year)) a.year = t.year;
  }
  const list = [...m.values()];
  for (const a of list) {
    a.tracks.sort((x, y) => (x.discNo - y.discNo) || (x.trackNo - y.trackNo) || collator.compare(x.title, y.title));
    a.cover = (a.tracks.find(t => t.hasCover) || a.tracks[0]).id;
  }
  return list.sort((x, y) => collator.compare(x.name, y.name));
}

function artists() {
  const m = new Map();
  for (const t of tracks) {
    let a = m.get(t.artist);
    if (!a) { a = { name: t.artist, tracks: [], albums: new Set() }; m.set(t.artist, a); }
    a.tracks.push(t);
    a.albums.add(t.album);
  }
  const list = [...m.values()];
  for (const a of list) a.cover = (a.tracks.find(t => t.hasCover) || a.tracks[0]).id;
  return list.sort((x, y) => collator.compare(x.name, y.name));
}

function folders() {
  const m = new Map();
  for (const t of tracks) {
    let f = m.get(t.folder);
    if (!f) { f = { path: t.folder, tracks: [] }; m.set(t.folder, f); }
    f.tracks.push(t);
  }
  return [...m.values()].sort((a, b) => collator.compare(a.path, b.path));
}

function setHeader(title, count, opts = {}) {
  $('#title').textContent = title;
  $('#count').textContent = count || '';
  $('#back').style.display = stack.length ? 'inline-flex' : 'none';
  $('#sort').classList.toggle('hidden', !opts.sort);
  $$('.nav[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === (opts.nav || route.name)));
}

function render(keepScroll) {
  currentList = null;
  const r = route;
  if (!keepScroll) viewEl.scrollTop = 0;
  if (tracks.length === 0 && !['playlists'].includes(r.name)) return renderEmptyLibrary();
  switch (r.name) {
    case 'songs': {
      const list = sorted(tracks.filter(matches));
      setHeader('Músicas', plural(list.length, 'música', 'músicas'), { sort: true });
      viewEl.innerHTML = '<div id="lst"></div>';
      mountList($('#lst'), list, { kind: 'songs' });
      break;
    }
    case 'favorites': {
      const list = favList.map(id => byId.get(id)).filter(Boolean).filter(matches);
      setHeader('Favoritas', plural(list.length, 'música', 'músicas'));
      if (!list.length) { viewEl.innerHTML = `<div class="empty"><b>Nenhuma favorita ainda</b>Use o coração na barra do player ou o menu ⋮ de uma música.</div>`; break; }
      viewEl.innerHTML = `<div class="hero"><div class="info"><div class="actions">
        <button class="btn primary" data-act="playall">${icon('play')}Tocar</button>
        <button class="btn" data-act="shuffleall">${icon('shuffle')}Aleatório</button></div></div></div><div id="lst"></div>`;
      bindHeroActions(list);
      mountList($('#lst'), list, { kind: 'favorites' });
      break;
    }
    case 'playlists': renderPlaylists(); break;
    case 'playlist': renderPlaylist(r.id); break;
    case 'albums': {
      const list = albums().filter(a => !query || (a.name + ' ' + a.artist).toLowerCase().includes(query));
      setHeader('Álbuns', plural(list.length, 'álbum', 'álbuns'));
      viewEl.innerHTML = `<div class="grid">${list.map((a, i) => `
        <div class="card" data-i="${i}" tabindex="0"><img loading="lazy" src="${cover(a.cover)}" ${imgFallback} alt="">
        <b>${esc(a.name)}</b><span>${esc(a.artist)}${a.year ? ' · ' + a.year : ''}</span></div>`).join('')}</div>`;
      $$('.card', viewEl).forEach(c => {
        const open = () => go({ name: 'album', key: list[+c.dataset.i].key });
        c.onclick = open; c.onkeydown = e => e.key === 'Enter' && open();
      });
      break;
    }
    case 'album': {
      const a = albums().find(x => x.key === r.key);
      if (!a) return back();
      setHeader(a.name, '', { nav: 'albums' });
      const dur = a.tracks.reduce((s, t) => s + t.durationMs, 0);
      viewEl.innerHTML = heroHtml('Álbum', a.name, `${esc(a.artist)}${a.year ? ' · ' + a.year : ''} · ${plural(a.tracks.length, 'música', 'músicas')} · ${fmtTime(dur)} · ${esc(quality(a.tracks[0]))}`, cover(a.cover)) + '<div id="lst"></div>';
      bindHeroActions(a.tracks);
      mountList($('#lst'), a.tracks, { kind: 'album', showTrackNo: true });
      break;
    }
    case 'artists': {
      const list = artists().filter(a => !query || a.name.toLowerCase().includes(query));
      setHeader('Artistas', plural(list.length, 'artista', 'artistas'));
      viewEl.innerHTML = `<div class="grid">${list.map((a, i) => `
        <div class="card round" data-i="${i}" tabindex="0"><img loading="lazy" src="${cover(a.cover)}" ${imgFallback} alt="">
        <b>${esc(a.name)}</b><span>${plural(a.albums.size, 'álbum', 'álbuns')} · ${plural(a.tracks.length, 'música', 'músicas')}</span></div>`).join('')}</div>`;
      $$('.card', viewEl).forEach(c => {
        const open = () => go({ name: 'artist', artist: list[+c.dataset.i].name });
        c.onclick = open; c.onkeydown = e => e.key === 'Enter' && open();
      });
      break;
    }
    case 'artist': {
      const all = tracks.filter(t => t.artist === r.artist);
      if (!all.length) return back();
      const albs = albums().filter(a => a.tracks.some(t => t.artist === r.artist));
      setHeader(r.artist, '', { nav: 'artists' });
      viewEl.innerHTML = heroHtml('Artista', r.artist, `${plural(albs.length, 'álbum', 'álbuns')} · ${plural(all.length, 'música', 'músicas')}`, cover((all.find(t => t.hasCover) || all[0]).id), true) +
        `<div class="section-title">Álbuns</div><div class="grid">${albs.map((a, i) => `
        <div class="card" data-i="${i}" tabindex="0"><img loading="lazy" src="${cover(a.cover)}" ${imgFallback} alt=""><b>${esc(a.name)}</b><span>${a.year || ''}</span></div>`).join('')}</div>
        <div class="section-title">Músicas</div><div id="lst"></div>`;
      $$('.card', viewEl).forEach(c => c.onclick = () => go({ name: 'album', key: albs[+c.dataset.i].key }));
      const list = albs.flatMap(a => a.tracks.filter(t => t.artist === r.artist));
      bindHeroActions(list);
      mountList($('#lst'), list, { kind: 'artist' });
      break;
    }
    case 'folders': {
      const list = folders().filter(f => !query || f.path.toLowerCase().includes(query));
      setHeader('Pastas', plural(list.length, 'pasta', 'pastas'));
      viewEl.innerHTML = `<div class="lines">${list.map((f, i) => `
        <div class="line" data-i="${i}" tabindex="0"><div class="ic">${icon('folder')}</div>
        <div class="tx"><b>${esc(f.path.split(/[\\/]/).pop() || f.path)}</b><span>${esc(f.path)} · ${plural(f.tracks.length, 'música', 'músicas')}</span></div></div>`).join('')}</div>`;
      $$('.line', viewEl).forEach(c => c.onclick = () => go({ name: 'folder', path: list[+c.dataset.i].path }));
      break;
    }
    case 'folder': {
      const f = folders().find(x => x.path === r.path);
      if (!f) return back();
      const list = f.tracks.slice().sort((a, b) => (a.discNo - b.discNo) || (a.trackNo - b.trackNo) || collator.compare(a.path, b.path)).filter(matches);
      setHeader(f.path.split(/[\\/]/).pop() || f.path, plural(list.length, 'música', 'músicas'), { nav: 'folders' });
      viewEl.innerHTML = `<div class="hero"><div class="info"><div class="meta">${esc(f.path)}</div><div class="actions">
        <button class="btn primary" data-act="playall">${icon('play')}Tocar</button>
        <button class="btn" data-act="shuffleall">${icon('shuffle')}Aleatório</button></div></div></div><div id="lst"></div>`;
      bindHeroActions(list);
      mountList($('#lst'), list, { kind: 'folder' });
      break;
    }
  }
}

function renderEmptyLibrary() {
  setHeader(route.name === 'songs' ? 'Músicas' : $('#title').textContent, '');
  const scanning = S?.scanning;
  viewEl.innerHTML = `<div class="empty">
    <img src="icon.png" alt="" style="width:120px;border-radius:50%;margin-bottom:18px">
    <b>${scanning ? 'Procurando suas músicas…' : 'Nenhuma música encontrada'}</b>
    ${scanning ? 'Isso leva alguns segundos na primeira vez.' : `Escolha as pastas onde estão suas músicas (FLAC, WAV, AIFF, ALAC, MP3, AAC, OGG).<br><br>
    <button class="btn primary" id="empty-add">${icon('plus')}Adicionar pasta de músicas</button>`}
  </div>`;
  const b = $('#empty-add');
  if (b) b.onclick = pickFolder;
}

function heroHtml(kind, title, meta, img, round) {
  return `<div class="hero"><img src="${img}" ${imgFallback} alt="" style="${round ? 'border-radius:50%' : ''}">
    <div class="info"><div class="kind">${kind}</div><h2>${esc(title)}</h2><div class="meta">${meta}</div>
    <div class="actions"><button class="btn primary" data-act="playall">${icon('play')}Tocar</button>
    <button class="btn" data-act="shuffleall">${icon('shuffle')}Aleatório</button>
    <button class="btn" data-act="addpl">${icon('playlist')}Adicionar à playlist</button>
    <button class="btn" data-act="queueall">${icon('next-q')}Adicionar à fila</button></div></div></div>`;
}

function bindHeroActions(list) {
  const ids = () => list.map(t => t.id);
  const b = a => $(`[data-act="${a}"]`, viewEl);
  if (b('playall')) b('playall').onclick = () => playIds(ids(), 0, false);
  if (b('shuffleall')) b('shuffleall').onclick = () => playIds(ids(), Math.floor(Math.random() * list.length), true);
  if (b('addpl')) b('addpl').onclick = e => playlistMenu(e.currentTarget, ids());
  if (b('queueall')) b('queueall').onclick = async () => { await api('queue/add', { ids: ids() }); toast(plural(list.length, 'música adicionada', 'músicas adicionadas') + ' à fila'); };
}

async function playIds(ids, index, shuffle) {
  if (!ids.length) return;
  if (shuffle !== undefined && S && S.shuffle !== shuffle) await api('shuffle', { on: shuffle });
  await api('play', { ids, index });
}

// ---- lista virtual de músicas ----------------------------------------------------------------------------
function mountList(el, list, ctx) {
  el.innerHTML = `<div class="list-head"><span style="text-align:right">#</span><span></span><span>Título</span>
    <span class="c-album">Álbum</span><span class="c-q">Qualidade</span><span style="text-align:right">Duração</span><span></span></div>
    <div class="vlist" style="height:${list.length * ROW}px"></div>`;
  const vl = $('.vlist', el);
  let range = '';
  const lst = {
    list, ctx,
    render(force) {
      const top = viewEl.scrollTop - vl.offsetTop;
      const start = Math.max(0, Math.floor(top / ROW) - 8);
      const end = Math.min(list.length, Math.ceil((top + viewEl.clientHeight) / ROW) + 8);
      const key = start + ':' + end;
      if (key === range && !force) return;
      range = key;
      let html = '';
      for (let i = start; i < end; i++) html += rowHtml(list[i], i, ctx);
      vl.innerHTML = html;
    },
  };
  vl.onclick = e => {
    const row = e.target.closest('.row');
    if (!row) return;
    const i = +row.dataset.i;
    if (e.target.closest('.more')) return trackMenu(e.target.closest('.more'), list[i], ctx, i);
    if (e.target.closest('.num') || e.target.closest('.thumb')) playIds(list.map(t => t.id), i);
  };
  vl.ondblclick = e => {
    const row = e.target.closest('.row');
    if (row && !e.target.closest('.more')) playIds(list.map(t => t.id), +row.dataset.i);
  };
  vl.oncontextmenu = e => {
    const row = e.target.closest('.row');
    if (!row) return;
    e.preventDefault();
    trackMenu({ x: e.clientX, y: e.clientY }, list[+row.dataset.i], ctx, +row.dataset.i);
  };
  vl.onkeydown = e => {
    const row = e.target.closest('.row');
    if (row && e.key === 'Enter') playIds(list.map(t => t.id), +row.dataset.i);
  };
  currentList = lst;
  lst.render(true);
}
viewEl.addEventListener('scroll', () => currentList && currentList.render());
window.addEventListener('resize', () => currentList && currentList.render(true));

function rowHtml(t, i, ctx) {
  const playing = S && S.trackId === t.id;
  const num = playing ? `<span class="eq-bars"><i></i><i></i><i></i></span>` : (ctx.showTrackNo && t.trackNo ? t.trackNo : i + 1);
  return `<div class="row${playing ? ' playing' : ''}${playing && !S.playing ? ' paused' : ''}" data-i="${i}" style="top:${i * ROW}px" tabindex="0" title="Duplo clique para tocar">
    <span class="num" title="Tocar">${num}</span>
    <img class="thumb" loading="lazy" src="${cover(t.id)}" ${imgFallback} alt="" title="Tocar">
    <div class="tt"><div class="t-title">${favorites.has(t.id) ? '<span style="color:var(--accent)">♥</span> ' : ''}${esc(t.title)}</div><span>${esc(t.artist)}</span></div>
    <span class="sub c-album">${esc(t.album)}</span>
    <span class="q c-q${isHiRes(t) ? ' hires' : ''}">${esc(quality(t))}</span>
    <span class="dur">${fmtTime(t.durationMs)}</span>
    <button class="icon-btn more" title="Mais opções">${icon('more')}</button>
  </div>`;
}

// ---- menus ---------------------------------------------------------------------------------------
function closeMenu() { $('#menu')?.remove(); }
function openMenu(anchor, items) {
  closeMenu();
  const m = document.createElement('div');
  m.id = 'menu';
  m.innerHTML = items.map((it, i) => it.sep ? '<div class="sep"></div>' : it.label && !it.action ? `<div class="label">${esc(it.label)}</div>`
    : `<button data-i="${i}">${it.icon ? icon(it.icon) : '<svg></svg>'}<span>${esc(it.text)}</span></button>`).join('');
  document.body.appendChild(m);
  let x, y;
  if (anchor instanceof Element) { const r = anchor.getBoundingClientRect(); x = r.right - m.offsetWidth; y = r.bottom + 4; }
  else { x = anchor.x; y = anchor.y; }
  x = Math.max(8, Math.min(x, innerWidth - m.offsetWidth - 8));
  if (y + m.offsetHeight > innerHeight - 8) y = Math.max(8, innerHeight - m.offsetHeight - 8);
  m.style.left = x + 'px'; m.style.top = y + 'px';
  m.onclick = e => {
    const b = e.target.closest('button');
    if (!b) return;
    closeMenu();
    items[+b.dataset.i].action();
  };
  $('button', m)?.focus();
}
document.addEventListener('mousedown', e => { if (!e.target.closest('#menu')) closeMenu(); });

function trackMenu(anchor, t, ctx, index) {
  const fav = favorites.has(t.id);
  const items = [
    { text: 'Tocar agora', icon: 'play', action: () => playIds([t.id], 0) },
    { text: 'Tocar a seguir', icon: 'next-q', action: async () => { await api('queue/next', { ids: [t.id] }); toast('Vai tocar a seguir'); } },
    { text: 'Adicionar à fila', icon: 'queue', action: async () => { await api('queue/add', { ids: [t.id] }); toast('Adicionada à fila'); } },
    { text: fav ? 'Remover das favoritas' : 'Favoritar', icon: fav ? 'heart' : 'heart-o', action: () => toggleFav(t.id) },
    { sep: true },
    { text: 'Adicionar à playlist…', icon: 'playlist', action: () => playlistMenu(anchor, [t.id]) },
  ];
  if (ctx.kind === 'playlist') {
    items.push(
      { text: 'Remover desta playlist', icon: 'trash', action: async () => { await loadStore(await api(`playlists/${ctx.playlistId}/remove`, { index })); render(true); } },
      { text: 'Mover para cima', icon: 'up', action: async () => { await loadStore(await api(`playlists/${ctx.playlistId}/move`, { from: index, to: index - 1 })); render(true); } },
      { text: 'Mover para baixo', icon: 'down', action: async () => { await loadStore(await api(`playlists/${ctx.playlistId}/move`, { from: index, to: index + 1 })); render(true); } },
    );
  }
  items.push(
    { sep: true },
    { text: 'Ir para o álbum', icon: 'album', action: () => go({ name: 'album', key: albumKey(t) }) },
    { text: 'Ir para o artista', icon: 'artist', action: () => go({ name: 'artist', artist: t.artist }) },
    { text: 'Analisar espectro', icon: 'chart', action: () => openAnalyzer(t.id) },
    { text: 'Mostrar no Explorador de Arquivos', icon: 'open', action: () => api('reveal/' + t.id, {}) },
  );
  openMenu(anchor, items);
}

function playlistMenu(anchor, ids) {
  const items = [
    { text: 'Nova playlist…', icon: 'plus', action: async () => {
      const name = await prompt2('Nova playlist', 'Nome da playlist', '');
      if (name == null) return;
      await loadStore(await api('playlists', { name, ids }));
      toast(`Playlist "${name || 'Nova playlist'}" criada`);
      if (route.name === 'playlists') render(true);
    } },
  ];
  if (playlists.length) items.push({ sep: true });
  for (const p of playlists) items.push({ text: p.name, icon: 'playlist', action: async () => {
    await loadStore(await api(`playlists/${p.id}/add`, { ids }));
    toast(`${plural(ids.length, 'música adicionada', 'músicas adicionadas')} a "${p.name}"`);
  } });
  openMenu(anchor, items);
}

async function toggleFav(id) {
  await loadStore(await api('favorite', { id, on: !favorites.has(id) }));
  updateBar();
  if (route.name === 'favorites') render(true);
  else if (currentList) currentList.render(true);
  if ($('#np')) renderNowPlaying(false);
}

function prompt2(title, label, value) {
  return new Promise(resolve => {
    const d = document.createElement('div');
    d.id = 'dialog';
    d.innerHTML = `<div class="box"><h3>${esc(title)}</h3><input class="text-in" style="width:100%" placeholder="${esc(label)}" value="${esc(value)}">
      <div class="acts"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">Salvar</button></div></div>`;
    document.body.appendChild(d);
    const inp = $('input', d);
    inp.focus(); inp.select();
    const done = v => { d.remove(); resolve(v); };
    d.onclick = e => { const a = e.target.closest('[data-a]')?.dataset.a; if (a === 'ok') done(inp.value.trim()); else if (a === 'no' || e.target === d) done(null); };
    inp.onkeydown = e => { if (e.key === 'Enter') done(inp.value.trim()); if (e.key === 'Escape') done(null); };
  });
}

function confirm2(title, text, okText) {
  return new Promise(resolve => {
    const d = document.createElement('div');
    d.id = 'dialog';
    d.innerHTML = `<div class="box"><h3>${esc(title)}</h3><div class="muted">${esc(text)}</div>
      <div class="acts"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">${esc(okText)}</button></div></div>`;
    document.body.appendChild(d);
    $('[data-a="ok"]', d).focus();
    d.onclick = e => { const a = e.target.closest('[data-a]')?.dataset.a; if (a) { d.remove(); resolve(a === 'ok'); } else if (e.target === d) { d.remove(); resolve(false); } };
  });
}

// ---- playlists ---------------------------------------------------------------------------------------
function renderPlaylists() {
  setHeader('Playlists', plural(playlists.length, 'playlist', 'playlists'));
  viewEl.innerHTML = `<div class="hero"><div class="info"><div class="actions">
    <button class="btn primary" id="pl-new">${icon('plus')}Nova playlist</button>
    <button class="btn" id="pl-queue">${icon('queue')}Salvar a fila atual como playlist</button></div></div></div>
    ${playlists.length ? '' : '<div class="empty"><b>Nenhuma playlist</b>Crie uma aqui ou use o menu ⋮ de uma música.</div>'}
    <div class="lines">${playlists.map((p, i) => {
      const first = p.trackIds.map(id => byId.get(id)).find(Boolean);
      const dur = p.trackIds.reduce((s, id) => s + (byId.get(id)?.durationMs || 0), 0);
      return `<div class="line" data-i="${i}" tabindex="0">${first ? `<img src="${cover(first.id)}" ${imgFallback} style="width:44px;height:44px;border-radius:10px;object-fit:cover" alt="">` : `<div class="ic">${icon('playlist')}</div>`}
      <div class="tx"><b>${esc(p.name)}</b><span>${plural(p.trackIds.length, 'música', 'músicas')} · ${fmtTime(dur)}</span></div></div>`;
    }).join('')}</div>`;
  $('#pl-new').onclick = async () => {
    const name = await prompt2('Nova playlist', 'Nome da playlist', '');
    if (name == null) return;
    await loadStore(await api('playlists', { name }));
    render(true);
  };
  $('#pl-queue').onclick = saveQueueAsPlaylist;
  $$('.line', viewEl).forEach(l => l.onclick = () => go({ name: 'playlist', id: playlists[+l.dataset.i].id }));
}

async function saveQueueAsPlaylist() {
  if (!S || !S.queue.length) return toast('A fila está vazia');
  const name = await prompt2('Salvar fila como playlist', 'Nome da playlist', '');
  if (name == null) return;
  await loadStore(await api('playlists', { name, ids: S.queue }));
  toast('Playlist criada');
  if (route.name === 'playlists') render(true);
}

function renderPlaylist(id) {
  const p = playlists.find(x => x.id === id);
  if (!p) return back();
  const list = p.trackIds.map(i => byId.get(i)).filter(Boolean);
  setHeader(p.name, '', { nav: 'playlists' });
  const first = list.find(t => t.hasCover) || list[0];
  const dur = list.reduce((s, t) => s + t.durationMs, 0);
  viewEl.innerHTML = `<div class="hero"><img src="${first ? cover(first.id) : DEFAULT_COVER}" ${imgFallback} alt="">
    <div class="info"><div class="kind">Playlist</div><h2>${esc(p.name)}</h2><div class="meta">${plural(list.length, 'música', 'músicas')} · ${fmtTime(dur)}</div>
    <div class="actions"><button class="btn primary" data-act="playall">${icon('play')}Tocar</button>
    <button class="btn" data-act="shuffleall">${icon('shuffle')}Aleatório</button>
    <button class="btn" id="pl-rename">${icon('edit')}Renomear</button>
    <button class="btn" id="pl-delete">${icon('trash')}Excluir</button></div></div></div>
    ${list.length ? '<div id="lst"></div>' : '<div class="empty"><b>Playlist vazia</b>Adicione músicas pelo menu ⋮ ou pela tela de um álbum.</div>'}`;
  bindHeroActions(list);
  $('#pl-rename').onclick = async () => {
    const name = await prompt2('Renomear playlist', 'Nome', p.name);
    if (!name) return;
    await loadStore(await api(`playlists/${p.id}/rename`, { name }));
    render(true);
  };
  $('#pl-delete').onclick = async () => {
    if (!await confirm2('Excluir playlist', `Excluir "${p.name}"? As músicas continuam na biblioteca.`, 'Excluir')) return;
    await loadStore(await api(`playlists/${p.id}/delete`, {}));
    back();
  };
  if (list.length) mountList($('#lst'), list, { kind: 'playlist', playlistId: p.id });
}

// ---- Tocando agora ----------------------------------------------------------------------------------------
function closeOverlays(except) {
  $$('.overlay').forEach(o => { if (o.id !== except) o.remove(); });
  if (except !== 'queue') $('#queue')?.remove();
}

function overlay(id, title, actions = '') {
  closeOverlays(id);
  let o = $('#' + id);
  if (!o) {
    o = document.createElement('div');
    o.id = id;
    o.className = 'overlay';
    o.innerHTML = `<div class="ohead"><button class="icon-btn" data-close title="Fechar (Esc)">${icon('down')}</button><h2>${esc(title)}</h2>${actions}</div><div class="obody"></div>`;
    $('#overlays').appendChild(o);
    $('[data-close]', o).onclick = () => o.remove();
  }
  return o;
}

function openNowPlaying() {
  if (!S || !S.trackId) return toast('Nenhuma música tocando');
  const o = overlay('np', 'Tocando agora', `
    <button class="icon-btn" id="np-an" title="Analisar espectro">${icon('chart')}</button>
    <button class="icon-btn" id="np-eq" title="Equalizador e Palco">${icon('eq')}</button>
    <button class="icon-btn" id="np-q" title="Fila">${icon('queue')}</button>`);
  $('#np-an').onclick = () => S.trackId && openAnalyzer(S.trackId);
  $('#np-eq').onclick = openEq;
  $('#np-q').onclick = toggleQueue;
  npTab = null;
  renderNowPlaying(true);
  void o;
}

async function loadExtras() {
  if (!S?.trackId) return;
  const id = S.trackId;
  extrasFor = id;
  try {
    const d = await api(`track/${id}/extras`);
    if (extrasFor !== id) return;
    extras = d;
    if ($('#np')) renderNowPlaying(true);
  } catch (e) { console.error(e); }
}

function renderNowPlaying(full) {
  const o = $('#np');
  if (!o) return;
  const t = byId.get(S.trackId);
  if (!t) { o.remove(); return; }
  const body = $('.obody', o);
  if (full || !$('.np-art', body)) {
    if (!npTab) npTab = extras?.lyrics ? 'lyrics' : 'chain';
    body.innerHTML = `
      <div class="np-art"><img id="np-img" src="${cover(t.id)}" alt=""></div>
      <div>
        <div class="np-title">${esc(t.title)}</div>
        <div class="np-sub">${esc(t.artist)} · ${esc(t.album)}${t.year ? ' · ' + t.year : ''}</div>
        <div class="np-row">
          <button class="icon-btn${favorites.has(t.id) ? ' on' : ''}" id="np-fav" title="Favoritar">${icon(favorites.has(t.id) ? 'heart' : 'heart-o')}</button>
          <span class="badge${isHiRes(t) ? ' hires' : ''}">${esc(quality(t))}${t.channels ? ' · ' + (t.channels === 1 ? 'mono' : t.channels === 2 ? 'estéreo' : t.channels + ' canais') : ''}</span>
          ${t.genre ? `<span class="badge">${esc(t.genre)}</span>` : ''}
        </div>
        <div class="origin" id="np-origin" title="Clique para ver em qual tag a origem foi encontrada">${extras ? `Origem: <b>${esc(extras.origin.name)}</b>` : 'Origem: …'}</div>
        <div class="np-tabs">
          <button class="chip${npTab === 'lyrics' ? ' on' : ''}" data-tab="lyrics">Letra</button>
          <button class="chip${npTab === 'chain' ? ' on' : ''}" data-tab="chain">Cadeia de áudio</button>
          <button class="chip${npTab === 'tags' ? ' on' : ''}" data-tab="tags">Tags do arquivo</button>
        </div>
        <div id="np-panel"></div>
      </div>`;
    const img = $('#np-img');
    img.onerror = () => { img.onerror = null; img.src = DEFAULT_COVER; img.classList.add('disc'); img.classList.toggle('spinning', S.playing); };
    $('#np-fav').onclick = () => toggleFav(t.id);
    $('#np-origin').onclick = () => extras && toast(extras.origin.evidence, 6000);
    $$('[data-tab]', body).forEach(b => b.onclick = () => { npTab = b.dataset.tab; renderNowPlaying(true); });
    renderNpPanel(true);
  } else {
    const img = $('#np-img');
    if (img.classList.contains('disc')) img.classList.toggle('spinning', S.playing);
    renderNpPanel(false);
  }
}

let lyricIndex = -1;
function renderNpPanel(full) {
  const panel = $('#np-panel');
  if (!panel) return;
  const t = byId.get(S.trackId);
  if (npTab === 'lyrics') {
    if (!full) return;
    lyricIndex = -1;
    const l = extras?.lyrics;
    if (!extras) panel.innerHTML = '<div class="muted">Carregando…</div>';
    else if (!l) panel.innerHTML = `<div class="empty" style="padding:30px 0"><b>Sem letra neste arquivo</b>A letra aparece quando está nas tags (LYRICS, USLT, SYLT) ou num arquivo .lrc com o mesmo nome da música.</div>`;
    else if (l.synced) {
      panel.innerHTML = `<div class="lyrics" id="lyr">${l.lines.map((x, i) => `<p data-i="${i}" data-t="${x.timeMs}">${esc(x.text) || '♪'}</p>`).join('')}</div>`;
      $('#lyr').onclick = e => { const p = e.target.closest('p'); if (p) api('seek', { ms: +p.dataset.t }); };
    } else panel.innerHTML = `<div class="lyrics plain"><pre>${esc(l.text)}</pre></div>`;
  } else if (npTab === 'chain') {
    panel.innerHTML = chainHtml(t);
    bindChain(panel);
  } else if (npTab === 'tags') {
    if (!full) return;
    const fields = extras?.fields || [];
    panel.innerHTML = `<div class="chain"><dl class="kv">
      <dt>Arquivo</dt><dd>${esc(t.path)}</dd>
      <dt>Formato</dt><dd>${esc(quality(t))} · ${fmtRate(t.sampleRate)}${t.bitrateKbps ? ' · ' + t.bitrateKbps + ' kbps' : ''}</dd>
      ${extras?.vendor ? `<dt>Gravado por</dt><dd>${esc(extras.vendor)}</dd>` : ''}
      ${fields.map(f => `<dt>${esc(f.key.replace(/^TXXX:|^----:/, ''))}</dt><dd>${esc(f.value)}</dd>`).join('')}
    </dl></div>`;
  }
}

function syncLyrics(pos) {
  const lyr = $('#lyr');
  if (!lyr) return;
  const ps = lyr.children;
  let idx = -1;
  for (let i = 0; i < ps.length; i++) { if (+ps[i].dataset.t <= pos + 150) idx = i; else break; }
  if (idx === lyricIndex) return;
  if (lyricIndex >= 0 && ps[lyricIndex]) ps[lyricIndex].classList.remove('now');
  lyricIndex = idx;
  if (idx >= 0) {
    ps[idx].classList.add('now');
    lyr.scrollTop = ps[idx].offsetTop - lyr.clientHeight / 2 + ps[idx].offsetHeight / 2;
  }
}

function chainHtml(t) {
  const c = S.chain || {};
  const direct = !!c.bitPerfect;
  const fxOn = S.eq?.enabled || S.palcoOn;
  return `<div class="chain">
    <h3>Cadeia de áudio</h3>
    <div class="light${direct ? ' on' : ''}"><i></i>${direct ? 'DAC conectado direto · bit-perfect' : 'Pelo mixer do Windows'}</div>
    <dl class="kv">
      <dt>Saída</dt><dd>${esc(c.device || '—')}${c.deviceKind ? ` <span class="muted">(${esc(c.deviceKind)})</span>` : ''}</dd>
      ${c.adapter && c.adapter !== c.device ? `<dt>Dispositivo</dt><dd>${esc(c.adapter)}</dd>` : ''}
      <dt>Arquivo</dt><dd class="tech">${esc(c.source || quality(t))}</dd>
      <dt>Decodificador</dt><dd>${esc(c.decoder || '—')}</dd>
      <dt>Enviado ao DAC</dt><dd class="tech">${esc(c.output || '—')}</dd>
      <dt>Caminho</dt><dd>${esc(c.path || '—')}</dd>
      <dt>Processamento</dt><dd>${esc(c.processing || '—')}</dd>
      ${c.caps ? `<dt>DAC aceita</dt><dd>${esc(c.caps.replace(/^Aceita no modo exclusivo: /, ''))}</dd>` : ''}
    </dl>
    ${c.reason ? `<div class="note warn">${esc(c.reason)}</div>` : ''}
    ${direct ? '<div class="note">Volume: no bit-perfect o app não mexe no volume. Use o controle do DAC ou do amplificador; em alguns DACs o volume do Windows não tem efeito, então comece baixo.</div>' : ''}
    <div class="switch-row">
      <div class="tx"><b>Bit-perfect (WASAPI exclusivo)</b><span>${fxOn ? 'Desligue o equalizador e o Palco para usar o bit-perfect.' : 'Envia as amostras do arquivo direto ao DAC, sem o mixer do Windows, na taxa e nos bits originais.'}</span></div>
      <label class="sw"><input type="checkbox" id="bp-sw" ${S.bitPerfect && !fxOn ? 'checked' : ''}><span></span></label>
    </div>
    <div class="np-row"><button class="btn" id="go-settings">${icon('settings')}Trocar a saída de áudio</button>
    ${fxOn ? `<button class="btn" id="go-eq">${icon('eq')}Abrir equalizador e Palco</button>` : ''}</div>
  </div>`;
}

function bindChain(root) {
  const sw = $('#bp-sw', root);
  if (sw) sw.onchange = async () => {
    const on = sw.checked;
    if (on && (S.eq?.enabled || S.palcoOn) && !await confirm2('Ligar o bit-perfect', 'O equalizador e o Palco serão desligados, porque alteram o som.', 'Ligar')) { sw.checked = false; return; }
    await api('output', { bitPerfect: on });
  };
  const gs = $('#go-settings', root);
  if (gs) gs.onclick = openSettings;
  const ge = $('#go-eq', root);
  if (ge) ge.onclick = openEq;
}

// ---- fila ----------------------------------------------------------------------------------------------
function toggleQueue() {
  if ($('#queue')) { $('#queue').remove(); return; }
  const q = document.createElement('div');
  q.id = 'queue';
  q.innerHTML = `<div class="ohead" style="display:flex;align-items:center;gap:8px;padding:14px 12px">
    <h2 style="flex:1;margin:0;font-size:18px">Fila</h2>
    <button class="btn" id="q-save">${icon('playlist')}Salvar como playlist</button>
    <button class="icon-btn" id="q-close" title="Fechar">${icon('close')}</button></div><div class="qlist"></div>`;
  document.body.appendChild(q);
  $('#q-close').onclick = () => q.remove();
  $('#q-save').onclick = saveQueueAsPlaylist;
  $('.qlist', q).onclick = e => {
    const it = e.target.closest('.qitem');
    if (!it) return;
    const i = +it.dataset.i;
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'up') api('queue/move', { from: i, to: i - 1 });
    else if (a === 'down') api('queue/move', { from: i, to: i + 1 });
    else if (a === 'rm') api('queue/remove', { index: i });
    else api('jump', { index: i });
  };
  renderQueue();
  $('.qitem.cur', q)?.scrollIntoView({ block: 'center' });
}

function renderQueue() {
  const q = $('#queue');
  if (!q) return;
  const list = $('.qlist', q);
  if (!S.queue.length) { list.innerHTML = '<div class="empty">A fila está vazia</div>'; return; }
  const max = 1500; // filas enormes: mostra as próximas
  const start = Math.max(0, S.index - 50);
  const ids = S.queue.slice(start, start + max);
  list.innerHTML = ids.map((id, k) => {
    const i = start + k, t = byId.get(id);
    return `<div class="qitem${i === S.index ? ' cur' : ''}" data-i="${i}">
      <span class="muted" style="width:28px;text-align:right;font-size:12px">${i === S.index ? '▶' : i + 1}</span>
      <div class="tx" title="Tocar"><b>${esc(t ? t.title : '(arquivo removido)')}</b><span>${esc(t ? t.artist : '')}</span></div>
      <button class="icon-btn" data-a="up" title="Subir">${icon('up')}</button>
      <button class="icon-btn" data-a="down" title="Descer">${icon('down')}</button>
      <button class="icon-btn" data-a="rm" title="Remover da fila">${icon('close')}</button></div>`;
  }).join('');
}

// ---- Equalizador e Palco ----------------------------------------------------------------------------------
const BANDS = [25, 40, 63, 100, 160, 250, 400, 630, 1000, 1600, 2500, 4000, 6300, 10000, 16000];
let presets = [];
let eqDragging = false;
let eqLocal = null, palcoLocal = null;
let eqSendTimer = 0, palcoSendTimer = 0;

async function openEq() {
  if (!presets.length) presets = await api('eq/presets');
  overlay('eqv', 'Equalizador e Palco');
  eqLocal = null; palcoLocal = null;
  renderEq(true);
}

const dbTxt = v => (v > 0 ? '+' : '') + (Number.isInteger(v) ? v : v.toFixed(1));
const bandLabel = hz => hz >= 1000 ? (hz / 1000).toLocaleString('pt-BR') + 'k' : String(hz);
function palcoLabel(w) {
  return w < 0.95 ? 'mais estreito' : w <= 1.05 ? 'original' : w < 1.35 ? 'um pouco mais aberto' : w < 1.65 ? 'aberto' : 'bem aberto';
}

function renderEq(full) {
  const o = $('#eqv');
  if (!o) return;
  const eq = eqLocal || structuredClone(S.eq);
  const palco = palcoLocal || { on: S.palcoOn, amount: S.palcoAmount };
  const body = $('.obody', o);
  const exclusive = S.chain?.bitPerfect;
  if (full || !$('#eq-sw', body)) {
    body.innerHTML = `
      <div class="card-box${eq.enabled ? ' on' : ''}" id="eq-card">
        <div class="head"><div class="tx"><h3 id="eq-st"></h3><div class="note" id="eq-note" style="margin-top:4px"></div></div>
          <label class="sw" title="Liga/desliga o equalizador"><input type="checkbox" id="eq-sw"><span></span></label></div>
      </div>
      <div class="card-box${palco.on ? ' on' : ''}" id="pl-card">
        <div class="head"><div class="tx"><h3>Palco · separação estéreo</h3><div class="muted" id="pl-st" style="font-size:13px;margin-top:2px"></div></div>
          <label class="sw" title="Liga/desliga o Palco"><input type="checkbox" id="pl-sw"><span></span></label></div>
        <div class="chips" id="pl-chips">${[['Sutil', 1.2], ['Amplo', 1.4], ['Máximo', 1.7]].map(([n, v]) => `<button class="chip" data-v="${v}">${n}</button>`).join('')}</div>
        <div class="row-range"><label>Largura</label><input type="range" id="pl-range" min="50" max="200" step="5"><span class="v tech" id="pl-v"></span></div>
        <div class="scale"><span>Estreito</span><span>Original</span><span>Amplo</span></div>
        <div class="note" id="pl-note"></div>
      </div>
      <div class="card-box">
        <h3>Predefinições do equalizador</h3>
        <div class="chips" id="eq-presets">${presets.map(p => `<button class="chip" data-p="${esc(p.name)}">${esc(p.name)}</button>`).join('')}<button class="chip hidden" id="eq-custom">Personalizado</button></div>
        <div class="row-range"><label>Pré-amplificação</label><input type="range" id="eq-pre" min="-12" max="6" step="0.5"><span class="v tech" id="eq-pre-v"></span></div>
        <div style="display:flex;align-items:center;margin-top:16px"><h3 style="flex:1">Bandas (dB)</h3><button class="btn" id="eq-zero">Zerar</button></div>
        <div class="bands">${BANDS.map((hz, i) => `<div class="band"><span class="val tech" id="bv${i}"></span>
          <div class="vwrap"><input type="range" min="-15" max="15" step="0.5" data-b="${i}" aria-label="${bandLabel(hz)} Hz"></div><span class="hz">${bandLabel(hz)}</span></div>`).join('')}</div>
        <div class="note">O limitador segura picos acima de −1 dBFS quando há reforço de bandas. Se ouvir distorção, reduza a pré-amplificação.</div>
      </div>`;
    bindEq(body);
  }
  // valores
  $('#eq-sw').checked = eq.enabled;
  $('#eq-card').classList.toggle('on', eq.enabled);
  $('#eq-st').textContent = eq.enabled ? 'Equalizador ligado · 15 bandas + limitador' : 'Equalizador desligado · sinal puro';
  $('#eq-note').textContent = eq.enabled
    ? 'O som passa pelo equalizador. O bit-perfect fica pausado enquanto ele estiver ligado.'
    : (exclusive ? 'Bit-perfect ativo. Ao ligar o equalizador, o áudio passa a ir pelo mixer do Windows.' : 'Nenhum processamento no caminho do áudio.');
  $$('#eq-presets .chip').forEach(c => c.classList.toggle('on', eq.enabled && c.dataset.p === eq.preset));
  $('#eq-custom').classList.toggle('hidden', eq.preset !== 'Personalizado');
  $('#eq-custom').classList.toggle('on', eq.preset === 'Personalizado' && eq.enabled);
  const pre = $('#eq-pre');
  pre.value = eq.preamp; pre.disabled = !eq.enabled; setRangeFill(pre);
  $('#eq-pre-v').textContent = dbTxt(eq.preamp) + ' dB';
  $$('.band input', o).forEach(r => {
    const i = +r.dataset.b;
    r.value = eq.gains[i]; r.disabled = !eq.enabled;
    setRangeFill(r);
    const v = $('#bv' + i);
    v.textContent = dbTxt(eq.gains[i]);
    v.classList.toggle('set', eq.enabled && eq.gains[i] !== 0);
  });
  $('#eq-zero').disabled = !eq.enabled;

  $('#pl-sw').checked = palco.on;
  $('#pl-card').classList.toggle('on', palco.on);
  $('#pl-st').textContent = palco.on ? `${Math.round(palco.amount * 100)}% · ${palcoLabel(palco.amount)}` : 'Desligado · imagem original';
  const pr = $('#pl-range');
  pr.value = Math.round(palco.amount * 100); pr.disabled = !palco.on; setRangeFill(pr);
  $('#pl-v').textContent = Math.round(palco.amount * 100) + '%';
  $$('#pl-chips .chip').forEach(c => c.classList.toggle('on', palco.on && Math.abs(+c.dataset.v - palco.amount) < 0.01));
  $('#pl-note').textContent = palco.on
    ? 'Afasta os instrumentos para as laterais e destaca a voz no centro. Os graves continuam no centro. O bit-perfect fica pausado enquanto o Palco estiver ligado.'
    : 'Aumenta a sensação de separação entre voz e instrumentos. Melhor percebido em fones de ouvido.';
}

function bindEq(body) {
  const cur = () => eqLocal || (eqLocal = structuredClone(S.eq));
  const send = (immediate) => {
    clearTimeout(eqSendTimer);
    const go = async () => { const st = eqLocal; await api('eq', st); if (eqLocal === st) eqLocal = null; };
    if (immediate) go(); else eqSendTimer = setTimeout(go, 90);
  };
  $('#eq-sw').onchange = e => { cur().enabled = e.target.checked; renderEq(false); send(true); };
  $('#eq-presets').onclick = e => {
    const c = e.target.closest('[data-p]');
    if (!c) return;
    const p = presets.find(x => x.name === c.dataset.p);
    const st = cur();
    st.gains = p.gains.slice();
    st.preset = p.name;
    const maxBoost = Math.max(0, ...p.gains);
    st.preamp = -Math.round(maxBoost / 2);
    st.enabled = true;
    renderEq(false); send(true);
  };
  const pre = $('#eq-pre');
  pre.oninput = () => { cur().preamp = +pre.value; renderEq(false); send(false); };
  $$('.band input', body).forEach(r => {
    r.oninput = () => { const st = cur(); st.gains[+r.dataset.b] = +r.value; st.preset = 'Personalizado'; renderEq(false); send(false); };
    r.onpointerdown = () => eqDragging = true;
    r.onpointerup = () => eqDragging = false;
  });
  $('#eq-zero').onclick = () => { const st = cur(); st.gains = BANDS.map(() => 0); st.preamp = 0; st.preset = 'Plano'; renderEq(false); send(true); };

  const pcur = () => palcoLocal || (palcoLocal = { on: S.palcoOn, amount: S.palcoAmount });
  const psend = (immediate) => {
    clearTimeout(palcoSendTimer);
    const go = async () => { const st = palcoLocal; await api('palco', st); if (palcoLocal === st) palcoLocal = null; };
    if (immediate) go(); else palcoSendTimer = setTimeout(go, 120);
  };
  $('#pl-sw').onchange = e => { pcur().on = e.target.checked; renderEq(false); psend(true); };
  $('#pl-chips').onclick = e => { const c = e.target.closest('[data-v]'); if (!c) return; const st = pcur(); st.on = true; st.amount = +c.dataset.v; renderEq(false); psend(true); };
  const pr = $('#pl-range');
  pr.oninput = () => { pcur().amount = +pr.value / 100; renderEq(false); psend(false); };
  pr.onpointerdown = () => eqDragging = true;
  pr.onpointerup = () => eqDragging = false;
}

// ---- Ajustes ----------------------------------------------------------------------------------------------
let devices = null;
async function openSettings() {
  overlay('settings', 'Ajustes e saída de áudio');
  devices = null;
  renderSettings();
  try { devices = await api('devices'); } catch { devices = { devices: [] }; }
  renderSettings();
}

function renderSettings() {
  const o = $('#settings');
  if (!o) return;
  const body = $('.obody', o);
  const fxOn = S.eq?.enabled || S.palcoOn;
  body.innerHTML = `
    <div class="card-box">
      <h3>Saída de áudio</h3>
      <div class="note" style="margin-bottom:10px">Escolha o DAC ou a placa de som. "Padrão do Windows" acompanha o dispositivo escolhido no Windows.</div>
      <select class="full" id="dev">${devices ? `<option value="">Padrão do Windows</option>${devices.devices.map(d =>
        `<option value="${esc(d.id)}" ${d.id === S.deviceId ? 'selected' : ''}>${esc(d.name)} — ${esc(d.kind)}${d.isDefault ? ' (padrão)' : ''}</option>`).join('')}` : '<option>Carregando…</option>'}</select>
      <div class="switch-row">
        <div class="tx"><b>Bit-perfect (WASAPI exclusivo)</b><span>O app assume o DAC sozinho e envia as amostras do arquivo sem o mixer do Windows, sem reamostragem e sem mudar os bits. Outros programas ficam sem som enquanto o Tom estiver tocando. O volume passa a ser o do DAC ou do amplificador: comece baixo.</span></div>
        <label class="sw"><input type="checkbox" id="set-bp" ${S.bitPerfect && !fxOn ? 'checked' : ''}><span></span></label>
      </div>
      <div class="note" id="set-caps">${esc(S.chain?.caps || '')}</div>
      ${fxOn ? '<div class="note warn">O equalizador ou o Palco está ligado: o bit-perfect fica pausado até você desligá-los.</div>' : ''}
      <div class="note">Se o bit-perfect não ligar: no Windows, abra Configurações › Sistema › Som › seu dispositivo › Propriedades avançadas e marque "Permitir que aplicativos assumam o controle exclusivo".</div>
    </div>
    <div class="card-box">
      <h3>Pastas de música</h3>
      <div id="folders" style="margin-top:8px">${S.folders.length ? S.folders.map(f => `<div class="folder">${icon('folder')}<span>${esc(f)}</span>
        <button class="icon-btn" data-rm="${esc(f)}" title="Remover pasta">${icon('trash')}</button></div>`).join('') : '<div class="muted">Nenhuma pasta escolhida.</div>'}</div>
      <div class="np-row"><button class="btn primary" id="f-pick">${icon('plus')}Adicionar pasta</button>
        <button class="btn" id="f-rescan">${icon('refresh')}Procurar músicas novamente</button></div>
      <div class="np-row"><input class="text-in" id="f-path" placeholder="Ou cole o caminho da pasta, por exemplo D:\\Músicas"><button class="btn" id="f-add">Adicionar</button></div>
      <div class="note">${plural(tracks.length, 'música', 'músicas')} na biblioteca. Formatos: FLAC, WAV, AIFF, ALAC e AAC (.m4a), MP3, OGG e Opus.</div>
    </div>
    <div class="card-box">
      <h3>Aparência</h3>
      <div class="switch-row" style="border:0;margin-top:4px;padding-top:0">
        <div class="tx"><b>Tema escuro</b><span>Fundo escuro com destaques em azul.</span></div>
        <label class="sw"><input type="checkbox" id="set-dark" ${S.dark ? 'checked' : ''}><span></span></label>
      </div>
    </div>
    <div class="card-box">
      <h3>Atalhos</h3>
      <dl class="kv"><dt>Espaço</dt><dd>Tocar / pausar</dd><dt>Ctrl + → / ←</dt><dd>Próxima / anterior</dd>
      <dt>→ / ←</dt><dd>Avançar / voltar 10 segundos</dd><dt>Ctrl + F</dt><dd>Buscar</dd><dt>Teclas de mídia</dt><dd>Funcionam mesmo com a janela em segundo plano</dd></dl>
    </div>`;
  $('#dev').onchange = e => api('output', { deviceId: e.target.value });
  $('#set-bp').onchange = async e => {
    const on = e.target.checked;
    if (on && fxOn && !await confirm2('Ligar o bit-perfect', 'O equalizador e o Palco serão desligados, porque alteram o som.', 'Ligar')) { e.target.checked = false; return; }
    await api('output', { bitPerfect: on });
  };
  $('#set-dark').onchange = e => api('theme', { dark: e.target.checked });
  $('#f-pick').onclick = pickFolder;
  $('#f-rescan').onclick = () => { api('rescan', {}); toast('Procurando músicas…'); };
  $('#f-add').onclick = async () => {
    const r = await api('folders/add', { path: $('#f-path').value });
    if (!r.ok) toast(r.message || 'Pasta não encontrada'); else { toast('Pasta adicionada'); }
  };
  $$('[data-rm]', body).forEach(b => b.onclick = async () => {
    if (!await confirm2('Remover pasta', `Parar de ler músicas de "${b.dataset.rm}"? Os arquivos não são apagados.`, 'Remover')) return;
    await api('folders/remove', { path: b.dataset.rm });
  });
}

let settingsKey = '';
function renderSettingsLive() {
  const key = [S.folders.join('|'), S.bitPerfect, S.dark, S.deviceId, S.eq?.enabled, S.palcoOn, S.chain?.caps].join('#');
  if (key !== settingsKey && document.activeElement?.id !== 'f-path') { settingsKey = key; renderSettings(); }
}

async function pickFolder() {
  try {
    const r = await api('folders/pick', {});
    if (r.path) toast('Pasta adicionada. Lendo as músicas…');
    else if (!r.supported) openSettings();
  } catch { openSettings(); }
}

// ---- Analisador de espectro ------------------------------------------------------------------------------------
let anPoll = 0;
async function openAnalyzer(id) {
  const t = byId.get(id);
  if (!t) return;
  const o = overlay('an', 'Analisador de espectro');
  const body = $('.obody', o);
  body.innerHTML = `<div class="np-title" style="font-size:22px">${esc(t.title)}</div><div class="np-sub">${esc(t.artist)} · ${esc(quality(t))}</div>
    <div id="an-body"><div class="progress"><i id="an-p"></i></div><div class="muted">Decodificando e calculando a FFT de até 5 minutos do arquivo…</div></div>`;
  $('[data-close]', o).onclick = () => { api('analyze/cancel', {}); clearInterval(anPoll); o.remove(); };
  await api('analyze', { id });
  clearInterval(anPoll);
  anPoll = setInterval(async () => {
    if (!$('#an')) return clearInterval(anPoll);
    const d = await api('analyze');
    if (d.trackId !== id) return;
    if (d.running) { const p = $('#an-p'); if (p) p.style.width = (d.progress * 100) + '%'; return; }
    clearInterval(anPoll);
    if (d.error) { $('#an-body').innerHTML = `<div class="note warn" style="font-size:14px">${esc(d.error)}</div>`; return; }
    if (d.result) showReport(d.result, t);
  }, 350);
}

const VERDICT = { authentic: 'Autêntico', suspect: 'Suspeito', fake: 'Falso', lossy: 'Com perdas', inconclusive: 'Inconclusivo' };
function showReport(r, t) {
  const nyq = r.sampleRate / 2;
  const kHz = v => (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' kHz';
  $('#an-body').innerHTML = `
    <div class="verdict ${r.verdict}">${VERDICT[r.verdict] || ''}</div>
    <div style="font-size:18px;font-weight:650;margin-bottom:14px">${esc(r.title)}</div>
    <div class="spec-wrap"><canvas id="spec" width="${r.columns}" height="${r.rows}"></canvas>
      <div class="spec-axis"><span>${kHz(nyq)}</span><span>${kHz(nyq * 0.75)}</span><span>${kHz(nyq / 2)}</span><span>${kHz(nyq / 4)}</span><span>0</span></div>
      ${r.abrupt ? `<div class="spec-cut" style="top:${(1 - r.cutoffHz / nyq) * 100}%"><span>corte em ${kHz(r.cutoffHz)}</span></div>` : ''}
    </div>
    <ul style="line-height:1.8;margin-top:16px">${r.details.map(d => `<li>${esc(d)}</li>`).join('')}</ul>
    <dl class="kv"><dt>Formato</dt><dd>${esc(r.codec)} · ${fmtRate(r.sampleRate)} · ${r.channels === 1 ? 'mono' : r.channels + ' canais'}</dd>
      <dt>Bits</dt><dd>${r.declaredBits ? r.declaredBits + ' declarados' : '—'}${r.effectiveBits ? ' · ' + r.effectiveBits + ' em uso de verdade' : ''}</dd>
      <dt>Trecho analisado</dt><dd>${fmtTime(r.analyzedSeconds * 1000)}</dd></dl>
    <div class="note">Análise técnica indicativa: gravações antigas ou masterizações com poucos agudos também podem ter corte baixo. O app só aponta "falso" quando o corte é abrupto, como fazem os codificadores com perdas.</div>`;
  const cv = $('#spec');
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(r.columns, r.rows);
  const bytes = Uint8Array.from(atob(r.image), c => c.charCodeAt(0));
  const stops = [[0, 0, 0, 0], [0.25, 20, 30, 110], [0.5, 130, 30, 140], [0.75, 240, 110, 40], [1, 255, 245, 160]];
  const lut = new Uint8Array(256 * 3);
  for (let v = 0; v < 256; v++) {
    const tt = v / 255;
    let i = 1; while (i < stops.length - 1 && tt > stops[i][0]) i++;
    const a = stops[i - 1], b = stops[i], f = (tt - a[0]) / (b[0] - a[0]);
    for (let k = 0; k < 3; k++) lut[v * 3 + k] = a[k + 1] + (b[k + 1] - a[k + 1]) * f;
  }
  for (let i = 0; i < bytes.length; i++) {
    const v = bytes[i];
    img.data[i * 4] = lut[v * 3]; img.data[i * 4 + 1] = lut[v * 3 + 1]; img.data[i * 4 + 2] = lut[v * 3 + 2]; img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
}

// ---- controles --------------------------------------------------------------------------------------------
$('#b-play').onclick = () => api('toggle', {});
$('#b-next').onclick = () => api('next', {});
$('#b-prev').onclick = () => api('prev', {});
$('#b-shuffle').onclick = () => api('shuffle', { on: !S.shuffle });
$('#b-repeat').onclick = () => api('repeat', { mode: (S.repeat + 1) % 3 });
$('#b-queue').onclick = toggleQueue;
$('#b-lyrics').onclick = () => $('#np') ? $('#np').remove() : openNowPlaying();
$('#bar-now').onclick = e => { if (!e.target.closest('#bar-fav')) ($('#np') ? $('#np').remove() : openNowPlaying()); };
$('#bar-fav').onclick = () => S?.trackId && toggleFav(S.trackId);
$('#badge').onclick = () => { openNowPlaying(); npTab = 'chain'; renderNowPlaying(true); };
$('#nav-eq').onclick = openEq;
$('#nav-settings').onclick = openSettings;
$('#nav-theme').onclick = () => api('theme', { dark: !S.dark });
$('#b-vol').onclick = () => { if (!S.chain?.exclusive) api('volume', { value: S.volume > 0 ? 0 : 1 }); };

const seekEl = $('#seek');
seekEl.oninput = () => { seeking = true; setRangeFill(seekEl); $('#t-pos').textContent = fmtTime(seekEl.value / 1000 * (S?.durationMs || 0)); };
seekEl.onchange = async () => {
  const ms = Math.round(seekEl.value / 1000 * (S?.durationMs || 0));
  await api('seek', { ms });
  seeking = false;
};
const volEl = $('#vol');
let volTimer = 0;
volEl.oninput = () => { setRangeFill(volEl); clearTimeout(volTimer); volTimer = setTimeout(() => api('volume', { value: volEl.value / 100 }), 60); };

document.addEventListener('keydown', e => {
  const typing = e.target.closest('input[type=text], input:not([type]), textarea, select') || e.target.classList?.contains('text-in');
  if (e.key === 'Escape') {
    if ($('#menu')) return closeMenu();
    if ($('#dialog')) return;
    const ovs = $$('.overlay');
    if ($('#queue')) return $('#queue').remove();
    if (ovs.length) { const last = ovs[ovs.length - 1]; if (last.id === 'an') api('analyze/cancel', {}); return last.remove(); }
    if (stack.length) return back();
  }
  if (typing) return;
  if (e.code === 'Space' && !e.target.closest('button, input[type=range]')) { e.preventDefault(); api('toggle', {}); }
  else if (e.ctrlKey && e.key === 'ArrowRight') { e.preventDefault(); api('next', {}); }
  else if (e.ctrlKey && e.key === 'ArrowLeft') { e.preventDefault(); api('prev', {}); }
  else if (!e.ctrlKey && e.key === 'ArrowRight' && !e.target.closest('input[type=range]')) api('seek', { ms: positionNow() + 10000 });
  else if (!e.ctrlKey && e.key === 'ArrowLeft' && !e.target.closest('input[type=range]')) api('seek', { ms: Math.max(0, positionNow() - 10000) });
  else if (e.ctrlKey && e.key.toLowerCase() === 'f') { e.preventDefault(); $('#q').focus(); }
});

// ---- início ---------------------------------------------------------------------------------------------
(async function start() {
  setTimeout(() => { $('#splash').classList.add('out'); setTimeout(() => $('#splash')?.remove(), 450); }, 2000);
  await loadStore();
  try { onState(await api('state')); } catch (e) { console.error(e); }
  connect();
  requestAnimationFrame(tick);
})();
