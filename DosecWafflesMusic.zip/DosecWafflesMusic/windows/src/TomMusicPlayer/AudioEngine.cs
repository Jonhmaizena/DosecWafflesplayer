using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace TomMusic;

/// <summary>Um dispositivo de saída de áudio do Windows.</summary>
public sealed class OutputDevice
{
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public string Adapter { get; init; } = "";
    public string Kind { get; init; } = "";        // "DAC USB", "Bluetooth", "HDMI", "Interno"...
    public bool IsDefault { get; init; }
}

/// <summary>O que a saída sabe fazer no modo exclusivo (bit-perfect).</summary>
public sealed class DeviceCaps
{
    public int MaxRate { get; init; }
    public int MaxBits { get; init; }
    public List<int> Rates { get; init; } = new();
    public string Summary { get; init; } = "";
}

/// <summary>Acesso aos dispositivos (WASAPI no Windows; uma saída simulada nos testes).</summary>
public interface IDeviceBackend
{
    List<OutputDevice> List();
    OutputDevice? Resolve(string id);
    WaveFormat MixFormat(OutputDevice d);
    bool SupportsExclusive(OutputDevice d, WaveFormat f);
    IWavePlayer Create(OutputDevice d, bool exclusive);
    DeviceCaps Caps(OutputDevice d);
    event Action? DevicesChanged;
}

/// <summary>Como o áudio está saindo agora, para o painel "Cadeia de áudio".</summary>
public sealed class ChainInfo
{
    public string Device { get; set; } = "";
    public string DeviceKind { get; set; } = "";
    public string Adapter { get; set; } = "";
    public bool Exclusive { get; set; }
    public bool BitPerfect { get; set; }
    public string Source { get; set; } = "";
    public string Output { get; set; } = "";
    public string Decoder { get; set; } = "";
    public string Path { get; set; } = "";
    public string Reason { get; set; } = "";
    public string Processing { get; set; } = "";
    public int MixRate { get; set; }
    public string Caps { get; set; } = "";
}

/// <summary>
/// Motor de áudio. No modo bit-perfect usa o WASAPI exclusivo: as amostras do arquivo vão ao DAC
/// sem passar pelo mixer do Windows, na taxa e nos bits originais. Com equalizador ou Palco
/// ligados (ou quando o DAC não aceita o formato), toca pelo mixer do Windows em 32-bit float.
/// </summary>
public sealed class AudioEngine : IDisposable
{
    readonly IDeviceBackend backend;
    readonly DspState dsp;
    readonly object gate = new();

    IWavePlayer? output;
    int generation;
    IChain? chain;
    Track? current;
    bool playing;
    int recoveries;

    public string DeviceId { get; set; } = "";
    public bool WantExclusive { get; set; } = true;
    /// <summary>Qual faixa vem depois desta (respeitando fila, aleatório e repetir).</summary>
    public Func<Track, Track?>? NextAfter { get; set; }
    public event Action<Track>? Advanced;
    public event Action? Ended;
    public event Action<Track, string>? Failed;
    public event Action? InfoChanged;

    public ChainInfo Info { get; private set; } = new();

    public AudioEngine(IDeviceBackend backend, DspState dsp)
    {
        this.backend = backend;
        this.dsp = dsp;
        backend.DevicesChanged += () => Task.Run(OnDevicesChanged);
    }

    public Track? Current => Volatile.Read(ref current);
    public bool IsPlaying { get { lock (gate) return playing && output != null; } }

    public long PositionMs
    {
        get
        {
            lock (gate)
            {
                if (chain == null) return 0;
                return Math.Max(0, chain.PositionMs - (playing ? chain.LatencyMs : 0));
            }
        }
    }

    public List<OutputDevice> Devices() => backend.List();

    /// <summary>Começa a tocar uma faixa. Devolve false (e avisa por <see cref="Failed"/>) se o arquivo não abrir.</summary>
    public bool Play(Track t, long startMs, bool autoplay)
    {
        Log($"play {t.Title} at {startMs}");
        lock (gate)
        {
            StopOutput();
            current = t;
            var pipe = TrackPipe.TryOpen(t, out var error);
            if (pipe == null)
            {
                current = null;
                chain = null;
                Info = new ChainInfo { Reason = error };
                Task.Run(() => Failed?.Invoke(t, error));
                return false;
            }
            if (startMs > 0) pipe.Seek(startMs);
            return Start(pipe, autoplay);
        }
    }

    bool Start(TrackPipe pipe, bool autoplay)
    {
        var device = backend.Resolve(DeviceId);
        if (device == null)
        {
            pipe.Dispose();
            Info = new ChainInfo { Reason = "Nenhuma saída de áudio encontrada" };
            Task.Run(() => Failed?.Invoke(pipe.Track, "Nenhuma saída de áudio encontrada no Windows"));
            return false;
        }

        var info = new ChainInfo
        {
            Device = device.Name,
            DeviceKind = device.Kind,
            Adapter = device.Adapter,
            Decoder = pipe.Decoder,
            Source = Describe(pipe.Reader.WaveFormat, pipe.Track),
        };
        // Capacidades do DAC no modo exclusivo (testadas uma vez por dispositivo, antes de abrir a saída)
        try { info.Caps = backend.Caps(device).Summary; } catch { }

        IChain? newChain = null;
        bool exclusive = false;
        string reason = "";
        if (WantExclusive && !dsp.Active)
        {
            var plan = ExclusivePlan.For(backend, device, pipe.Reader.WaveFormat);
            if (plan != null)
            {
                try
                {
                    var excl = new ExclusiveChain(pipe, plan, this);
                    var player = backend.Create(device, exclusive: true);
                    player.Init(excl);
                    Attach(player);
                    newChain = excl;
                    exclusive = true;
                    info.Output = Describe(plan.Output) + (plan.Padded ? " (bits completados com zeros, sem alterar o áudio)" : "");
                    info.BitPerfect = true;
                    info.Path = "Direto ao DAC, sem o mixer do Windows (WASAPI exclusivo, bit-perfect)";
                }
                catch (Exception e)
                {
                    Log("exclusive failed: " + e);
                    DisposeOutput();
                    reason = "O Windows não liberou o modo exclusivo (" + Short(e) + "). Confira se outro programa está usando o DAC e se "
                        + "\"Permitir que aplicativos assumam o controle exclusivo\" está marcado nas propriedades do dispositivo.";
                    pipe.Seek(pipe.PositionMs);
                }
            }
            else reason = $"O dispositivo não aceita {Describe(pipe.Reader.WaveFormat)} no modo exclusivo; tocando pelo mixer do Windows";
        }
        else if (WantExclusive && dsp.Active)
            reason = "Bit-perfect pausado: o equalizador ou o Palco está ligado";

        if (newChain == null)
        {
            try
            {
                var mix = backend.MixFormat(device);
                var shared = new SharedChain(pipe, mix, dsp, this);
                var player = backend.Create(device, exclusive: false);
                player.Init(shared);
                Attach(player);
                newChain = shared;
                info.MixRate = mix.SampleRate;
                info.Output = $"32-bit float · {Fmt.Rate(mix.SampleRate)} · {mix.Channels} canais (mixer do Windows)";
                bool resampled = pipe.Reader.WaveFormat.SampleRate != mix.SampleRate;
                info.Path = resampled
                    ? $"Mixer do Windows · reamostrado pelo app (WDL sinc) de {Fmt.Rate(pipe.Reader.WaveFormat.SampleRate)} para {Fmt.Rate(mix.SampleRate)}"
                    : $"Mixer do Windows em {Fmt.Rate(mix.SampleRate)} · sem reamostragem";
            }
            catch (Exception e)
            {
                Log("shared failed: " + e);
                DisposeOutput();
                pipe.Dispose();
                Info = new ChainInfo { Device = device.Name, Reason = "Falha ao abrir a saída de áudio: " + Short(e) };
                var t = pipe.Track;
                Task.Run(() => Failed?.Invoke(t, "Falha ao abrir a saída de áudio: " + Short(e)));
                return false;
            }
        }

        info.Exclusive = exclusive;
        info.Reason = reason;
        info.Processing = ProcessingLabel();
        Info = info;
        chain = newChain;
        if (autoplay) { output!.Play(); playing = true; }
        else playing = false;
        Task.Run(() => InfoChanged?.Invoke());
        return true;
    }

    string ProcessingLabel()
    {
        var parts = new List<string>();
        if (dsp.EqOn) parts.Add("Equalizador 15 bandas · limitador");
        if (dsp.PalcoOn) parts.Add($"Palco {(int)Math.Round(dsp.PalcoAmount * 100)}% (graves no centro)");
        return parts.Count == 0 ? "Nenhum: sem EQ, efeitos, normalização ou ajuste de velocidade" : string.Join(" · ", parts);
    }

    /// <summary>Atualiza o texto de processamento (mudança de EQ/Palco que não exige reabrir a saída).</summary>
    public void RefreshProcessing()
    {
        Info.Processing = ProcessingLabel();
        if (!Info.Exclusive && WantExclusive && dsp.Active) Info.Reason = "Bit-perfect pausado: o equalizador ou o Palco está ligado";
        Task.Run(() => InfoChanged?.Invoke());
    }

    void Attach(IWavePlayer player)
    {
        output = player;
        int gen = ++generation;
        player.PlaybackStopped += (_, e) => Task.Run(() => OnStopped(gen, e.Exception));
    }

    static void Log(string m) { if (Environment.GetEnvironmentVariable("TOM_DEBUG") == "1") Console.WriteLine($"{DateTime.Now:HH:mm:ss.fff} {m}"); }

    void OnStopped(int gen, Exception? error)
    {
        Log($"stopped gen={gen}/{generation} err={error?.Message} cur={current?.Title}");
        Track? endedTrack;
        TrackPipe? pending;
        lock (gate)
        {
            if (gen != generation) return; // parada pedida pelo app
            endedTrack = current;
            pending = chain?.TakePending();
            DisposeOutput();
            if (error != null && endedTrack != null && recoveries < 3)
            {
                // Saída perdida (DAC desconectado, troca de dispositivo): reabre no ponto onde estava
                recoveries++;
                long pos = chain?.PositionMs ?? 0;
                var pipe = chain?.DetachCurrent();
                chain = null;
                if (pipe != null)
                {
                    Thread.Sleep(400);
                    pipe.Seek(pos);
                    Start(pipe, true);
                    return;
                }
            }
            if (pending != null)
            {
                // A próxima faixa tem outro formato: reabre a saída no formato dela
                chain?.Dispose();
                chain = null;
                current = pending.Track;
                Start(pending, true);
                Task.Run(() => Advanced?.Invoke(pending.Track));
                return;
            }
            chain?.Dispose();
            chain = null;
            playing = false;
        }
        Ended?.Invoke();
    }

    /// <summary>Chamado pela linha de áudio ao emendar a próxima faixa (sem travar o motor).</summary>
    internal void ChainAdvanced(TrackPipe next)
    {
        Log($"advanced {next.Track.Title}");
        Volatile.Write(ref current, next.Track);
        recoveries = 0;
        var t = next.Track;
        var src = Describe(next.Reader.WaveFormat, t);
        Info.Source = src;
        Info.Decoder = next.Decoder;
        Task.Run(() => { Advanced?.Invoke(t); InfoChanged?.Invoke(); });
    }

    /// <summary>Abre a próxima faixa com antecedência, para emendar sem pausa (gapless).</summary>
    internal TrackPipe? OpenNext(Track after)
    {
        var t = NextAfter?.Invoke(after);
        Log($"opennext {t?.Title}");
        if (t == null) return null;
        // Se falhar aqui, a faixa é tentada de novo (e o erro avisado) quando chegar a vez dela
        return TrackPipe.TryOpen(t, out _);
    }

    public void Pause()
    {
        lock (gate)
        {
            if (output == null) return;
            output.Pause();
            playing = false;
        }
    }

    public void Resume()
    {
        lock (gate)
        {
            if (output == null) return;
            output.Play();
            playing = true;
        }
    }

    public void Seek(long ms)
    {
        lock (gate) chain?.Seek(ms);
    }

    public void Stop()
    {
        lock (gate)
        {
            StopOutput();
            current = null;
        }
    }

    /// <summary>A próxima faixa mudou (fila editada, aleatório...): descarta a que foi aberta antes.</summary>
    public void InvalidateNext()
    {
        lock (gate) chain?.InvalidateNext();
    }

    /// <summary>Reabre a saída no mesmo ponto (troca de dispositivo, bit-perfect, EQ ou Palco).</summary>
    public void Reopen()
    {
        lock (gate)
        {
            if (chain == null || current == null) return;
            long pos = PositionMsUnlocked();
            bool wasPlaying = playing;
            var pipe = chain.DetachCurrent();
            StopOutput();
            if (pipe == null) return;
            pipe.Seek(pos);
            Start(pipe, wasPlaying);
        }
    }

    long PositionMsUnlocked() => chain == null ? 0 : Math.Max(0, chain.PositionMs - (playing ? chain.LatencyMs : 0));

    void OnDevicesChanged()
    {
        lock (gate)
        {
            if (output == null || current == null) return;
            // Se a saída em uso sumiu, ou se seguimos o padrão do Windows e ele mudou, reabre
            var device = backend.Resolve(DeviceId);
            if (device != null && device.Name == Info.Device) return;
        }
        Reopen();
    }

    void StopOutput()
    {
        generation++;
        DisposeOutput();
        chain?.Dispose();
        chain = null;
        playing = false;
    }

    void DisposeOutput()
    {
        var o = output;
        output = null;
        if (o == null) return;
        try { o.Stop(); } catch { }
        try { o.Dispose(); } catch { }
    }

    public void Dispose()
    {
        lock (gate) StopOutput();
    }

    // ---- utilidades ---------------------------------------------------------------------------

    static string Short(Exception e)
    {
        var m = e.Message;
        if (e is System.Runtime.InteropServices.COMException ce) m = $"código 0x{ce.ErrorCode:X8}";
        return m.Length > 120 ? m[..120] : m;
    }

    public static string Describe(WaveFormat f, Track? t = null)
    {
        int bits = f is WaveFormatExtensible x && x.ValidBitsPerSample > 0 ? x.ValidBitsPerSample : f.BitsPerSample;
        bool isFloat = f.Encoding == WaveFormatEncoding.IeeeFloat ||
                       (f is WaveFormatExtensible e && e.SubFormat == NAudio.Dmo.AudioMediaSubtypes.MEDIASUBTYPE_IEEE_FLOAT);
        var codec = t != null && t.Codec != "" ? t.Codec + " · " : "";
        var b = isFloat ? "32-bit float" : $"{bits}-bit";
        if (f is WaveFormatExtensible x2 && x2.ValidBitsPerSample > 0 && x2.ValidBitsPerSample < f.BitsPerSample) b += $" (em {f.BitsPerSample})";
        var ch = f.Channels == 1 ? "mono" : f.Channels == 2 ? "estéreo" : $"{f.Channels} canais";
        return $"{codec}{b} · {Fmt.Rate(f.SampleRate)} · {ch}";
    }
}

// ---- Faixa aberta --------------------------------------------------------------------------------

/// <summary>Uma faixa aberta para tocar: o leitor do arquivo e de onde ele veio.</summary>
public sealed class TrackPipe : IDisposable
{
    public Track Track { get; }
    public WaveStream Reader { get; }
    public string Decoder { get; }

    TrackPipe(Track t, WaveStream r, string decoder) { Track = t; Reader = r; Decoder = decoder; }

    public static TrackPipe? TryOpen(Track t, out string error)
    {
        error = "";
        try
        {
            var (r, dec) = AudioReaders.Open(t.Path);
            return new TrackPipe(t, r, dec);
        }
        catch (FileNotFoundException) { error = "Arquivo não encontrado: " + t.Path; }
        catch (DirectoryNotFoundException) { error = "Arquivo não encontrado: " + t.Path; }
        catch (Exception e) { error = "O Windows não conseguiu abrir este arquivo (" + t.Codec + "): " + e.Message; }
        return null;
    }

    public long PositionMs => (long)Reader.CurrentTime.TotalMilliseconds;

    public void Seek(long ms)
    {
        try
        {
            var total = Reader.TotalTime;
            var t = TimeSpan.FromMilliseconds(Math.Max(0, ms));
            if (total > TimeSpan.Zero && t > total) t = total;
            Reader.CurrentTime = t;
        }
        catch { }
    }

    public void Dispose()
    {
        try { Reader.Dispose(); } catch { }
    }
}

public static class AudioReaders
{
    /// <summary>
    /// Abre o arquivo com o leitor mais direto: WAV e AIFF são lidos sem decodificador;
    /// FLAC, ALAC, MP3, AAC e outros usam o Media Foundation do Windows (sem perdas e
    /// bit-exato para FLAC/ALAC).
    /// </summary>
    public static (WaveStream reader, string decoder) Open(string path)
    {
        if (!File.Exists(path)) throw new FileNotFoundException(path);
        var ext = Path.GetExtension(path).ToLowerInvariant();
        if (ext == ".wav")
        {
            try
            {
                var w = new WaveFileReader(path);
                var enc = w.WaveFormat.Encoding;
                if (enc is WaveFormatEncoding.Pcm or WaveFormatEncoding.IeeeFloat or WaveFormatEncoding.Extensible)
                    return (w, "Leitura direta do PCM (sem decodificador)");
                w.Dispose();
            }
            catch when (OperatingSystem.IsWindows()) { }
        }
        if (ext is ".aif" or ".aiff" or ".aifc")
        {
            try { return (new AiffFileReader(path), "Leitura direta do PCM (sem decodificador)"); }
            catch when (OperatingSystem.IsWindows()) { }
        }
        if (!OperatingSystem.IsWindows()) throw new NotSupportedException("Decodificação disponível só no Windows");
        var mf = new MediaFoundationReader(path, new MediaFoundationReader.MediaFoundationReaderSettings
        {
            RequestFloatOutput = false,
            RepositionInRead = true,
        });
        return (mf, "Media Foundation do Windows");
    }
}

// ---- Cadeias de reprodução -----------------------------------------------------------------------

interface IChain : IDisposable
{
    long PositionMs { get; }
    int LatencyMs { get; }
    void Seek(long ms);
    void InvalidateNext();
    TrackPipe? TakePending();
    TrackPipe? DetachCurrent();
}

/// <summary>Plano para o modo exclusivo: formato aceito pelo DAC e como encaixar as amostras.</summary>
sealed class ExclusivePlan
{
    public WaveFormat Output = null!;
    public int SrcBytes;      // bytes por amostra no arquivo
    public int DstBytes;      // bytes por amostra no contêiner do DAC
    public bool DupMono;      // mono → estéreo (a mesma amostra nos dois canais)
    public bool Padded => DstBytes != SrcBytes || DupMono;

    public static ExclusivePlan? For(IDeviceBackend backend, OutputDevice d, WaveFormat src)
    {
        bool isFloat = src.Encoding == WaveFormatEncoding.IeeeFloat ||
                       (src is WaveFormatExtensible e && e.SubFormat == NAudio.Dmo.AudioMediaSubtypes.MEDIASUBTYPE_IEEE_FLOAT);
        int bits = src.BitsPerSample;
        int rate = src.SampleRate;
        int[] channelOptions = src.Channels == 1 ? new[] { 1, 2 } : new[] { src.Channels };
        foreach (var ch in channelOptions)
        {
            var candidates = new List<(int container, int valid)>();
            if (isFloat) candidates.Add((32, 32));
            else
            {
                candidates.Add((bits, bits));
                if (bits <= 24) candidates.Add((32, bits));
                if (bits < 24) candidates.Add((24, 24));
                if (bits <= 24) candidates.Add((32, 24));
                candidates.Add((32, 32));
            }
            foreach (var (container, valid) in candidates)
            {
                var formats = new List<WaveFormat> { new WaveFormatExtensible(rate, container, valid, ch, isFloat) };
                if (!isFloat && container == valid && ch <= 2 && container <= 24) formats.Add(new WaveFormat(rate, container, ch));
                foreach (var f in formats)
                {
                    bool ok;
                    try { ok = backend.SupportsExclusive(d, f); } catch { ok = false; }
                    if (!ok) continue;
                    return new ExclusivePlan { Output = f, SrcBytes = bits / 8, DstBytes = container / 8, DupMono = ch != src.Channels };
                }
            }
        }
        return null;
    }
}

/// <summary>
/// Cadeia bit-perfect: copia as amostras do arquivo para o DAC. Se o DAC pede um contêiner maior
/// (por exemplo 24 bits dentro de 32), os bits extras são zeros à direita, o que não muda o som.
/// Emenda a próxima faixa sem pausa quando ela tem o mesmo formato.
/// </summary>
sealed class ExclusiveChain : IWaveProvider, IChain
{
    readonly object gate = new();
    readonly ExclusivePlan plan;
    readonly AudioEngine engine;
    readonly WaveFormat srcFormat;
    TrackPipe currentPipe;
    TrackPipe? next;
    Task<TrackPipe?>? nextTask;
    TrackPipe? pending;
    bool finished;
    byte[] tmp = new byte[0];

    public ExclusiveChain(TrackPipe pipe, ExclusivePlan plan, AudioEngine engine)
    {
        currentPipe = pipe;
        this.plan = plan;
        this.engine = engine;
        srcFormat = pipe.Reader.WaveFormat;
    }

    public WaveFormat WaveFormat => plan.Output;
    public int LatencyMs => 120;

    public long PositionMs { get { lock (gate) return currentPipe.PositionMs; } }

    public int Read(byte[] buffer, int offset, int count)
    {
        lock (gate)
        {
            int written = 0;
            int outFrame = plan.DstBytes * plan.Output.Channels;
            count -= count % outFrame;
            while (written < count)
            {
                int n = ReadConverted(currentPipe, buffer, offset + written, count - written);
                if (n > 0) { written += n; Prefetch(); continue; }
                // Fim da faixa: emenda a próxima, se tiver o mesmo formato
                if (finished || pending != null) break;
                var nx = TakeNext();
                if (nx == null) { finished = true; break; }
                if (SameFormat(nx.Reader.WaveFormat, srcFormat))
                {
                    currentPipe.Dispose();
                    currentPipe = nx;
                    engine.ChainAdvanced(nx);
                    continue;
                }
                pending = nx;
                break;
            }
            return written;
        }
    }

    int ReadConverted(TrackPipe pipe, byte[] buffer, int offset, int count)
    {
        int sb = plan.SrcBytes, db = plan.DstBytes;
        int outCh = plan.Output.Channels;
        int inCh = srcFormat.Channels;
        int frames = count / (db * outCh);
        if (!plan.Padded) return ReadFull(pipe.Reader, buffer, offset, frames * sb * inCh);
        int need = frames * sb * inCh;
        if (tmp.Length < need) tmp = new byte[need];
        int got = ReadFull(pipe.Reader, tmp, 0, need);
        int inFrames = got / (sb * inCh);
        int o = offset;
        for (int f = 0; f < inFrames; f++)
        {
            for (int c = 0; c < outCh; c++)
            {
                int src = (f * inCh + (plan.DupMono ? 0 : c)) * sb;
                for (int z = 0; z < db - sb; z++) buffer[o++] = 0;           // bits baixos em zero
                for (int k = 0; k < sb; k++) buffer[o++] = tmp[src + k];     // amostra original
            }
        }
        return inFrames * db * outCh;
    }

    static int ReadFull(WaveStream r, byte[] buf, int offset, int count)
    {
        int total = 0;
        int block = r.WaveFormat.BlockAlign;
        count -= count % Math.Max(1, block);
        while (total < count)
        {
            int n = r.Read(buf, offset + total, count - total);
            if (n <= 0) break;
            total += n;
        }
        return total;
    }

    static bool SameFormat(WaveFormat a, WaveFormat b) =>
        a.SampleRate == b.SampleRate && a.BitsPerSample == b.BitsPerSample && a.Channels == b.Channels &&
        (a.Encoding == WaveFormatEncoding.IeeeFloat) == (b.Encoding == WaveFormatEncoding.IeeeFloat);

    void Prefetch()
    {
        if (next != null || nextTask != null) return;
        try
        {
            var r = currentPipe.Reader;
            if (r.TotalTime - r.CurrentTime > TimeSpan.FromSeconds(8)) return;
        }
        catch { return; }
        { var after = currentPipe.Track; nextTask = Task.Run(() => engine.OpenNext(after)); }
    }

    TrackPipe? TakeNext()
    {
        if (next == null && nextTask == null) { var after = currentPipe.Track; nextTask = Task.Run(() => engine.OpenNext(after)); }
        if (next == null && nextTask != null)
        {
            if (!nextTask.Wait(1500)) return null;
            next = nextTask.Result;
            nextTask = null;
        }
        var n = next;
        next = null;
        return n;
    }

    public void Seek(long ms) { lock (gate) { currentPipe.Seek(ms); finished = false; } }

    public void InvalidateNext()
    {
        lock (gate)
        {
            finished = false;
            next?.Dispose();
            next = null;
            var t = nextTask;
            nextTask = null;
            t?.ContinueWith(x => x.Result?.Dispose());
        }
    }

    public TrackPipe? TakePending() { lock (gate) { var p = pending; pending = null; return p; } }

    public TrackPipe? DetachCurrent()
    {
        lock (gate)
        {
            var p = currentPipe;
            currentPipe = null!;
            return p;
        }
    }

    public void Dispose()
    {
        lock (gate)
        {
            currentPipe?.Dispose();
            next?.Dispose();
            pending?.Dispose();
            nextTask?.ContinueWith(x => x.Result?.Dispose());
        }
    }
}

/// <summary>
/// Cadeia pelo mixer do Windows: decodifica em 32-bit float, aplica Palco/equalizador,
/// converte para a taxa do mixer com um reamostrador sinc de alta qualidade e emenda
/// qualquer faixa seguinte sem pausa.
/// </summary>
sealed class SharedChain : IWaveProvider, IChain
{
    readonly object gate = new();
    readonly WaveFormat mix;
    readonly DspState dsp;
    readonly AudioEngine engine;
    TrackPipe currentPipe;
    ISampleProvider samples;
    TrackPipe? next;
    Task<TrackPipe?>? nextTask;
    float[] fbuf = new float[0];
    bool finished;

    public SharedChain(TrackPipe pipe, WaveFormat mixFormat, DspState dsp, AudioEngine engine)
    {
        mix = mixFormat;
        this.dsp = dsp;
        this.engine = engine;
        currentPipe = pipe;
        samples = Build(pipe);
    }

    public WaveFormat WaveFormat => mix;
    public int LatencyMs => 150;
    public long PositionMs { get { lock (gate) return currentPipe.PositionMs; } }

    ISampleProvider Build(TrackPipe pipe)
    {
        ISampleProvider s = new PcmToFloat(pipe.Reader);
        if (s.WaveFormat.Channels == 1) s = new MonoToStereoSampleProvider(s);
        else if (s.WaveFormat.Channels > 2)
        {
            var m = new MultiplexingSampleProvider(new[] { s }, 2);
            m.ConnectInputToOutput(0, 0);
            m.ConnectInputToOutput(1, 1);
            s = m;
        }
        s = new DspProvider(s, dsp);
        if (s.WaveFormat.SampleRate != mix.SampleRate) s = new WdlResamplingSampleProvider(s, mix.SampleRate);
        if (mix.Channels != 2)
        {
            var m = new MultiplexingSampleProvider(new[] { s }, mix.Channels);
            for (int c = 0; c < mix.Channels; c++) m.ConnectInputToOutput(Math.Min(c, 1), c);
            if (mix.Channels > 2) for (int c = 2; c < mix.Channels; c++) m.ConnectInputToOutput(c % 2, c);
            s = m;
        }
        return s;
    }

    public int Read(byte[] buffer, int offset, int count)
    {
        lock (gate)
        {
            int floats = count / 4;
            floats -= floats % mix.Channels;
            if (fbuf.Length < floats) fbuf = new float[floats];
            int got = 0;
            while (got < floats)
            {
                int n = samples.Read(fbuf, got, floats - got);
                if (n > 0) { got += n; Prefetch(); continue; }
                if (finished) break;
                var nx = TakeNext();
                if (nx == null) { finished = true; break; }
                currentPipe.Dispose();
                currentPipe = nx;
                samples = Build(nx);
                engine.ChainAdvanced(nx);
            }
            float vol = dsp.Volume;
            if (vol != 1f) for (int i = 0; i < got; i++) fbuf[i] *= vol;
            System.Runtime.InteropServices.MemoryMarshal.Cast<float, byte>(fbuf.AsSpan(0, got)).CopyTo(buffer.AsSpan(offset));
            return got * 4;
        }
    }

    void Prefetch()
    {
        if (next != null || nextTask != null) return;
        try
        {
            var r = currentPipe.Reader;
            if (r.TotalTime - r.CurrentTime > TimeSpan.FromSeconds(8)) return;
        }
        catch { return; }
        { var after = currentPipe.Track; nextTask = Task.Run(() => engine.OpenNext(after)); }
    }

    TrackPipe? TakeNext()
    {
        if (next == null && nextTask == null) { var after = currentPipe.Track; nextTask = Task.Run(() => engine.OpenNext(after)); }
        if (next == null && nextTask != null)
        {
            if (!nextTask.Wait(1500)) return null;
            next = nextTask.Result;
            nextTask = null;
        }
        var n = next;
        next = null;
        return n;
    }

    public void Seek(long ms)
    {
        lock (gate)
        {
            currentPipe.Seek(ms);
            finished = false;
            samples = Build(currentPipe); // recomeça filtros e reamostrador no ponto novo
        }
    }

    public void InvalidateNext()
    {
        lock (gate)
        {
            finished = false;
            next?.Dispose();
            next = null;
            var t = nextTask;
            nextTask = null;
            t?.ContinueWith(x => x.Result?.Dispose());
        }
    }

    public TrackPipe? TakePending() => null;

    public TrackPipe? DetachCurrent()
    {
        lock (gate)
        {
            var p = currentPipe;
            currentPipe = null!;
            return p;
        }
    }

    public void Dispose()
    {
        lock (gate)
        {
            currentPipe?.Dispose();
            next?.Dispose();
            nextTask?.ContinueWith(x => x.Result?.Dispose());
        }
    }
}

/// <summary>Converte PCM inteiro (8/16/24/32 bits) ou float, simples ou "extensible", para float.</summary>
sealed class PcmToFloat : ISampleProvider
{
    readonly IWaveProvider src;
    readonly int bytes;
    readonly bool isFloat;
    byte[] buf = new byte[0];

    public PcmToFloat(IWaveProvider source)
    {
        src = source;
        var f = source.WaveFormat;
        bytes = f.BitsPerSample / 8;
        isFloat = f.Encoding == WaveFormatEncoding.IeeeFloat ||
                  (f is WaveFormatExtensible e && e.SubFormat == NAudio.Dmo.AudioMediaSubtypes.MEDIASUBTYPE_IEEE_FLOAT);
        if (isFloat && bytes != 4 && bytes != 8) throw new NotSupportedException("Formato float não suportado");
        if (!isFloat && (bytes < 1 || bytes > 4)) throw new NotSupportedException("Formato PCM não suportado");
        WaveFormat = WaveFormat.CreateIeeeFloatWaveFormat(f.SampleRate, f.Channels);
    }

    public WaveFormat WaveFormat { get; }

    public int Read(float[] buffer, int offset, int count)
    {
        int need = count * bytes;
        if (buf.Length < need) buf = new byte[need];
        int got = 0;
        while (got < need)
        {
            int n = src.Read(buf, got, need - got);
            if (n <= 0) break;
            got += n;
        }
        int samples = got / bytes;
        int o = 0;
        for (int i = 0; i < samples; i++, o += bytes)
        {
            float v;
            if (isFloat) v = bytes == 4 ? BitConverter.ToSingle(buf, o) : (float)BitConverter.ToDouble(buf, o);
            else switch (bytes)
            {
                case 1: v = (buf[o] - 128) / 128f; break;
                case 2: v = (short)(buf[o] | (buf[o + 1] << 8)) / 32768f; break;
                case 3: v = (buf[o] | (buf[o + 1] << 8) | ((sbyte)buf[o + 2] << 16)) / 8388608f; break;
                default: v = BitConverter.ToInt32(buf, o) / 2147483648f; break;
            }
            buffer[offset + i] = v;
        }
        return samples;
    }
}
