using System.Text.Json;

namespace TomMusic;

public sealed class EqSettings
{
    public bool Enabled { get; set; }
    public float Preamp { get; set; }
    public float[] Gains { get; set; } = new float[EqBands.Count];
    public string Preset { get; set; } = "Plano";
}

public sealed class SavedQueue
{
    public List<string> Ids { get; set; } = new();
    public List<string> Original { get; set; } = new();
    public int Index { get; set; }
    public long PositionMs { get; set; }
    public bool Shuffle { get; set; }
    public int Repeat { get; set; }
}

/// <summary>Ajustes do app, salvos em %APPDATA%\Tom Music Player.</summary>
public sealed class Settings
{
    public List<string> Folders { get; set; } = new();
    public string DeviceId { get; set; } = "";          // vazio = o dispositivo padrão do Windows
    public bool BitPerfect { get; set; } = true;        // modo exclusivo do WASAPI
    public float Volume { get; set; } = 1f;
    public bool Dark { get; set; } = true;
    public EqSettings Eq { get; set; } = new();
    public bool PalcoOn { get; set; }
    public float PalcoAmount { get; set; } = 1.4f;
    public SavedQueue Queue { get; set; } = new();

    [System.Text.Json.Serialization.JsonIgnore] public string FilePath { get; private set; } = "";

    public static Settings Load(string dataDir)
    {
        var path = Path.Combine(dataDir, "ajustes.json");
        Settings s;
        try { s = File.Exists(path) ? JsonSerializer.Deserialize<Settings>(File.ReadAllText(path), Json.Options) ?? new() : new(); }
        catch { s = new(); }
        s.FilePath = path;
        if (s.Eq.Gains.Length != EqBands.Count) s.Eq.Gains = new float[EqBands.Count];
        if (s.Folders.Count == 0)
        {
            var music = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
            if (!string.IsNullOrEmpty(music)) s.Folders.Add(music);
        }
        return s;
    }

    readonly object gate = new();

    public void Save()
    {
        lock (gate)
        {
            try
            {
                var tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(this, Json.Options));
                File.Move(tmp, FilePath, true);
            }
            catch { }
        }
    }
}
