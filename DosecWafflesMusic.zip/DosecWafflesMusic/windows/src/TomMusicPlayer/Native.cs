using System.Diagnostics;
using System.Runtime.InteropServices;

namespace TomMusic;

/// <summary>Partes que conversam direto com o Windows: janela, seletor de pasta e teclas de mídia.</summary>
public static class Native
{
    // ---- Janela do app (Microsoft Edge em modo aplicativo) ------------------------------------

    public static string? FindBrowser()
    {
        var candidates = new List<string>();
        foreach (var root in new[]
                 {
                     Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                     Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                     Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                 })
        {
            if (string.IsNullOrEmpty(root)) continue;
            candidates.Add(Path.Combine(root, "Microsoft", "Edge", "Application", "msedge.exe"));
        }
        if (OperatingSystem.IsWindows())
        {
            try
            {
                using var k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe");
                if (k?.GetValue(null) is string p) candidates.Add(p);
            }
            catch { }
        }
        foreach (var root in new[]
                 {
                     Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                     Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                     Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                 })
        {
            if (string.IsNullOrEmpty(root)) continue;
            candidates.Add(Path.Combine(root, "Google", "Chrome", "Application", "chrome.exe"));
        }
        return candidates.FirstOrDefault(File.Exists);
    }

    /// <summary>Abre a interface numa janela própria, sem barra de endereço.</summary>
    public static Process? OpenWindow(string url, string profileDir)
    {
        var browser = FindBrowser();
        if (browser == null)
        {
            try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch { }
            return null;
        }
        var psi = new ProcessStartInfo(browser) { UseShellExecute = false };
        psi.ArgumentList.Add("--app=" + url);
        psi.ArgumentList.Add("--user-data-dir=" + profileDir);
        psi.ArgumentList.Add("--no-first-run");
        psi.ArgumentList.Add("--no-default-browser-check");
        psi.ArgumentList.Add("--disable-sync");
        psi.ArgumentList.Add("--disable-features=msEdgeSidebarV2,Translate,msHubApps,msUndersideButton");
        psi.ArgumentList.Add("--autoplay-policy=no-user-gesture-required");
        psi.ArgumentList.Add("--window-size=1320,860");
        try { return Process.Start(psi); }
        catch
        {
            try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch { }
            return null;
        }
    }

    // ---- Seletor de pasta (diálogo moderno do Windows) -----------------------------------------

    public static Task<string?> PickFolder(string title)
    {
        var tcs = new TaskCompletionSource<string?>();
        if (!OperatingSystem.IsWindows()) { tcs.SetResult(null); return tcs.Task; }
        var t = new Thread(() =>
        {
            try { tcs.SetResult(PickFolderSta(title)); }
            catch { tcs.TrySetResult(null); }
        });
        t.SetApartmentState(ApartmentState.STA);
        t.IsBackground = true;
        t.Start();
        return tcs.Task;
    }

    static string? PickFolderSta(string title)
    {
        var dialog = (IFileDialog)new FileOpenDialogRcw();
        try
        {
            dialog.GetOptions(out var opts);
            dialog.SetOptions(opts | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST);
            dialog.SetTitle(title);
            var owner = GetForegroundWindow();
            int hr = dialog.Show(owner);
            if (hr != 0) return null;
            dialog.GetResult(out var item);
            item.GetDisplayName(SIGDN_FILESYSPATH, out var ptr);
            try { return Marshal.PtrToStringUni(ptr); }
            finally { Marshal.FreeCoTaskMem(ptr); }
        }
        finally { Marshal.ReleaseComObject(dialog); }
    }

    const uint FOS_PICKFOLDERS = 0x20, FOS_FORCEFILESYSTEM = 0x40, FOS_PATHMUSTEXIST = 0x800;
    const uint SIGDN_FILESYSPATH = 0x80058000;

    [ComImport, Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]
    class FileOpenDialogRcw { }

    [ComImport, Guid("42f85136-db7e-439c-85f1-e4075d135fc8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IFileDialog
    {
        [PreserveSig] int Show(IntPtr parent);
        void SetFileTypes(uint cFileTypes, IntPtr rgFilterSpec);
        void SetFileTypeIndex(uint iFileType);
        void GetFileTypeIndex(out uint piFileType);
        void Advise(IntPtr pfde, out uint pdwCookie);
        void Unadvise(uint dwCookie);
        void SetOptions(uint fos);
        void GetOptions(out uint pfos);
        void SetDefaultFolder(IShellItem psi);
        void SetFolder(IShellItem psi);
        void GetFolder(out IShellItem ppsi);
        void GetCurrentSelection(out IShellItem ppsi);
        void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);
        void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);
        void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);
        void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);
        void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);
        void GetResult(out IShellItem ppsi);
        void AddPlace(IShellItem psi, int fdap);
        void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);
        void Close(int hr);
        void SetClientGuid(ref Guid guid);
        void ClearClientData();
        void SetFilter(IntPtr pFilter);
    }

    [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IShellItem
    {
        void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);
        void GetParent(out IShellItem ppsi);
        void GetDisplayName(uint sigdnName, out IntPtr ppszName);
        void GetAttributes(uint sfgaoMask, out uint psfgaoAttribs);
        void Compare(IShellItem psi, uint hint, out int piOrder);
    }

    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();

    // ---- Teclas de mídia do teclado -----------------------------------------------------------

    [StructLayout(LayoutKind.Sequential)]
    struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }

    [DllImport("user32.dll", SetLastError = true)] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] static extern int GetMessage(out MSG lpMsg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax);

    /// <summary>Play/pausa, próxima e anterior pelas teclas de mídia, mesmo com a janela em segundo plano.</summary>
    public static void StartMediaKeys(Action playPause, Action next, Action previous, Action stop)
    {
        if (!OperatingSystem.IsWindows()) return;
        var t = new Thread(() =>
        {
            const uint MOD_NOREPEAT = 0x4000;
            var keys = new (int id, uint vk, Action act)[]
            {
                (1, 0xB3, playPause), (2, 0xB0, next), (3, 0xB1, previous), (4, 0xB2, stop),
            };
            int registered = 0;
            foreach (var k in keys) if (RegisterHotKey(IntPtr.Zero, k.id, MOD_NOREPEAT, k.vk)) registered++;
            if (registered == 0) return;
            while (GetMessage(out var msg, IntPtr.Zero, 0, 0) > 0)
            {
                if (msg.message != 0x0312) continue; // WM_HOTKEY
                int id = (int)msg.wParam;
                foreach (var k in keys)
                    if (k.id == id) { try { k.act(); } catch { } }
            }
        }) { IsBackground = true, Name = "Teclas de mídia" };
        t.Start();
    }
}
