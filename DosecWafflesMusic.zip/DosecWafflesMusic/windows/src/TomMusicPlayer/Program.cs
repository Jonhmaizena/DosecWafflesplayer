using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using TomMusic;

// ================================================================================================
// Tom Music Player para Windows
// O áudio é tocado por este programa (WASAPI). A interface é uma página local, aberta numa
// janela própria do Microsoft Edge (modo aplicativo, sem barra de endereço).
// ================================================================================================

var dataDir = Environment.GetEnvironmentVariable("TOM_DATA") ??
              Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Tom Music Player");
Directory.CreateDirectory(dataDir);
var portFile = Path.Combine(dataDir, "porta.txt");
bool noWindow = Environment.GetEnvironmentVariable("TOM_NO_WINDOW") == "1";

// Uma instância só: se já estiver aberto, só abre outra janela para ele
using var single = new Mutex(true, "TomMusicPlayer-instancia-unica", out bool firstInstance);
if (!firstInstance)
{
    try
    {
        var url = File.ReadAllText(portFile).Trim();
        Native.OpenWindow(url, Path.Combine(dataDir, "janela"));
    }
    catch { }
    return;
}

var settings = Settings.Load(dataDir);
var library = new Library(dataDir);
var store = new LibraryStore(dataDir);
var dsp = new DspState();
dsp.Set(settings.Eq, settings.PalcoOn, settings.PalcoAmount, settings.Volume);
IDeviceBackend backend = OperatingSystem.IsWindows() ? new WasapiBackend() : new FakeBackend();
var engine = new AudioEngine(backend, dsp) { DeviceId = settings.DeviceId, WantExclusive = settings.BitPerfect };
var player = new Player(engine, library, settings);
var token = Environment.GetEnvironmentVariable("TOM_TOKEN") ?? Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();

// ---- Avisos para a interface (Server-Sent Events) -------------------------------------------------
var clients = new ConcurrentDictionary<int, SemaphoreSlim>();
int clientSeq = 0;
DateTime lastClientSeen = DateTime.UtcNow;
bool everConnected = false;
void Notify() { foreach (var s in clients.Values) { try { if (s.CurrentCount == 0) s.Release(); } catch (SemaphoreFullException) { } } }
player.Changed += Notify;
library.Changed += Notify;

library.Changed += () =>
{
    if (!library.Scanning) player.Relink();
};

player.Restore();
_ = library.ScanAsync(settings.Folders);

// ---- Servidor local --------------------------------------------------------------------------------
var builder = WebApplication.CreateBuilder(new WebApplicationOptions
{
    Args = args,
    ContentRootPath = AppContext.BaseDirectory,
    WebRootPath = Path.Combine(AppContext.BaseDirectory, "wwwroot"),
});
builder.Logging.ClearProviders();
int fixedPort = int.TryParse(Environment.GetEnvironmentVariable("TOM_PORT"), out var p) ? p : 0;
builder.WebHost.ConfigureKestrel(o => o.Listen(IPAddress.Loopback, fixedPort));
builder.Services.ConfigureHttpJsonOptions(o =>
{
    o.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
});
var app = builder.Build();

// Só a própria interface pode usar a API (protege contra páginas da internet chamando o servidor local)
app.Use(async (ctx, next) =>
{
    if (ctx.Request.Path.StartsWithSegments("/api"))
    {
        var t = ctx.Request.Headers["X-Tom"].ToString();
        if (t == "") t = ctx.Request.Query["t"].ToString();
        if (t != token) { ctx.Response.StatusCode = 403; return; }
    }
    if (ctx.Request.Path == "/" || ctx.Request.Path.Value!.EndsWith(".html") || ctx.Request.Path.Value!.EndsWith(".js") || ctx.Request.Path.Value!.EndsWith(".css"))
        ctx.Response.Headers.CacheControl = "no-cache";
    await next();
});
app.UseDefaultFiles();
app.UseStaticFiles();

JsonObject StateJson()
{
    var s = player.Get();
    var info = engine.Info;
    return new JsonObject
    {
        ["trackId"] = s.Track?.Id,
        ["queue"] = new JsonArray(s.QueueIds.Select(i => (JsonNode)JsonValue.Create(i)!).ToArray()),
        ["index"] = s.Index,
        ["playing"] = s.Playing,
        ["positionMs"] = s.PositionMs,
        ["durationMs"] = s.Track?.DurationMs ?? 0,
        ["shuffle"] = s.Shuffle,
        ["repeat"] = s.Repeat,
        ["error"] = s.Error,
        ["volume"] = settings.Volume,
        ["bitPerfect"] = settings.BitPerfect,
        ["deviceId"] = settings.DeviceId,
        ["dark"] = settings.Dark,
        ["eq"] = JsonSerializer.SerializeToNode(settings.Eq, Json.Options),
        ["palcoOn"] = settings.PalcoOn,
        ["palcoAmount"] = settings.PalcoAmount,
        ["chain"] = JsonSerializer.SerializeToNode(info, Json.Options),
        ["libraryVersion"] = library.Version,
        ["scanning"] = library.Scanning,
        ["scanDone"] = library.ScanDone,
        ["scanTotal"] = library.ScanTotal,
        ["folders"] = new JsonArray(settings.Folders.Select(f => (JsonNode)JsonValue.Create(f)!).ToArray()),
        ["serverTime"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
    };
}

app.MapGet("/api/state", () => Results.Text(StateJson().ToJsonString(), "application/json"));

app.MapGet("/api/events", async (HttpContext ctx) =>
{
    ctx.Response.Headers.ContentType = "text/event-stream";
    ctx.Response.Headers.CacheControl = "no-cache";
    int id = Interlocked.Increment(ref clientSeq);
    var signal = new SemaphoreSlim(0, 1);
    clients[id] = signal;
    everConnected = true;
    try
    {
        var ct = ctx.RequestAborted;
        while (!ct.IsCancellationRequested)
        {
            var json = StateJson().ToJsonString();
            await ctx.Response.WriteAsync("data: " + json + "\n\n", ct);
            await ctx.Response.Body.FlushAsync(ct);
            lastClientSeen = DateTime.UtcNow;
            await signal.WaitAsync(player.Get().Playing ? 1000 : 3000, ct);
            await Task.Delay(30, ct); // junta avisos seguidos
        }
    }
    catch { }
    finally
    {
        clients.TryRemove(id, out _);
        lastClientSeen = DateTime.UtcNow;
    }
});

app.MapGet("/api/library", () =>
    Results.Text(JsonSerializer.Serialize(new { version = library.Version, tracks = library.All }, Json.Options), "application/json"));

// Capas (guardadas na memória para não ler o arquivo de novo)
var coverCache = new ConcurrentDictionary<string, (byte[] data, string mime)?>();
app.MapGet("/api/cover/{id}", (string id) =>
{
    var t = library.Get(id);
    if (t == null) return Results.NotFound();
    if (coverCache.Count > 400) coverCache.Clear();
    var c = coverCache.GetOrAdd(id, _ => Library.Cover(t));
    if (c == null) return Results.NotFound();
    return Results.Bytes(c.Value.data, c.Value.mime);
});

app.MapGet("/api/track/{id}/extras", (string id) =>
{
    var t = library.Get(id);
    if (t == null) return Results.NotFound();
    var tags = TagReader.Read(t.Path);
    var origin = TagReader.Origin(tags);
    var fields = tags.Fields.Where(f => f.Value.Length < 300 && f.Key is not ("LYRICS" or "UNSYNCEDLYRICS" or "SYNCEDLYRICS"))
        .Select(f => new { key = f.Key, value = f.Value }).Take(80);
    return Results.Text(JsonSerializer.Serialize(new { lyrics = tags.Lyrics, origin, fields, vendor = tags.Vendor }, Json.Options), "application/json");
});

List<Track> Resolve(JsonNode? ids) =>
    (ids as JsonArray ?? new JsonArray()).Select(n => library.Get(n?.GetValue<string>() ?? "")).Where(t => t != null).Select(t => t!).ToList();

async Task<JsonObject> Body(HttpContext ctx)
{
    try { return (await JsonNode.ParseAsync(ctx.Request.Body)) as JsonObject ?? new JsonObject(); }
    catch { return new JsonObject(); }
}

IResult Ok() => Results.Text(StateJson().ToJsonString(), "application/json");

app.MapPost("/api/play", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    await player.PlayList(Resolve(b["ids"]), b["index"]?.GetValue<int>() ?? 0);
    return Ok();
});
app.MapPost("/api/toggle", async () => { await player.Toggle(); return Ok(); });
app.MapPost("/api/pause", async () => { await player.Pause(); return Ok(); });
app.MapPost("/api/next", async () => { await player.Next(); return Ok(); });
app.MapPost("/api/prev", async () => { await player.Previous(); return Ok(); });
app.MapPost("/api/seek", async (HttpContext ctx) => { var b = await Body(ctx); await player.Seek(b["ms"]?.GetValue<long>() ?? 0); return Ok(); });
app.MapPost("/api/jump", async (HttpContext ctx) => { var b = await Body(ctx); await player.JumpTo(b["index"]?.GetValue<int>() ?? 0); return Ok(); });
app.MapPost("/api/queue/next", async (HttpContext ctx) => { var b = await Body(ctx); await player.PlayNextInQueue(Resolve(b["ids"])); return Ok(); });
app.MapPost("/api/queue/add", async (HttpContext ctx) => { var b = await Body(ctx); await player.AddToQueue(Resolve(b["ids"])); return Ok(); });
app.MapPost("/api/queue/remove", async (HttpContext ctx) => { var b = await Body(ctx); await player.RemoveAt(b["index"]?.GetValue<int>() ?? -1); return Ok(); });
app.MapPost("/api/queue/move", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    await player.Move(b["from"]?.GetValue<int>() ?? -1, b["to"]?.GetValue<int>() ?? -1);
    return Ok();
});
app.MapPost("/api/shuffle", async (HttpContext ctx) => { var b = await Body(ctx); await player.SetShuffle(b["on"]?.GetValue<bool>() ?? false); return Ok(); });
app.MapPost("/api/repeat", async (HttpContext ctx) => { var b = await Body(ctx); await player.SetRepeat(b["mode"]?.GetValue<int>() ?? 0); return Ok(); });

app.MapPost("/api/volume", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    settings.Volume = Math.Clamp(b["value"]?.GetValue<float>() ?? 1f, 0f, 1f);
    dsp.Set(settings.Eq, settings.PalcoOn, settings.PalcoAmount, settings.Volume);
    settings.Save();
    Notify();
    return Ok();
});

app.MapPost("/api/theme", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    settings.Dark = b["dark"]?.GetValue<bool>() ?? true;
    settings.Save();
    Notify();
    return Ok();
});

// ---- Equalizador e Palco ----------------------------------------------------------------------------
async Task ApplyDsp(bool wasActive)
{
    dsp.Set(settings.Eq, settings.PalcoOn, settings.PalcoAmount, settings.Volume);
    settings.Save();
    // Ligar/desligar o processamento troca entre bit-perfect (exclusivo) e mixer: reabre a saída
    if (settings.BitPerfect && wasActive != dsp.Active) await player.ReopenOutput();
    else engine.RefreshProcessing();
    Notify();
}

app.MapGet("/api/eq/presets", () => Results.Json(EqPresets.All.Select(x => new { name = x.Name, gains = x.Gains }),
    new JsonSerializerOptions(JsonSerializerDefaults.Web)));
app.MapPost("/api/eq", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    bool was = dsp.Active;
    var eq = b.Deserialize<EqSettings>(Json.Options) ?? new EqSettings();
    if (eq.Gains.Length != EqBands.Count) eq.Gains = new float[EqBands.Count];
    eq.Preamp = Math.Clamp(eq.Preamp, EqBands.PreampMin, EqBands.PreampMax);
    for (int i = 0; i < eq.Gains.Length; i++) eq.Gains[i] = Math.Clamp(eq.Gains[i], -EqBands.MaxDb, EqBands.MaxDb);
    settings.Eq = eq;
    await ApplyDsp(was);
    return Ok();
});
app.MapPost("/api/palco", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    bool was = dsp.Active;
    settings.PalcoOn = b["on"]?.GetValue<bool>() ?? false;
    settings.PalcoAmount = Math.Clamp(b["amount"]?.GetValue<float>() ?? settings.PalcoAmount, 0.5f, 2f);
    await ApplyDsp(was);
    return Ok();
});

// ---- Saída de áudio ---------------------------------------------------------------------------------
app.MapGet("/api/devices", () =>
{
    var list = engine.Devices();
    return Results.Text(JsonSerializer.Serialize(new { selected = settings.DeviceId, devices = list }, Json.Options), "application/json");
});
app.MapPost("/api/output", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    if (b["deviceId"] != null) settings.DeviceId = b["deviceId"]!.GetValue<string>();
    if (b["bitPerfect"] != null) settings.BitPerfect = b["bitPerfect"]!.GetValue<bool>();
    // Ligar o bit-perfect desliga equalizador e Palco: os dois não convivem
    if (b["bitPerfect"]?.GetValue<bool>() == true && dsp.Active)
    {
        settings.Eq.Enabled = false;
        settings.PalcoOn = false;
        dsp.Set(settings.Eq, settings.PalcoOn, settings.PalcoAmount, settings.Volume);
    }
    engine.DeviceId = settings.DeviceId;
    engine.WantExclusive = settings.BitPerfect;
    settings.Save();
    await player.ReopenOutput();
    Notify();
    return Ok();
});

// ---- Favoritas e playlists ----------------------------------------------------------------------------
app.MapGet("/api/store", () => Results.Text(JsonSerializer.Serialize(new { favorites = store.Favorites, playlists = store.Playlists }, Json.Options), "application/json"));
IResult StoreResult() => Results.Text(JsonSerializer.Serialize(new { favorites = store.Favorites, playlists = store.Playlists }, Json.Options), "application/json");
app.MapPost("/api/favorite", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    store.SetFavorite(b["id"]?.GetValue<string>() ?? "", b["on"]?.GetValue<bool>() ?? false);
    return StoreResult();
});
app.MapPost("/api/playlists", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    var ids = (b["ids"] as JsonArray)?.Select(n => n!.GetValue<string>());
    store.Create(b["name"]?.GetValue<string>() ?? "", ids);
    return StoreResult();
});
app.MapPost("/api/playlists/{id}/rename", async (string id, HttpContext ctx) => { var b = await Body(ctx); store.Rename(id, b["name"]?.GetValue<string>() ?? ""); return StoreResult(); });
app.MapPost("/api/playlists/{id}/delete", (string id) => { store.Delete(id); return StoreResult(); });
app.MapPost("/api/playlists/{id}/add", async (string id, HttpContext ctx) =>
{
    var b = await Body(ctx);
    store.Add(id, (b["ids"] as JsonArray ?? new JsonArray()).Select(n => n!.GetValue<string>()));
    return StoreResult();
});
app.MapPost("/api/playlists/{id}/remove", async (string id, HttpContext ctx) => { var b = await Body(ctx); store.RemoveAt(id, b["index"]?.GetValue<int>() ?? -1); return StoreResult(); });
app.MapPost("/api/playlists/{id}/move", async (string id, HttpContext ctx) =>
{
    var b = await Body(ctx);
    store.Move(id, b["from"]?.GetValue<int>() ?? -1, b["to"]?.GetValue<int>() ?? -1);
    return StoreResult();
});

// ---- Pastas de música ------------------------------------------------------------------------------
app.MapPost("/api/folders/pick", async () =>
{
    var path = await Native.PickFolder("Escolha uma pasta com músicas");
    if (!string.IsNullOrEmpty(path) && !settings.Folders.Contains(path, StringComparer.OrdinalIgnoreCase))
    {
        settings.Folders.Add(path);
        settings.Save();
        _ = library.ScanAsync(settings.Folders);
    }
    return Results.Json(new { path, supported = OperatingSystem.IsWindows() });
});
app.MapPost("/api/folders/add", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    var path = (b["path"]?.GetValue<string>() ?? "").Trim().Trim('"');
    if (path == "" || !Directory.Exists(path)) return Results.Json(new { ok = false, message = "Pasta não encontrada" });
    if (!settings.Folders.Contains(path, StringComparer.OrdinalIgnoreCase)) settings.Folders.Add(path);
    settings.Save();
    _ = library.ScanAsync(settings.Folders);
    return Results.Json(new { ok = true });
});
app.MapPost("/api/folders/remove", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    var path = b["path"]?.GetValue<string>() ?? "";
    settings.Folders.RemoveAll(f => string.Equals(f, path, StringComparison.OrdinalIgnoreCase));
    settings.Save();
    _ = library.ScanAsync(settings.Folders);
    return Ok();
});
app.MapPost("/api/rescan", () => { _ = library.ScanAsync(settings.Folders); return Ok(); });

app.MapPost("/api/reveal/{id}", (string id) =>
{
    var t = library.Get(id);
    if (t != null && OperatingSystem.IsWindows())
    {
        try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{t.Path}\"") { UseShellExecute = false }); } catch { }
    }
    return Results.Ok();
});

// ---- Analisador de espectro ---------------------------------------------------------------------------
object analysisGate = new();
var analysis = new JsonObject { ["running"] = false };
CancellationTokenSource? analysisCts = null;
app.MapPost("/api/analyze", async (HttpContext ctx) =>
{
    var b = await Body(ctx);
    var t = library.Get(b["id"]?.GetValue<string>() ?? "");
    if (t == null) return Results.NotFound();
    lock (analysisGate)
    {
        analysisCts?.Cancel();
        analysisCts = new CancellationTokenSource();
        analysis = new JsonObject { ["running"] = true, ["trackId"] = t.Id, ["progress"] = 0.0 };
    }
    var cts = analysisCts;
    _ = Task.Run(() =>
    {
        try
        {
            var report = SpectrumAnalyzer.Analyze(t, p => { lock (analysisGate) if (!cts.IsCancellationRequested) analysis["progress"] = p; }, cts.Token);
            lock (analysisGate)
                if (!cts.IsCancellationRequested)
                    analysis = new JsonObject { ["running"] = false, ["trackId"] = t.Id, ["progress"] = 1.0, ["result"] = JsonSerializer.SerializeToNode(report, Json.Options) };
        }
        catch (OperationCanceledException) { }
        catch (Exception e)
        {
            lock (analysisGate)
                analysis = new JsonObject { ["running"] = false, ["trackId"] = t.Id, ["error"] = "Não foi possível analisar: " + e.Message };
        }
    });
    return Results.Ok();
});
app.MapGet("/api/analyze", () => { lock (analysisGate) return Results.Text(analysis.ToJsonString(), "application/json"); });
app.MapPost("/api/analyze/cancel", () => { lock (analysisGate) { analysisCts?.Cancel(); analysis = new JsonObject { ["running"] = false }; } return Results.Ok(); });

// ---- Início ------------------------------------------------------------------------------------------
await app.StartAsync();
var address = app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.First();
var appUrl = $"{address}/?t={token}";
try { File.WriteAllText(portFile, appUrl); } catch { }
Console.WriteLine("Tom Music Player: " + appUrl);

Process? window = noWindow ? null : Native.OpenWindow(appUrl, Path.Combine(dataDir, "janela"));

Native.StartMediaKeys(
    () => _ = player.Toggle(),
    () => _ = player.Next(),
    () => _ = player.Previous(),
    () => _ = player.Pause());

// Salva a posição da fila de tempos em tempos
var saver = new Timer(_ => player.SaveQueue(), null, 10_000, 10_000);

// Fecha o programa quando a janela é fechada (nenhuma interface conectada por alguns segundos)
var started = DateTime.UtcNow;
var lifetime = app.Services.GetRequiredService<IHostApplicationLifetime>();
_ = Task.Run(async () =>
{
    while (!lifetime.ApplicationStopping.IsCancellationRequested)
    {
        await Task.Delay(1000);
        if (noWindow) continue;
        bool noClients = clients.IsEmpty;
        if (everConnected && noClients && (DateTime.UtcNow - lastClientSeen).TotalSeconds > 6) break;
        if (!everConnected && (DateTime.UtcNow - started).TotalSeconds > 120) break;
    }
    lifetime.StopApplication();
});

await app.WaitForShutdownAsync();
saver.Dispose();
player.SaveQueue(force: true);
engine.Dispose();
try { if (window != null && !window.HasExited) window.Kill(true); } catch { }
try { File.Delete(portFile); } catch { }
