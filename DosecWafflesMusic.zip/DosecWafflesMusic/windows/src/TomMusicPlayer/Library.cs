using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace TomMusic;

/// <summary>Pastas de música, leitura das tags e cache da biblioteca.</summary>
public sealed class Library
{
    public static readonly HashSet<string> Extensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".flac", ".wav", ".aif", ".aiff", ".aifc", ".mp3", ".m4a", ".mp4", ".aac", ".ogg", ".oga", ".opus", ".wma",
    };

    readonly string cacheFile;
    readonly object gate = new();
    Dictionary<string, Track> byId = new();
    List<Track> tracks = new();

    public bool Scanning { get; private set; }
    public int ScanDone { get; private set; }
    public int ScanTotal { get; private set; }
    public long Version { get; private set; }
    public event Action? Changed;

    public Library(string dataDir)
    {
        cacheFile = System.IO.Path.Combine(dataDir, "biblioteca.json");
        try
        {
            if (File.Exists(cacheFile))
            {
                var list = JsonSerializer.Deserialize<List<Track>>(File.ReadAllText(cacheFile), Json.Options) ?? new();
                Set(list);
            }
        }
        catch { }
    }

    public static string IdFor(string path)
    {
        var bytes = SHA1.HashData(Encoding.UTF8.GetBytes(path.ToLowerInvariant()));
        return Convert.ToHexString(bytes, 0, 8).ToLowerInvariant();
    }

    public IReadOnlyList<Track> All { get { lock (gate) return tracks; } }

    public Track? Get(string id) { lock (gate) return byId.GetValueOrDefault(id); }

    void Set(List<Track> list)
    {
        list.Sort((a, b) =>
        {
            int c = string.Compare(a.Artist, b.Artist, StringComparison.CurrentCultureIgnoreCase);
            if (c != 0) return c;
            c = string.Compare(a.Album, b.Album, StringComparison.CurrentCultureIgnoreCase);
            if (c != 0) return c;
            c = a.DiscNo.CompareTo(b.DiscNo);
            if (c != 0) return c;
            c = a.TrackNo.CompareTo(b.TrackNo);
            return c != 0 ? c : string.Compare(a.Title, b.Title, StringComparison.CurrentCultureIgnoreCase);
        });
        lock (gate)
        {
            tracks = list;
            byId = new Dictionary<string, Track>();
            foreach (var t in list) byId[t.Id] = t;
            Version++;
        }
    }

    /// <summary>Procura música nas pastas. Arquivos sem mudança reaproveitam o que já foi lido.</summary>
    public Task ScanAsync(IReadOnlyList<string> folders)
    {
        lock (gate)
        {
            if (Scanning) return Task.CompletedTask;
            Scanning = true;
        }
        return Task.Run(() =>
        {
            try { Scan(folders); }
            finally { Scanning = false; Changed?.Invoke(); }
        });
    }

    void Scan(IReadOnlyList<string> folders)
    {
        var files = new List<string>();
        foreach (var folder in folders)
        {
            if (!Directory.Exists(folder)) continue;
            try
            {
                var opts = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = FileAttributes.System };
                foreach (var f in Directory.EnumerateFiles(folder, "*", opts))
                    if (Extensions.Contains(System.IO.Path.GetExtension(f))) files.Add(f);
            }
            catch { }
        }
        files = files.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        ScanTotal = files.Count;
        ScanDone = 0;
        Changed?.Invoke();

        Dictionary<string, Track> old;
        lock (gate) old = tracks.ToDictionary(t => t.Path, StringComparer.OrdinalIgnoreCase);

        var result = new ConcurrentBag<Track>();
        int done = 0;
        var lastNotify = DateTime.UtcNow;
        Parallel.ForEach(files, new ParallelOptions { MaxDegreeOfParallelism = Math.Clamp(Environment.ProcessorCount, 2, 8) }, f =>
        {
            try
            {
                var fi = new FileInfo(f);
                if (old.TryGetValue(f, out var prev) && prev.Size == fi.Length && prev.Modified == fi.LastWriteTimeUtc.Ticks)
                    result.Add(prev);
                else
                    result.Add(TagReader.ToTrack(f, TagReader.Read(f), fi));
            }
            catch { }
            int d = Interlocked.Increment(ref done);
            ScanDone = d;
            if ((DateTime.UtcNow - lastNotify).TotalMilliseconds > 500)
            {
                lastNotify = DateTime.UtcNow;
                Changed?.Invoke();
            }
        });

        Set(result.ToList());
        Save();
    }

    void Save()
    {
        try
        {
            List<Track> copy;
            lock (gate) copy = tracks.ToList();
            var tmp = cacheFile + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(copy, Json.Options));
            File.Move(tmp, cacheFile, true);
        }
        catch { }
    }

    /// <summary>Capa embutida no arquivo ou, se não houver, uma imagem na pasta (cover.jpg, folder.jpg...).</summary>
    public static (byte[] data, string mime)? Cover(Track t)
    {
        try
        {
            var tags = TagReader.Read(t.Path, wantPicture: true);
            if (tags.Picture != null) return (tags.Picture, tags.PictureMime);
        }
        catch { }
        try
        {
            string[] names = { "cover", "folder", "front", "album", "capa", "albumart" };
            foreach (var file in Directory.EnumerateFiles(t.Folder))
            {
                var ext = System.IO.Path.GetExtension(file).ToLowerInvariant();
                if (ext is not (".jpg" or ".jpeg" or ".png" or ".webp")) continue;
                var name = System.IO.Path.GetFileNameWithoutExtension(file).ToLowerInvariant();
                if (names.Any(n => name == n || name.StartsWith(n)))
                    return (File.ReadAllBytes(file), ext == ".png" ? "image/png" : ext == ".webp" ? "image/webp" : "image/jpeg");
            }
        }
        catch { }
        return null;
    }
}

/// <summary>Favoritas e playlists.</summary>
public sealed class LibraryStore
{
    readonly string file;
    readonly object gate = new();

    sealed class Data
    {
        public List<string> Favorites { get; set; } = new();
        public List<Playlist> Playlists { get; set; } = new();
    }

    Data data = new();

    public LibraryStore(string dataDir)
    {
        file = System.IO.Path.Combine(dataDir, "favoritas-playlists.json");
        try
        {
            if (File.Exists(file)) data = JsonSerializer.Deserialize<Data>(File.ReadAllText(file), Json.Options) ?? new();
        }
        catch { }
    }

    public List<string> Favorites { get { lock (gate) return data.Favorites.ToList(); } }
    public List<Playlist> Playlists
    {
        get
        {
            lock (gate)
                return data.Playlists.Select(p => new Playlist { Id = p.Id, Name = p.Name, TrackIds = p.TrackIds.ToList() }).ToList();
        }
    }

    public void SetFavorite(string id, bool on)
    {
        lock (gate)
        {
            data.Favorites.Remove(id);
            if (on) data.Favorites.Insert(0, id);
            Save();
        }
    }

    public Playlist Create(string name, IEnumerable<string>? ids = null)
    {
        lock (gate)
        {
            var p = new Playlist { Name = name.Trim() == "" ? "Nova playlist" : name.Trim(), TrackIds = ids?.ToList() ?? new() };
            data.Playlists.Add(p);
            Save();
            return p;
        }
    }

    public void Rename(string id, string name) => Edit(id, p => p.Name = name.Trim() == "" ? p.Name : name.Trim());
    public void Delete(string id) { lock (gate) { data.Playlists.RemoveAll(p => p.Id == id); Save(); } }
    public void Add(string id, IEnumerable<string> trackIds) => Edit(id, p => p.TrackIds.AddRange(trackIds));
    public void RemoveAt(string id, int index) => Edit(id, p => { if (index >= 0 && index < p.TrackIds.Count) p.TrackIds.RemoveAt(index); });

    public void Move(string id, int from, int to) => Edit(id, p =>
    {
        if (from < 0 || from >= p.TrackIds.Count || to < 0 || to >= p.TrackIds.Count) return;
        var t = p.TrackIds[from];
        p.TrackIds.RemoveAt(from);
        p.TrackIds.Insert(to, t);
    });

    void Edit(string id, Action<Playlist> change)
    {
        lock (gate)
        {
            var p = data.Playlists.FirstOrDefault(x => x.Id == id);
            if (p == null) return;
            change(p);
            Save();
        }
    }

    void Save()
    {
        try
        {
            var tmp = file + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(data, Json.Options));
            File.Move(tmp, file, true);
        }
        catch { }
    }
}

public static class Json
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = false,
    };
}
