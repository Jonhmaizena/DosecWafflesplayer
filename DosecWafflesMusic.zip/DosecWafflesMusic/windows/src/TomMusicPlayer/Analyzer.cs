using NAudio.Wave;

namespace TomMusic;

/// <summary>Resultado da análise de espectro.</summary>
public sealed class SpectrumReport
{
    public string TrackId { get; set; } = "";
    public string Verdict { get; set; } = "";   // authentic, suspect, fake, lossy, inconclusive
    public string Title { get; set; } = "";
    public List<string> Details { get; set; } = new();
    public int SampleRate { get; set; }
    public int Channels { get; set; }
    public string Codec { get; set; } = "";
    public int DeclaredBits { get; set; }
    public int EffectiveBits { get; set; }
    public int CutoffHz { get; set; }
    public bool Abrupt { get; set; }
    public int AnalyzedSeconds { get; set; }
    public int Columns { get; set; }
    public int Rows { get; set; }
    public string Image { get; set; } = "";     // intensidades 0–255, colunas × linhas, em base64
}

/// <summary>
/// Analisador de espectro (o mesmo do app Android): procura o corte abrupto deixado por MP3/AAC
/// convertidos, Hi-Res falso (CD convertido para 96/192 kHz) e 24-bit falso.
/// </summary>
public static class SpectrumAnalyzer
{
    const int FftSize = 4096;
    const int ColumnsMax = 480;
    const int Rows = 256;
    const int MaxSeconds = 300;
    const int BitCheckSamples = 4_000_000;

    public static SpectrumReport Analyze(Track track, Action<float> progress, CancellationToken ct)
    {
        var (reader, _) = AudioReaders.Open(track.Path);
        using var r = reader;
        var fmt = r.WaveFormat;
        int sampleRate = fmt.SampleRate;
        int channels = fmt.Channels;
        int bits = fmt.BitsPerSample;
        bool isFloat = fmt.Encoding == WaveFormatEncoding.IeeeFloat ||
                       (fmt is WaveFormatExtensible wfx && wfx.SubFormat == NAudio.Dmo.AudioMediaSubtypes.MEDIASUBTYPE_IEEE_FLOAT);
        double totalSec = r.TotalTime.TotalSeconds;
        int analyzeSeconds = totalSec > 0 ? (int)Math.Clamp(totalSec, 1, MaxSeconds) : MaxSeconds;
        long maxFrames = (long)analyzeSeconds * sampleRate;

        var fft = new Fft(FftSize);
        var window = new float[FftSize];
        for (int i = 0; i < FftSize; i++) window[i] = (float)(0.5 - 0.5 * Math.Cos(2 * Math.PI * i / (FftSize - 1)));
        var frame = new float[FftSize];
        int filled = 0;
        int bins = FftSize / 2;
        var avgPower = new double[bins];
        int frames = 0;
        int expectedFrames = Math.Max(1, (int)((long)analyzeSeconds * sampleRate / FftSize));
        int framesPerColumn = Math.Max(1, expectedFrames / ColumnsMax);
        var columns = new List<float[]>();
        var column = new float[Rows];
        int inColumn = 0;

        long checkedSamples = 0, beyond16 = 0;
        float peak = 0;
        long monoFrames = 0;
        int bytesPerSample = bits / 8;
        int blockAlign = bytesPerSample * channels;
        var buf = new byte[blockAlign * 8192];

        void PushMono(float v)
        {
            frame[filled++] = v;
            if (filled < FftSize) return;
            filled = 0;
            var power = fft.PowerSpectrum(frame, window);
            for (int b = 0; b < bins; b++) avgPower[b] += power[b];
            frames++;
            int perRow = bins / Rows;
            for (int row = 0; row < Rows; row++)
            {
                float m = 0;
                for (int k = row * perRow; k < (row + 1) * perRow; k++) if (power[k] > m) m = power[k];
                if (m > column[row]) column[row] = m;
            }
            if (++inColumn >= framesPerColumn)
            {
                columns.Add(column);
                column = new float[Rows];
                inColumn = 0;
            }
            if (frames % 16 == 0) progress(Math.Min(1f, (float)frames / expectedFrames));
        }

        while (monoFrames < maxFrames)
        {
            ct.ThrowIfCancellationRequested();
            int n = r.Read(buf, 0, buf.Length);
            if (n <= 0) break;
            int count = n / blockAlign;
            for (int f = 0; f < count && monoFrames < maxFrames; f++)
            {
                float sum = 0;
                for (int c = 0; c < channels; c++)
                {
                    int o = f * blockAlign + c * bytesPerSample;
                    float v;
                    bool extra = false;
                    if (isFloat)
                    {
                        v = BitConverter.ToSingle(buf, o);
                        if (v != 0)
                        {
                            float s = v * 32768f;
                            extra = Math.Abs(s - MathF.Round(s)) > 1e-3f;
                        }
                    }
                    else if (bits == 16) v = BitConverter.ToInt16(buf, o) / 32768f;
                    else if (bits == 24)
                    {
                        int s = buf[o] | (buf[o + 1] << 8) | ((sbyte)buf[o + 2] << 16);
                        v = s / 8388608f;
                        extra = buf[o] != 0;
                    }
                    else if (bits == 32)
                    {
                        int s = BitConverter.ToInt32(buf, o);
                        v = s / 2147483648f;
                        extra = (s & 0xFFFF) != 0;
                    }
                    else v = (buf[o] - 128) / 128f;
                    if (bits > 16 && v != 0 && checkedSamples < BitCheckSamples)
                    {
                        checkedSamples++;
                        if (extra) beyond16++;
                    }
                    sum += v;
                    float a = Math.Abs(v);
                    if (a > peak) peak = a;
                }
                PushMono(sum / channels);
                monoFrames++;
            }
        }
        if (inColumn > 0) columns.Add(column);
        if (frames == 0) throw new InvalidOperationException("Não foi possível decodificar o áudio");

        // ---- Espectro médio e corte ----------------------------------------------------------
        double nyquist = sampleRate / 2.0;
        double hzPerBin = nyquist / bins;
        var db = new double[bins];
        for (int b = 0; b < bins; b++) db[b] = 10 * Math.Log10(avgPower[b] / frames + 1e-20);
        var smooth = new double[bins];
        for (int b = 0; b < bins; b++)
        {
            double s = 0; int n = 0;
            for (int k = Math.Max(0, b - 6); k <= Math.Min(bins - 1, b + 6); k++) { s += db[k]; n++; }
            smooth[b] = s / n;
        }
        int from1k = Math.Min(bins - 1, (int)(1000 / hzPerBin));
        var refBand = smooth[from1k..Math.Min(bins, (int)(5000 / hzPerBin) + 1)].OrderBy(v => v).ToArray();
        double reference = refBand[refBand.Length / 2];
        double dynamic = reference - smooth[from1k..].Min();

        int span = Math.Max(2, (int)(600 / hzPerBin));
        int searchFrom = Math.Max(span, (int)(10_000 / hzPerBin));
        int bestBin = -1;
        double bestDrop = 0;
        for (int b = searchFrom; b < bins - span - 1; b++)
        {
            double drop = smooth[b - span] - smooth[b + span];
            if (drop > bestDrop) { bestDrop = drop; bestBin = b; }
        }
        bool abrupt = bestDrop > 20.0 && bestBin > 0;
        int cutoffBin = abrupt ? bestBin : bins - 1;
        int cutoffHz = (int)(cutoffBin * hzPerBin);

        int effectiveBits =
            bits <= 16 || checkedSamples < 10_000 ? 0 :
            (double)beyond16 / checkedSamples > 0.001 ? 24 : 16;

        // ---- Veredito -----------------------------------------------------------------------
        var codec = track.Codec;
        bool lossless = track.Lossless;
        double kc = cutoffHz / 1000.0;
        var br = System.Globalization.CultureInfo.GetCultureInfo("pt-BR");
        string Khz(double v) => v.ToString("0.0", br) + " kHz";
        var details = new List<string>
        {
            $"Conteúdo de áudio até {Khz(kc)} (limite do arquivo: {Khz(nyquist / 1000)})",
            abrupt ? $"Queda abrupta de {(int)Math.Round(bestDrop)} dB em {Khz(kc)}: parede típica de filtro digital"
                   : "Sem corte abrupto: os agudos vão até o limite do arquivo",
        };

        string verdict, title;
        if (peak < 0.003f || dynamic < 15) { verdict = "inconclusive"; title = "Inconclusivo: trecho muito baixo ou sem variação de frequência"; }
        else if (!lossless)
        {
            verdict = "lossy";
            title = $"{codec} é um formato com perdas por natureza" +
                    (kc < 16.5 ? " (qualidade de ~128 kbps)" : kc < 19.5 ? " (qualidade de ~192–256 kbps)" : " (qualidade alta, ~320 kbps)");
        }
        else if (sampleRate > 48000 && abrupt && kc < 16.5) { verdict = "fake"; title = "Hi-Res falso: feito a partir de um MP3 de ~128 kbps"; }
        else if (sampleRate > 48000 && kc <= 22.5) { verdict = "fake"; title = $"Hi-Res falso: conteúdo de CD convertido para {Fmt.Rate(sampleRate)}"; }
        else if (sampleRate > 48000 && kc <= 24.5) { verdict = "suspect"; title = $"Suspeito: parece um arquivo de 48 kHz convertido para {Fmt.Rate(sampleRate)}"; }
        else if (sampleRate > 48000) { verdict = "authentic"; title = $"Hi-Res real: há conteúdo até {Khz(kc)}"; }
        else if (abrupt && kc < 16.5) { verdict = "fake"; title = $"Falso: provável MP3 de ~128 kbps convertido para {codec}"; }
        else if (abrupt && kc < 17.5) { verdict = "fake"; title = $"Falso: provável MP3 de ~160–192 kbps convertido para {codec}"; }
        else if (abrupt && kc < 19.0) { verdict = "suspect"; title = "Suspeito: corte típico de MP3/AAC de ~256 kbps"; }
        else if (abrupt && kc < 20.0) { verdict = "suspect"; title = "Suspeito: corte típico de MP3 320 kbps ou AAC"; }
        else
        {
            verdict = "authentic";
            title = "Autêntico: sem sinais de compressão com perdas";
            if (abrupt) details.Add($"A parede perto de {Khz(kc)} é o filtro normal no fim da faixa de áudio do arquivo");
        }

        int declared = track.Bits > 0 ? track.Bits : bits;
        if (lossless && declared > 16 && effectiveBits == 16 && verdict != "inconclusive")
        {
            details.Add($"Declara {declared} bits, mas só usa 16: 24-bit falso");
            if (verdict == "authentic") { verdict = "suspect"; title = "Suspeito: 24-bit falso (16 bits preenchidos com zeros)"; }
        }
        else if (effectiveBits == 24) details.Add("Usa mais de 16 bits de resolução de verdade");

        // ---- Imagem (intensidade de 0 a 255; graves embaixo) ---------------------------------
        int w = Math.Max(1, columns.Count);
        var img = new byte[w * Rows];
        for (int x = 0; x < columns.Count; x++)
            for (int row = 0; row < Rows; row++)
            {
                double dbv = 10 * Math.Log10(columns[x][row] + 1e-12);
                double t = Math.Clamp((dbv + 110) / 100, 0, 1);
                img[(Rows - 1 - row) * w + x] = (byte)Math.Round(t * 255);
            }

        progress(1f);
        return new SpectrumReport
        {
            TrackId = track.Id,
            Verdict = verdict,
            Title = title,
            Details = details,
            SampleRate = sampleRate,
            Channels = channels,
            Codec = codec,
            DeclaredBits = declared,
            EffectiveBits = effectiveBits,
            CutoffHz = cutoffHz,
            Abrupt = abrupt,
            AnalyzedSeconds = (int)(monoFrames / sampleRate),
            Columns = w,
            Rows = Rows,
            Image = Convert.ToBase64String(img),
        };
    }

    /// <summary>FFT radix-2 iterativa.</summary>
    sealed class Fft
    {
        readonly int n;
        readonly double[] cosT, sinT, re, im;
        readonly int[] rev;
        readonly float[] output;

        public Fft(int n)
        {
            this.n = n;
            cosT = new double[n / 2];
            sinT = new double[n / 2];
            for (int i = 0; i < n / 2; i++) { cosT[i] = Math.Cos(2 * Math.PI * i / n); sinT[i] = -Math.Sin(2 * Math.PI * i / n); }
            rev = new int[n];
            int bitsN = System.Numerics.BitOperations.TrailingZeroCount(n);
            for (int i = 0; i < n; i++)
            {
                int r = 0;
                for (int b = 0; b < bitsN; b++) if ((i & (1 << b)) != 0) r |= 1 << (bitsN - 1 - b);
                rev[i] = r;
            }
            re = new double[n];
            im = new double[n];
            output = new float[n / 2];
        }

        public float[] PowerSpectrum(float[] x, float[] window)
        {
            for (int i = 0; i < n; i++) { re[rev[i]] = x[i] * window[i]; im[rev[i]] = 0; }
            for (int size = 2; size <= n; size *= 2)
            {
                int half = size / 2, step = n / size;
                for (int start = 0; start < n; start += size)
                {
                    int k = 0;
                    for (int j = start; j < start + half; j++)
                    {
                        double wr = cosT[k], wi = sinT[k];
                        double tr = wr * re[j + half] - wi * im[j + half];
                        double ti = wr * im[j + half] + wi * re[j + half];
                        re[j + half] = re[j] - tr; im[j + half] = im[j] - ti;
                        re[j] += tr; im[j] += ti;
                        k += step;
                    }
                }
            }
            double norm = 4.0 / ((double)n * n);
            for (int b = 0; b < n / 2; b++) output[b] = (float)((re[b] * re[b] + im[b] * im[b]) * norm);
            return output;
        }
    }
}
