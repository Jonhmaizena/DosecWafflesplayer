# Tom Music Player para Windows

Programa para Windows 10/11 (64 bits).

## Como funciona

- `src/TomMusicPlayer`: o programa (C#/.NET 8). Ele toca o áudio com o WASAPI do Windows e serve a interface numa página local (127.0.0.1), aberta numa janela do Microsoft Edge em modo aplicativo.
- `lib`: NAudio 2.2.1 (licença MIT, Mark Heath), partes Core e Wasapi, com dois ajustes: formato com bits válidos separados do contêiner (24 em 32) e pausa real do fluxo no modo exclusivo.
- `installer`: script do Inno Setup que gera o `TomMusicPlayer-Setup.exe`.

## Cadeia de áudio

- **Bit-perfect (padrão):** WASAPI exclusivo. O formato do arquivo é enviado sem conversão; se o DAC só aceita um contêiner maior (24 bits em 32), os bits baixos são preenchidos com zeros, o que não altera o som. Se o DAC não aceita a taxa do arquivo, o app avisa e toca pelo mixer.
- **Mixer do Windows:** usado quando o bit-perfect está desligado ou com equalizador/Palco ligados. Decodifica em 32-bit float, aplica Palco e equalizador (biquads em precisão dupla e limitador em −1 dBFS) e reamostra para a taxa do mixer com o reamostrador sinc WDL.
- **Decodificação:** WAV e AIFF são lidos direto; FLAC, ALAC, MP3, AAC, OGG e Opus usam o Media Foundation do Windows (FLAC e ALAC são decodificados sem perdas, bit a bit).

## Compilar no computador

```
dotnet publish src/TomMusicPlayer/TomMusicPlayer.csproj -c Release -r win-x64 --self-contained true -o publish
```

Os ajustes, a biblioteca, as favoritas e as playlists ficam em `%APPDATA%\Tom Music Player`.
