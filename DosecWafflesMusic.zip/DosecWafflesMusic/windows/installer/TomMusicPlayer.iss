; Instalador do Tom Music Player para Windows (Inno Setup 6)
#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif

[Setup]
AppId={{8F3C6E2A-5B1D-4C7E-9A2F-1D4E6B7C8A90}
AppName=Tom Music Player
AppVersion={#AppVersion}
AppVerName=Tom Music Player {#AppVersion}
AppPublisher=Tom Music Player
DefaultDirName={localappdata}\Programs\Tom Music Player
DefaultGroupName=Tom Music Player
DisableProgramGroupPage=yes
DisableDirPage=auto
PrivilegesRequired=lowest
OutputDir=..\out
OutputBaseFilename=TomMusicPlayer-Setup
SetupIconFile=..\src\TomMusicPlayer\app.ico
UninstallDisplayIcon={app}\TomMusicPlayer.exe
UninstallDisplayName=Tom Music Player
WizardStyle=modern
WizardImageFile=wizard.bmp
WizardSmallImageFile=small.bmp
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
MinVersion=10.0
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[InstallDelete]
; versões novas substituem a interface antiga por completo
Type: filesandordirs; Name: "{app}\wwwroot"

[Icons]
Name: "{autoprograms}\Tom Music Player"; Filename: "{app}\TomMusicPlayer.exe"
Name: "{autodesktop}\Tom Music Player"; Filename: "{app}\TomMusicPlayer.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\TomMusicPlayer.exe"; Description: "{cm:LaunchProgram,Tom Music Player}"; Flags: nowait postinstall skipifsilent
