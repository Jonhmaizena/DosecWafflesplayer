# Tom Music Player

> Antigo Maizeninha Audio Player e Dosec Waffles Music. O nome da pasta e do zip (DosecWafflesMusic) foi mantido para o repositório e a compilação continuarem iguais.

## Novidades da versão 7.1 (Android)

- **Predefinições para carro:** Carro 4T+2F (4 triaxiais nas portas + 2 frontais, como no Jeep Compass), Carro 2V+2T+1S (duas vias na frente, triaxiais atrás e subwoofer slim) e Carro 2V+2T (duas vias na frente e triaxiais atrás, como no Peugeot 2008). Também no Windows.
- **As listas voltam de onde você parou:** Músicas, Favoritas, Álbuns, Artistas, Pastas e Playlists guardam a posição ao abrir o player, um álbum ou um artista e voltar.
- **Sobre a música, álbum e artista:** botão (i) na tela Tocando agora e no menu ⋮ de cada música. Biografia e foto do artista (Wikipedia), ano, gravadora, número de faixas e gêneros do álbum (MusicBrainz), primeiro lançamento e ISRC da música. Tudo fica salvo no aparelho e funciona offline.
- **Letras da internet:** músicas sem letra no arquivo buscam a letra (sincronizada quando existe) no LRCLIB e guardam no aparelho.
- **Baixar a biblioteca inteira** para uso offline, com barra de progresso. A busca na internet pode ser desligada.

## Novidades da versão 7.0 (Android)

- **Capa em segundo plano:** o app agora entrega a capa por um endereço próprio, então ela aparece na notificação, na tela de bloqueio, no Android Auto e no widget mesmo com o app fechado.
- **Widget do player** para a tela inicial: capa, música, artista e os botões anterior, tocar/pausar e próxima. Tocar na capa abre o app. Com o app fechado, o botão tocar retoma a última fila.
- **Barra de rolagem rápida** em Músicas, Álbuns, Artistas e Pastas: arraste o marcador à direita e um balão mostra a letra inicial do ponto da lista. A ordem alfabética agora ignora acentos (Álbum fica no A).
- **Idiomas:** português, inglês e espanhol, pelo botão de globo no topo da biblioteca. Na primeira abertura, o app segue o idioma do celular.
- O botão play do fone Bluetooth também retoma a última fila com o app fechado.

## Versão para Windows (Tom Music Player 1.0 para PC)

A pasta `windows` traz o Tom Music Player para Windows 10 e 11 (64 bits). O GitHub gera o instalador `TomMusicPlayer-Setup.exe` junto com o APK.

- **Bit-perfect de verdade (WASAPI exclusivo):** as amostras do arquivo vão direto ao DAC, sem o mixer do Windows, na taxa e nos bits originais. Faixas seguidas no mesmo formato tocam sem pausa (gapless).
- Biblioteca com Músicas, Favoritas, Playlists, Álbuns, Artistas e Pastas, busca e ordenação.
- Capa, letra em tempo real (tags ou arquivo .lrc ao lado da música), origem do arquivo e tags completas.
- Equalizador de 15 bandas com as mesmas predefinições do celular, limitador e **Palco**. Com eles ligados, o som passa pelo mixer do Windows em 32-bit float, com reamostragem sinc de alta qualidade.
- Analisador de espectro (Hi-Res falso, MP3 convertido, 24-bit falso).
- Escolha do DAC/placa de som, painel "Cadeia de áudio" com luz verde/vermelha, tema escuro/claro, teclas de mídia do teclado.
- A última música volta no ponto onde parou.

A interface abre numa janela própria do Microsoft Edge (que já vem no Windows), sem barra de endereço. Fechar a janela fecha o programa.

Na primeira instalação o Windows pode mostrar "O Windows protegeu o computador", porque o instalador não tem assinatura digital paga. Clique em **Mais informações › Executar assim mesmo**.

## Novidades da versão 6.3

- Novo logo do disco **Tom Audio Player** no ícone do app, na abertura, na capa padrão (e no disco girando) e no banner da TV.

## Novidades da versão 6.2 – Palco

- **Palco (separação estéreo)**, na tela do equalizador: abre ou fecha a imagem estéreo para destacar a voz no centro e afastar os instrumentos para as laterais. Atalhos Sutil (120%), Amplo (140%) e Máximo (170%), ou ajuste fino de 50% a 200%.
- Os graves abaixo de ~150 Hz ficam no centro, para não perderem firmeza. O volume é compensado e os picos são arredondados, sem estalos.
- Mudar a intensidade vale na hora. Ligar ou desligar reabre a saída por um instante.
- Assim como o equalizador, o Palco desativa o bit-perfect enquanto estiver ligado.

## Novidades da versão 6.1

- Novas predefinições do equalizador: **60+** (realça a faixa de 2–10 kHz, onde a audição perde sensibilidade com a idade), **Jovens** (graves com punch e agudos brilhantes), **Estilo Qobuz** (quase neutro, com mais "ar") e **Estilo Tidal** (levemente quente e encorpado).
- **Tema escuro**: botão de lua/sol no topo da biblioteca. A escolha fica salva.

## Novidades da versão 6.0

- Novo nome: **Tom Music Player**.
- **Letra em tempo real** a partir dos metadados do arquivo: letras sincronizadas (LRC nas tags LYRICS/SYNCEDLYRICS, ou SYLT no MP3) acompanham a música com a linha atual em destaque. Toque numa linha para pular até ela. Letras sem tempo (USLT, ©lyr) aparecem como texto para rolar.
- **Origem do arquivo**, deduzida das tags: Qobuz, Tidal, Deezer, Bandcamp, HDtracks, Amazon, iTunes, Beatport, Spotify, YouTube, SoundCloud, CD (EAC, XLD, dBpoweramp, CUETools, fre:ac), vinil, cassete ou loja WEB. Sem pistas, aparece "Desconhecida". Toque na origem para ver em qual tag ela foi encontrada.
- Tags lidas direto do arquivo em FLAC, OGG/Opus, MP3 (ID3v2/ID3v1), M4A/ALAC/AAC, WAV e AIFF.

## Novidades da versão 5.0 – Analisador de espectro

- Espectrograma do arquivo (até 5 minutos), com eixo de frequência e marcação do ponto de corte.
- Veredito de autenticidade: Autêntico, Suspeito, Falso, Com perdas ou Inconclusivo.
- Detecta MP3/AAC convertido para FLAC/WAV (corte abrupto em ~16, ~19 ou ~20 kHz), Hi-Res falso (88,2/96/192 kHz sem conteúdo acima de ~22 kHz) e 24-bit falso (só 16 bits usados).
- Abre pelo ícone de gráfico na tela Tocando agora ou em ⋮ › Analisar espectro em qualquer música.

## Novidades da versão 4.3

- Capa do álbum na notificação, na tela de bloqueio e no Android Auto (a mesma capa que aparece no app; sem capa, o disco da Maizeninha).
- Luz de status do DAC no painel: verde "DAC conectado" ou vermelha "DAC não conectado", com o tipo de conexão logo abaixo.

## Novidades da versão 4.2

- Ao abrir o app, a última música volta pausada no ponto onde parou, com a mesma fila, aleatório e repetir.
- TV: escolher uma música já abre o player, com o foco no botão de tocar/pausar.
- TV: o controle remoto não "escapa" mais para a lista escondida atrás do player.
- TV: botão de nota musical no topo da biblioteca para voltar ao player.

## Novidades da versão 4.1

- Correção: com o reamostrador ligado, a troca para uma faixa com taxa diferente podia travar a fila.
- Uma faixa com erro (arquivo corrompido ou formato não suportado) agora é pulada, e a fila continua.
- Falhas da saída de áudio (troca de DAC, mudança de taxa) são recuperadas sozinhas, sem parar a música.

## Novidades da versão 4.0 – Android TV

- O mesmo APK funciona no celular e na Android TV / Google TV, e aparece na tela inicial da TV com um banner próprio.
- Navegação pelo controle remoto: o item selecionado ganha contorno azul.
- Tela "Tocando agora" com capa à esquerda e controles à direita em telas largas.
- Equalizador pelo controle: ↑/↓ mudam a banda, ←/→ passam para a próxima.
- Play/pause, próxima e anterior pelos botões de mídia do controle.

## Novidades da versão 3.3

- Música sem capa: o logo da Maizeninha aparece como um disco de vinil girando na tela Tocando agora e no mini player. Ele para quando a música pausa.

## Novidades da versão 3.2

- Paleta azul infantil: azul bebê, azul céu e água-marinha, com destaques em azul vivo.

## Novidades da versão 3.1 – Android Auto

- No carro: Músicas, Favoritas, Playlists, Álbuns (em grade) e Artistas.
- Tocar uma música no carro coloca a lista inteira na fila, a partir dela.
- Comando de voz: "Ok Google, tocar [música ou artista] no Maizeninha".
- Para aparecer no Android Auto sem vir da Play Store: no app Android Auto, toque 10 vezes em "Versão" para ativar o modo desenvolvedor, depois ⋮ › Configurações do desenvolvedor › Fontes desconhecidas.
- O Android Auto precisa dos serviços do Google instalados no celular.

## Novidades da versão 3.0

- Novo nome: **Maizeninha Audio Player**, com ícone, logo de abertura e capa padrão novos.
- Cores infantis: rosa chiclete, azul céu e amarelo sol, em tema claro.

Player de música para Android focado em reprodução fiel. Por padrão não há equalizador, efeitos, normalização de volume, crossfade nem mudança de velocidade no caminho do áudio.

## Novidades da versão 2.2

- **Conexão direta automática:** ao conectar um DAC USB, o app liga sozinho a conexão direta (pode ser desativado).
- **Segunda opção sem reamostragem:** se o celular não oferecer bit-perfect, o app coloca o mixer do Android na taxa exata da faixa, o que evita qualquer reamostragem.
- **Diagnóstico do DAC USB:** o painel mostra quais taxas e formatos o Android oferece para o DAC, em bit-perfect e no mixer.

## Novidades da versão 2.1

- **Reamostrador de alta qualidade:** filtro sinc com janela de Kaiser (32 cruzamentos de zero, ~90 dB de rejeição), em 32-bit float. Converte a faixa para a taxa do mixer do Android, que então não precisa usar o conversor padrão dele. Tem liga/desliga ao lado do bit-perfect, e os dois não funcionam juntos.
- O aviso do LG Hi-Fi Quad DAC só aparece quando a saída em uso é o Quad DAC.

## Novidades da versão 2.0

- **Favoritas:** toque no coração na tela Tocando agora ou use ⋮ › Favoritar. Elas ficam na aba Favoritas.
- **Playlists:** crie, renomeie, exclua e reordene playlists. Adicione músicas pelo menu ⋮, álbuns inteiros pela tela do álbum, ou salve a fila atual como playlist.
- **Equalizador de 15 bandas** (25 Hz a 16 kHz, ±15 dB), com pré-amplificação, limitador contra distorção e 12 predefinições. Tem botão de liga/desliga. Desligado, o efeito é removido por completo do caminho do áudio.
- **Bit-perfect e equalizador não convivem:** ligar o equalizador desativa o bit-perfect, e o bit-perfect só pode ser ligado com o equalizador desligado.

## O que ele faz

- Biblioteca com abas de Músicas, Álbuns, Artistas e Pastas, além de busca
- Fila com "tocar a seguir", "adicionar à fila", remover da fila, aleatório e repetir (todas / uma)
- Capa embutida em resolução total e metadados das tags: artista do álbum, ano, gênero, compositor, faixa e disco
- Notificação e tela de bloqueio com capa e controles, fones Bluetooth e botões de mídia
- Pausa automática ao desconectar o fone
- Reprodução sem lacunas (gapless) entre faixas
- Painel "Cadeia de áudio" mostrando, em tempo real:
  - se o áudio está indo direto ao DAC ou passando pelo mixer do Android
  - nome do DAC (DAC USB pelo nome do produto, LG Hi-Fi Quad DAC com o chip ESS, DAC interno ou Bluetooth)
  - formato do arquivo, decodificador usado, formato entregue ao Android e se há reamostragem

## Decodificação

O app usa o **FFmpeg** (biblioteca `org.jellyfin.media3:media3-ffmpeg-decoder`) como decodificador principal, com o decodificador do Android como reserva. Para formatos sem perdas (FLAC, ALAC, WAV, AIFF), qualquer decodificador correto produz exatamente as mesmas amostras do arquivo; o FFmpeg foi escolhido por não ter os limites de alguns decodificadores de fabricante (por exemplo, cortar para 16 bits ou 192 kHz).

A saída do player é PCM float de 32 bits, que guarda 24 bits sem perda. Com isso, todos os processadores de áudio do player ficam desligados.

## Formatos

FLAC, ALAC (.m4a), WAV, AIFF, MP3, AAC, OGG Vorbis e Opus. DSD (.dsf/.dff) não é suportado.

## LG com Hi-Fi Quad DAC

O app reconhece V20, V30, V35, V40, V50, V50S, V60, G7, G8, G8S e G8X. O Quad DAC só atua com fone na entrada P2 (3,5 mm) e precisa estar ligado em Ajustes › Som › Hi-Fi Quad DAC. A LG não oferece API pública para o estado do Quad DAC; quando o sistema não informa, o app avisa e oferece um atalho para os ajustes de som.

## Sobre "conexão direta ao DAC"

- **DAC USB + Android 14 ou mais novo:** ligue "Bit-perfect via DAC USB" na tela Tocando agora. O Android passa a enviar a taxa exata da faixa, sem mixer e sem reamostragem. O painel mostra "Conectado direto ao DAC" só quando o sistema confirma.
- **Fone P2, Quad DAC, alto-falante e Bluetooth:** o Android sempre passa pelo mixer do sistema. O painel mostra a taxa do mixer e se a faixa está sendo reamostrada. No Bluetooth, o som ainda é recomprimido pelo codec do Bluetooth.

## Como gerar o APK e o instalador do Windows pelo GitHub

1. Envie o `DosecWafflesMusic.zip` para a branch `main` do repositório.
2. A aba **Actions** compila sozinha: primeiro o APK (uns 5 minutos), depois o Windows (mais uns 5 minutos).
3. Em **Releases** aparecem o `DosecWafflesMusic.apk` (celular e TV) e o `TomMusicPlayer-Setup.exe` (Windows).

As versões novas instalam por cima da anterior, porque a chave de assinatura fica fixa em `app/debug.keystore`.

Para compilar no computador: abra a pasta no Android Studio e use **Build › Build APK(s)**.
