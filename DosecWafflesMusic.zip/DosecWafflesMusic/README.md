# Dosec Waffles Music

Player de música para Android focado em reprodução fiel. Por padrão não há equalizador, efeitos, normalização de volume, crossfade nem mudança de velocidade no caminho do áudio.

## Novidades da versão 2.0

- **Favoritas:** toque no coração na tela Tocando agora ou use ⋮ › Favoritar. Elas ficam na aba Favoritas.
- **Playlists:** crie, renomeie, exclua e reordene playlists. Adicione músicas pelo menu ⋮, álbuns inteiros pela tela do álbum, ou salve a fila atual como playlist.
- **Equalizador de 15 bandas** (25 Hz a 16 kHz, ±15 dB), com pré-amplificação, limitador contra distorção e 12 predefinições. Tem botão de liga/desliga. Desligado, o efeito é removido por completo do caminho do áudio.
- **Bit-perfect e equalizador não convivem:** ligar o equalizador desativa o bit-perfect, e o bit-perfect só pode ser ligado com o equalizador desligado.

## O que ele faz

- Biblioteca com abas de Músicas, Álbuns, Artistas e Pastas, além de busca
- Fila com "tocar a seguir", "adicionar à fila", remover da fila, aleatório e repetir (todas / uma)
- Capa embutida em resolução total e metadados das tags: artista do álbum, ano, gênero, compositor, faixa e disco
- Notificação e tela de bloqueio com capa e controles, fones Bluetooth e botões de mídia
- Pausa automática ao desconectar o fone
- Reprodução sem lacunas (gapless) entre faixas
- Painel "Cadeia de áudio" mostrando, em tempo real:
  - se o áudio está indo direto ao DAC ou passando pelo mixer do Android
  - nome do DAC (DAC USB pelo nome do produto, LG Hi-Fi Quad DAC com o chip ESS, DAC interno ou Bluetooth)
  - formato do arquivo, decodificador usado, formato entregue ao Android e se há reamostragem

## Decodificação

O app usa o **FFmpeg** (biblioteca `org.jellyfin.media3:media3-ffmpeg-decoder`) como decodificador principal, com o decodificador do Android como reserva. Para formatos sem perdas (FLAC, ALAC, WAV, AIFF), qualquer decodificador correto produz exatamente as mesmas amostras do arquivo; o FFmpeg foi escolhido por não ter os limites de alguns decodificadores de fabricante (por exemplo, cortar para 16 bits ou 192 kHz).

A saída do player é PCM float de 32 bits, que guarda 24 bits sem perda. Com isso, todos os processadores de áudio do player ficam desligados.

## Formatos

FLAC, ALAC (.m4a), WAV, AIFF, MP3, AAC, OGG Vorbis e Opus. DSD (.dsf/.dff) não é suportado.

## LG com Hi-Fi Quad DAC

O app reconhece V20, V30, V35, V40, V50, V50S, V60, G7, G8, G8S e G8X. O Quad DAC só atua com fone na entrada P2 (3,5 mm) e precisa estar ligado em Ajustes › Som › Hi-Fi Quad DAC. A LG não oferece API pública para o estado do Quad DAC; quando o sistema não informa, o app avisa e oferece um atalho para os ajustes de som.

## Sobre "conexão direta ao DAC"

- **DAC USB + Android 14 ou mais novo:** ligue "Bit-perfect via DAC USB" na tela Tocando agora. O Android passa a enviar a taxa exata da faixa, sem mixer e sem reamostragem. O painel mostra "Conectado direto ao DAC" só quando o sistema confirma.
- **Fone P2, Quad DAC, alto-falante e Bluetooth:** o Android sempre passa pelo mixer do sistema. O painel mostra a taxa do mixer e se a faixa está sendo reamostrada. No Bluetooth, o som ainda é recomprimido pelo codec do Bluetooth.

## Como gerar o APK pelo GitHub

1. Envie todo o conteúdo desta pasta para a branch `main` do repositório.
2. A aba **Actions** compila sozinha (leva uns 5 minutos).
3. O `DosecWafflesMusic.apk` aparece em **Releases**. Abra pelo celular e instale.

As versões novas instalam por cima da anterior, porque a chave de assinatura fica fixa em `app/debug.keystore`.

Para compilar no computador: abra a pasta no Android Studio e use **Build › Build APK(s)**.
