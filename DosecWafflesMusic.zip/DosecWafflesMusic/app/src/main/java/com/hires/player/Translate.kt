package com.hires.player

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.TimeUnit

/**
 * Tradução automática feita no próprio aparelho (Google ML Kit).
 * Na primeira vez baixa o pacote do idioma (cerca de 30 MB); depois funciona offline.
 * Nada do texto é enviado para servidores.
 */
object Tradutor {
    /** Traduz cada texto da lista de [from] para [to]. Lança exceção se o tradutor não estiver disponível. */
    fun translate(texts: List<String>, from: String, to: String, onProgress: (Int, Int) -> Unit = { _, _ -> }): List<String> {
        if (from == to || texts.isEmpty()) return texts
        val src = TranslateLanguage.fromLanguageTag(from) ?: throw IllegalArgumentException("idioma $from")
        val dst = TranslateLanguage.fromLanguageTag(to) ?: throw IllegalArgumentException("idioma $to")
        val client = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build()
        )
        try {
            Tasks.await(client.downloadModelIfNeeded(DownloadConditions.Builder().build()), 5, TimeUnit.MINUTES)
            val out = ArrayList<String>(texts.size)
            texts.forEachIndexed { i, t ->
                out += if (t.isBlank()) t
                else runCatching { Tasks.await(client.translate(t), 60, TimeUnit.SECONDS) }.getOrDefault(t)
                onProgress(i + 1, texts.size)
            }
            return out
        } finally {
            client.close()
        }
    }
}
