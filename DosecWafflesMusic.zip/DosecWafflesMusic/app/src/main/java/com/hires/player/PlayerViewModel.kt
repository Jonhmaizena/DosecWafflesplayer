package com.hires.player

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Quality(
    val codec: String = "",
    val sampleRate: Int = 0,
    val bits: Int = 0,
    val channels: Int = 0,
    val bitrateKbps: Int = 0,
) {
    val isHiRes: Boolean get() = bits > 16 || sampleRate > 48000

    fun label(): String = listOfNotNull(
        codec.ifEmpty { null },
        if (bits > 0) "$bits-bit" else null,
        formatRate(sampleRate).ifEmpty { null },
        when (channels) { 1 -> "Mono"; 2 -> "Estéreo"; 0 -> null; else -> "$channels canais" },
    ).joinToString(" · ")
}

/** Cadeia completa: arquivo → decodificador → app → Android → DAC. */
data class AudioChain(
    val decoder: String = "",
    val appOutput: String = "",
    val path: String = "",
    val direct: Boolean = false,
    val directAvailable: Boolean = false,
    val deviceType: String = "",
    val dacName: String = "",
    val deviceMaxRate: Int = 0,
    val deviceMaxBits: Int = 0,
    val usb: Boolean = false,
    val lgQuadDacInUse: Boolean = false,
    val lgPhone: Boolean = false,
    val lgState: String = "",
)

/** Metadados lidos das tags do arquivo (Vorbis comments, ID3, MP4). */
data class TagInfo(
    val albumArtist: String = "",
    val year: Int = 0,
    val genre: String = "",
    val composer: String = "",
    val disc: Int = 0,
    val trackOf: String = "",
    val artwork: ByteArray? = null,
)

data class PlayerUi(
    val connected: Boolean = false,
    val current: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Track> = emptyList(),
    val index: Int = 0,
    val quality: Quality = Quality(),
    val chain: AudioChain = AudioChain(),
    val tags: TagInfo = TagInfo(),
    val bitPerfectOn: Boolean = false,
    val bitPerfectStatus: String = "",
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private var byId: Map<String, Track> = emptyMap()
    private val defaultArt: Uri =
        Uri.parse("android.resource://${app.packageName}/${R.drawable.default_cover}")
    private var controller: MediaController? = null

    fun loadLibrary() {
        viewModelScope.launch {
            _loading.value = true
            val list = withContext(Dispatchers.IO) {
                runCatching { MusicRepository.load(getApplication()) }.getOrDefault(emptyList())
            }
            byId = list.associateBy { it.id.toString() }
            _tracks.value = list
            _loading.value = false
            refresh()
        }
    }

    fun connect() {
        if (controller != null) return
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
            val c = runCatching {
                MediaController.Builder(ctx, token)
                    .setListener(object : MediaController.Listener {
                        override fun onExtrasChanged(controller: MediaController, extras: Bundle) {
                            applyExtras(extras)
                        }
                    })
                    .buildAsync()
                    .await()
            }.getOrNull() ?: return@launch

            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = refresh()
            })
            applyExtras(c.sessionExtras)
            refresh()

            while (isActive) {
                if (c.isPlaying) _ui.update { it.copy(positionMs = c.currentPosition.coerceAtLeast(0)) }
                delay(500)
            }
        }
    }

    private fun applyExtras(extras: Bundle) {
        _ui.update {
            it.copy(
                quality = Quality(
                    codec = extras.getString(PlaybackService.EX_CODEC, ""),
                    sampleRate = extras.getInt(PlaybackService.EX_RATE, 0),
                    bits = extras.getInt(PlaybackService.EX_BITS, 0),
                    channels = extras.getInt(PlaybackService.EX_CHANNELS, 0),
                    bitrateKbps = extras.getInt(PlaybackService.EX_BITRATE, 0),
                ),
                chain = AudioChain(
                    decoder = extras.getString(PlaybackService.EX_DECODER, ""),
                    appOutput = extras.getString(PlaybackService.EX_APP_OUT, ""),
                    path = extras.getString(PlaybackService.EX_PATH, ""),
                    direct = extras.getBoolean(PlaybackService.EX_DIRECT, false),
                    directAvailable = extras.getBoolean(PlaybackService.EX_DIRECT_AVAILABLE, false),
                    deviceType = extras.getString(PlaybackService.EX_DEV_TYPE, ""),
                    dacName = extras.getString(PlaybackService.EX_DAC, ""),
                    deviceMaxRate = extras.getInt(PlaybackService.EX_DEV_MAX_RATE, 0),
                    deviceMaxBits = extras.getInt(PlaybackService.EX_DEV_MAX_BITS, 0),
                    usb = extras.getBoolean(PlaybackService.EX_USB, false),
                    lgQuadDacInUse = extras.getBoolean(PlaybackService.EX_LG_QUAD, false),
                    lgPhone = extras.getBoolean(PlaybackService.EX_LG_PHONE, false),
                    lgState = extras.getString(PlaybackService.EX_LG_STATE, ""),
                ),
                bitPerfectOn = extras.getBoolean(PlaybackService.EX_BP_ENABLED, false),
                bitPerfectStatus = extras.getString(PlaybackService.EX_BP_STATUS, ""),
            )
        }
    }

    private fun refresh() {
        val c = controller ?: return
        val queue = (0 until c.mediaItemCount).map { i ->
            val item = c.getMediaItemAt(i)
            byId[item.mediaId] ?: Track.fromMediaItem(item)
        }
        val current = c.currentMediaItem?.let { byId[it.mediaId] ?: Track.fromMediaItem(it) }
        val md = c.mediaMetadata
        val tags = TagInfo(
            albumArtist = md.albumArtist?.toString().orEmpty(),
            year = md.recordingYear ?: md.releaseYear ?: 0,
            genre = md.genre?.toString().orEmpty(),
            composer = md.composer?.toString().orEmpty(),
            disc = md.discNumber ?: 0,
            trackOf = md.totalTrackCount?.let { total -> "${md.trackNumber ?: 0}/$total" }.orEmpty(),
            artwork = md.artworkData,
        )
        val dur = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: (current?.durationMs ?: 0L)
        _ui.update {
            it.copy(
                connected = true,
                current = current,
                isPlaying = c.isPlaying,
                positionMs = c.currentPosition.coerceAtLeast(0),
                durationMs = dur,
                shuffle = c.shuffleModeEnabled,
                repeatMode = c.repeatMode,
                queue = queue,
                index = c.currentMediaItemIndex,
                tags = tags,
            )
        }
    }

    // ---- Ações -------------------------------------------------------------------------

    fun playList(list: List<Track>, startIndex: Int, shuffle: Boolean = false) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.shuffleModeEnabled = shuffle
        val start = if (shuffle) list.indices.random() else startIndex
        c.setMediaItems(list.map { it.toMediaItem(defaultArt) }, start, 0L)
        c.prepare()
        c.play()
    }

    fun playNext(track: Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return playList(listOf(track), 0)
        c.addMediaItem(c.currentMediaItemIndex + 1, track.toMediaItem(defaultArt))
    }

    fun addToQueue(track: Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return playList(listOf(track), 0)
        c.addMediaItem(track.toMediaItem(defaultArt))
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(c.currentMediaItemIndex, 0)
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun previous() {
        val c = controller ?: return
        // Comportamento padrão: volta ao início se passou de 3 s, senão vai para a anterior.
        c.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _ui.update { it.copy(positionMs = ms) }
    }

    fun jumpTo(index: Int) {
        val c = controller ?: return
        c.seekTo(index, 0)
        c.play()
    }

    fun removeFromQueue(index: Int) { controller?.removeMediaItem(index) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setBitPerfect(on: Boolean) {
        val c = controller ?: return
        _ui.update { it.copy(bitPerfectOn = on) }
        val args = Bundle().apply { putBoolean(PlaybackService.ARG_ENABLED, on) }
        c.sendCustomCommand(SessionCommand(PlaybackService.CMD_SET_BITPERFECT, Bundle.EMPTY), args)
    }

    /** Relê a saída de áudio (ex.: depois de mudar o Quad DAC nos ajustes do sistema). */
    fun refreshOutput() {
        controller?.sendCustomCommand(SessionCommand(PlaybackService.CMD_REFRESH_OUTPUT, Bundle.EMPTY), Bundle.EMPTY)
    }

    override fun onCleared() {
        controller?.release()
        controller = null
    }
}
