package com.hires.player

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import java.io.File
import java.io.FileNotFoundException
import java.util.concurrent.ConcurrentHashMap

/**
 * Capas guardadas em arquivo (cache do app), uma por música. Servem a notificação,
 * a tela de bloqueio, o Android Auto e o widget, mesmo com o app em segundo plano.
 */
object CoverStore {
    private val locks = ConcurrentHashMap<Long, Any>()
    private const val MAX = 720

    private fun dir(context: Context) = File(context.cacheDir, "capas").apply { mkdirs() }

    /** Arquivo JPEG com a capa da música (embutida, miniatura do Android ou o disco padrão). */
    fun file(context: Context, trackId: Long): File {
        val f = File(dir(context), "$trackId.jpg")
        if (f.length() > 0) return f
        val lock = locks.getOrPut(trackId) { Any() }
        synchronized(lock) {
            if (f.length() > 0) return f
            val bmp = extract(context, trackId) ?: return defaultFile(context)
            val tmp = File(f.path + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            tmp.renameTo(f)
            return if (f.length() > 0) f else defaultFile(context)
        }
    }

    /** A capa já reduzida para um tamanho máximo (para o widget). */
    fun bitmap(context: Context, trackId: Long, maxPx: Int): Bitmap? = runCatching {
        decodeScaled(file(context, trackId).readBytes(), maxPx)
    }.getOrNull()

    private fun defaultFile(context: Context): File {
        val f = File(dir(context), "padrao.jpg")
        if (f.length() > 0) return f
        synchronized(this) {
            if (f.length() == 0L) {
                val bmp = BitmapFactory.decodeResource(context.resources, R.drawable.default_cover)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            }
        }
        return f
    }

    private fun extract(context: Context, trackId: Long): Bitmap? {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, trackId)
        // 1) Capa embutida no arquivo (FLAC, MP3, M4A…)
        runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, uri)
                r.embeddedPicture?.let { bytes -> decodeScaled(bytes, MAX)?.let { return it } }
            } finally {
                runCatching { r.release() }
            }
        }
        // 2) Miniatura que o Android gera (capa da pasta, por exemplo)
        runCatching { return context.contentResolver.loadThumbnail(uri, Size(512, 512), null) }
        return null
    }

    fun decodeScaled(bytes: ByteArray, maxPx: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxPx && bounds.outHeight / (sample * 2) >= maxPx) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val big = maxOf(bmp.width, bmp.height)
        if (big <= maxPx) return bmp
        val k = maxPx.toFloat() / big
        return Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    }
}

/**
 * Entrega as capas por um endereço content:// (só leitura). Assim qualquer parte do sistema
 * que carrega a capa pelo endereço (notificação, Android Auto, widget) recebe a capa certa.
 */
class CoverProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw SecurityException("Somente leitura")
        val id = uri.lastPathSegment?.toLongOrNull() ?: throw FileNotFoundException(uri.toString())
        val f = CoverStore.file(context ?: throw FileNotFoundException(), id)
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri): String = "image/jpeg"
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    companion object {
        const val AUTHORITY = "com.dosec.waffles.music.capas"
        fun uriFor(trackId: Long): Uri = Uri.parse("content://$AUTHORITY/capa/$trackId")
    }
}
