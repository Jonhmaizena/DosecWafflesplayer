package com.hires.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Playlist(
    val id: String,
    val name: String,
    val trackIds: List<Long>,
)

data class UserLibrary(
    val favorites: List<Long> = emptyList(),   // ordem: mais recente primeiro
    val playlists: List<Playlist> = emptyList(),
)

/**
 * Favoritos e playlists, salvos num arquivo JSON dentro do app.
 * As músicas são guardadas pelo ID do MediaStore do Android.
 */
class LibraryStore(context: Context) {

    private val file = File(context.filesDir, "biblioteca.json")

    fun load(): UserLibrary = runCatching {
        if (!file.exists()) return UserLibrary()
        val root = JSONObject(file.readText())
        val favs = root.optJSONArray("favoritos").toLongList()
        val lists = root.optJSONArray("playlists")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Playlist(
                    id = o.getString("id"),
                    name = o.getString("nome"),
                    trackIds = o.optJSONArray("faixas").toLongList(),
                )
            }
        } ?: emptyList()
        UserLibrary(favs, lists)
    }.getOrDefault(UserLibrary())

    fun save(lib: UserLibrary) {
        val root = JSONObject()
        root.put("versao", 1)
        root.put("favoritos", JSONArray(lib.favorites))
        root.put("playlists", JSONArray().apply {
            lib.playlists.forEach { p ->
                put(JSONObject().apply {
                    put("id", p.id)
                    put("nome", p.name)
                    put("faixas", JSONArray(p.trackIds))
                })
            }
        })
        // Grava num arquivo temporário e troca, para nunca corromper a biblioteca
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(root.toString())
        tmp.renameTo(file)
    }

    companion object {
        fun newId(): String = UUID.randomUUID().toString()

        private fun JSONArray?.toLongList(): List<Long> =
            if (this == null) emptyList() else (0 until length()).map { getLong(it) }
    }
}

/**
 * Avisa o app e o serviço de reprodução quando os favoritos mudam fora deles
 * (ex.: coração tocado no Android Auto ou na notificação), para manter tudo igual.
 */
object FavoriteSync {
    private val listeners = java.util.concurrent.CopyOnWriteArrayList<(String) -> Unit>()
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    fun listen(l: (String) -> Unit) { listeners += l }
    fun stop(l: (String) -> Unit) { listeners -= l }

    /** [source]: quem mudou ("app" ou "servico"). */
    fun changed(source: String) = main.post { listeners.forEach { it(source) } }
}
