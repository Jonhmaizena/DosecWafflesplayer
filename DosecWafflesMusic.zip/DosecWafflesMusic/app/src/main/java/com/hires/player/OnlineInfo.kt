package com.hires.player

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/** Informações do artista vindas da internet (MusicBrainz + Wikipedia). */
data class ArtistInfo(
    val name: String,
    val type: String,
    val country: String,
    val begin: String,
    val end: String,
    val genres: List<String>,
    val bio: String,
    val wikiUrl: String,
    val imagePath: String,
)

/** Informações do álbum (MusicBrainz + Wikipedia). */
data class AlbumInfo(
    val title: String,
    val artist: String,
    val date: String,
    val type: String,
    val label: String,
    val trackCount: Int,
    val genres: List<String>,
    val description: String,
    val wikiUrl: String,
)

/** Informações da música (MusicBrainz) e se há letra salva (LRCLIB). */
data class SongInfo(
    val title: String,
    val artist: String,
    val firstRelease: String,
    val lengthMs: Long,
    val isrc: String,
    val genres: List<String>,
    val hasLyrics: Boolean,
)

/** Resultado de uma busca: encontrado, não encontrado ou sem internet (e sem dados salvos). */
sealed class Lookup<out T> {
    data class Found<T>(val value: T, val fromCache: Boolean) : Lookup<T>()
    data object NotFound : Lookup<Nothing>()
    data object Offline : Lookup<Nothing>()
}

/**
 * Busca na internet informações sobre artista, álbum e música a partir dos metadados,
 * e guarda tudo no aparelho para funcionar offline depois.
 *
 * Fontes abertas e gratuitas: MusicBrainz (dados), Wikipedia (biografia e foto) e
 * LRCLIB (letras sincronizadas). Só são enviados nome do artista, do álbum e da música.
 */
object OnlineInfo {
    private const val UA = "TomMusicPlayer/7.1 (https://github.com/Jonhmaizena/Player-udio-)"
    private const val RETRY_MS = 7L * 24 * 3600 * 1000 // "não encontrado" é refeito depois de 7 dias
    private var lastMb = 0L

    fun enabled(context: Context) =
        context.getSharedPreferences("info", Context.MODE_PRIVATE).getBoolean("online", true)

    fun setEnabled(context: Context, on: Boolean) =
        context.getSharedPreferences("info", Context.MODE_PRIVATE).edit().putBoolean("online", on).apply()

    /** Artista/álbum genérico ("desconhecido") não é buscado. */
    private val unknownNames = setOf(
        "artista desconhecido", "unknown artist", "artista desconocido", "<unknown>",
        "álbum desconhecido", "unknown album", "álbum desconocido", "vários artistas", "various artists", "varios artistas", "",
    )

    fun isUnknown(name: String) = name.trim().lowercase() in unknownNames

    // ---- Cache ------------------------------------------------------------------------------

    private fun dir(context: Context) = File(context.filesDir, "info").apply { mkdirs() }

    private fun key(vararg parts: String): String {
        val md = MessageDigest.getInstance("SHA-1").digest(parts.joinToString("\u0001") { it.trim().lowercase() }.toByteArray())
        return md.joinToString("") { "%02x".format(it) }.take(24)
    }

    private fun read(context: Context, name: String): JSONObject? =
        runCatching { JSONObject(File(dir(context), name).readText()) }.getOrNull()

    private fun write(context: Context, name: String, json: JSONObject) {
        runCatching {
            val f = File(dir(context), name)
            val tmp = File(f.path + ".tmp")
            tmp.writeText(json.toString())
            tmp.renameTo(f)
        }
    }

    private fun stale(j: JSONObject) = j.optBoolean("notFound") && System.currentTimeMillis() - j.optLong("t") > RETRY_MS

    /** Quanto ocupa o que já foi baixado. */
    fun cacheSize(context: Context): Long = dir(context).listFiles()?.sumOf { it.length() } ?: 0L

    fun clearCache(context: Context) { dir(context).listFiles()?.forEach { it.delete() } }

    // ---- HTTP -------------------------------------------------------------------------------

    private class NotFound : Exception()

    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        try {
            val code = c.responseCode
            if (code == 404) return null
            if (code == 503 || code == 429) {
                Thread.sleep(2000)
                throw java.io.IOException("Serviço ocupado ($code)")
            }
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** MusicBrainz pede no máximo uma consulta por segundo. */
    private fun mb(path: String): JSONObject? {
        synchronized(this) {
            val wait = 1100 - (System.currentTimeMillis() - lastMb)
            if (wait > 0) Thread.sleep(wait)
            lastMb = System.currentTimeMillis()
        }
        return get("https://musicbrainz.org/ws/2/$path")?.let { JSONObject(it) }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /** Escapa caracteres especiais da busca do MusicBrainz (Lucene). */
    private fun lucene(s: String) = s.replace(Regex("""([+\-&|!(){}\[\]^"~*?:\\/])"""), "\\\\$1")

    private fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}"), "").replace(Regex("[^a-z0-9]"), "")

    private fun genresOf(j: JSONObject): List<String> {
        val arr = j.optJSONArray("genres")?.takeIf { it.length() > 0 } ?: j.optJSONArray("tags") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .sortedByDescending { it.optInt("count") }
            .map { it.optString("name") }
            .filter { it.isNotBlank() }
            .take(5)
    }

    private fun wikidataId(relations: JSONArray?): String? {
        relations ?: return null
        for (i in 0 until relations.length()) {
            val r = relations.getJSONObject(i)
            if (r.optString("type") == "wikidata") {
                return r.optJSONObject("url")?.optString("resource")?.substringAfterLast('/')?.takeIf { it.startsWith("Q") }
            }
        }
        return null
    }

    // ---- Wikipedia --------------------------------------------------------------------------

    private fun wikiLangs() = listOf(L.lang, "en").distinct()

    /** Resumo da Wikipedia no idioma do app (ou em inglês), a partir do Wikidata. */
    private fun wikiSummary(qid: String?, fallbackTitle: String?, musicOnly: Boolean): JSONObject? {
        val langs = wikiLangs()
        if (qid != null) {
            val sites = langs.joinToString("|") { "${it}wiki" }
            val wd = get("https://www.wikidata.org/w/api.php?action=wbgetentities&ids=$qid&props=sitelinks&sitefilter=$sites&format=json")
                ?.let { JSONObject(it) }
            val links = wd?.optJSONObject("entities")?.optJSONObject(qid)?.optJSONObject("sitelinks")
            for (lang in langs) {
                val title = links?.optJSONObject("${lang}wiki")?.optString("title")?.takeIf { it.isNotBlank() } ?: continue
                summary(lang, title)?.let { return it.put("lang", lang) }
            }
        }
        // Sem Wikidata: tenta a página com o nome exato, só se for claramente sobre música
        if (fallbackTitle != null) {
            for (lang in langs) {
                val s = summary(lang, fallbackTitle) ?: continue
                if (s.optString("type") == "disambiguation") continue
                val d = (s.optString("description") + " " + s.optString("extract").take(200)).lowercase()
                val music = listOf(
                    "band", "singer", "musician", "rapper", "group", "duo", "composer", "dj", "orchestra", "album",
                    "banda", "cantor", "cantora", "músico", "grupo", "dupla", "compositor", "orquestra", "álbum",
                    "cantante", "músico", "orquesta", "disco", "álbum de estudio", "studio album",
                )
                if (!musicOnly || music.any { it in d }) return s.put("lang", lang)
            }
        }
        return null
    }

    private fun summary(lang: String, title: String): JSONObject? = runCatching {
        get("https://$lang.wikipedia.org/api/rest_v1/page/summary/${enc(title.replace(' ', '_'))}")?.let { JSONObject(it) }
    }.getOrNull()

    private fun download(url: String, to: File): Boolean = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        try {
            if (c.responseCode !in 200..299) return false
            val tmp = File(to.path + ".tmp")
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.renameTo(to)
        } finally {
            c.disconnect()
        }
    }.getOrDefault(false)

    // ---- Artista ----------------------------------------------------------------------------

    fun artist(context: Context, name: String, online: Boolean = enabled(context)): Lookup<ArtistInfo> {
        if (isUnknown(name)) return Lookup.NotFound
        val file = "artista_${key(name)}.json"
        val cached = read(context, file)
        // O resumo da Wikipedia é guardado por idioma; troca de idioma busca de novo quando há internet
        if (cached != null && !stale(cached) && (cached.optBoolean("notFound") || cached.has("bio_" + L.lang) || !online)) {
            return if (cached.optBoolean("notFound")) Lookup.NotFound else Lookup.Found(parseArtist(context, cached, name), true)
        }
        if (!online) return cached?.let { if (it.optBoolean("notFound")) Lookup.NotFound else Lookup.Found(parseArtist(context, it, name), true) } ?: Lookup.Offline
        return try {
            val j = cached?.takeIf { !it.optBoolean("notFound") } ?: fetchArtist(name)
            if (j == null) {
                write(context, file, JSONObject().put("notFound", true).put("t", System.currentTimeMillis()))
                Lookup.NotFound
            } else {
                if (!j.has("bio_" + L.lang)) {
                    val s = wikiSummary(j.optString("wikidata").ifBlank { null }, name, musicOnly = true)
                    j.put("bio_" + L.lang, s?.optString("extract").orEmpty())
                    j.put("wiki_" + L.lang, s?.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page").orEmpty())
                    val img = s?.optJSONObject("thumbnail")?.optString("source")
                    if (!img.isNullOrBlank() && !File(dir(context), "foto_${key(name)}.jpg").exists()) {
                        val big = img.replace(Regex("/\\d+px-"), "/640px-")
                        val target = File(dir(context), "foto_${key(name)}.jpg")
                        if (!download(big, target)) download(img, target)
                    }
                }
                j.put("t", System.currentTimeMillis())
                write(context, file, j)
                Lookup.Found(parseArtist(context, j, name), false)
            }
        } catch (e: Exception) {
            cached?.takeIf { !it.optBoolean("notFound") }?.let { Lookup.Found(parseArtist(context, it, name), true) } ?: Lookup.Offline
        }
    }

    private fun fetchArtist(name: String): JSONObject? {
        val search = mb("artist/?query=${enc("artist:\"${lucene(name)}\"")}&fmt=json&limit=5") ?: return null
        val list = search.optJSONArray("artists") ?: return null
        var pick: JSONObject? = null
        for (i in 0 until list.length()) {
            val a = list.getJSONObject(i)
            if (a.optInt("score") < 85) continue
            if (norm(a.optString("name")) == norm(name) || pick == null) {
                pick = a
                if (norm(a.optString("name")) == norm(name)) break
            }
        }
        pick ?: return null
        val id = pick.optString("id")
        val full = mb("artist/$id?inc=url-rels+genres+tags&fmt=json") ?: pick
        val life = full.optJSONObject("life-span")
        return JSONObject()
            .put("name", full.optString("name", name))
            .put("type", full.optString("type"))
            .put("country", full.optJSONObject("area")?.optString("name").orEmpty())
            .put("begin", life?.optString("begin").orEmpty())
            .put("end", life?.optString("end").orEmpty())
            .put("genres", JSONArray(genresOf(full)))
            .put("wikidata", wikidataId(full.optJSONArray("relations")).orEmpty())
    }

    private fun parseArtist(context: Context, j: JSONObject, asked: String): ArtistInfo {
        val name = j.optString("name").ifBlank { asked }
        val photo = File(dir(context), "foto_${key(asked)}.jpg").takeIf { it.exists() }
        val lang = if (j.has("bio_" + L.lang)) L.lang else listOf("pt", "en", "es").firstOrNull { j.optString("bio_$it").isNotBlank() } ?: L.lang
        return ArtistInfo(
            name = name,
            type = j.optString("type"),
            country = j.optString("country"),
            begin = j.optString("begin"),
            end = j.optString("end"),
            genres = j.optJSONArray("genres")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty(),
            bio = j.optString("bio_$lang"),
            wikiUrl = j.optString("wiki_$lang"),
            imagePath = photo?.path.orEmpty(),
        )
    }

    /** Foto do artista salva com o nome pedido (o nome no MusicBrainz pode ter outra grafia). */
    fun artistPhoto(context: Context, name: String): File? =
        File(dir(context), "foto_${key(name)}.jpg").takeIf { it.exists() }

    // ---- Álbum ------------------------------------------------------------------------------

    fun album(context: Context, artist: String, album: String, online: Boolean = enabled(context)): Lookup<AlbumInfo> {
        if (isUnknown(album)) return Lookup.NotFound
        val file = "album_${key(artist, album)}.json"
        val cached = read(context, file)
        if (cached != null && !stale(cached) && (cached.optBoolean("notFound") || cached.has("desc_" + L.lang) || !online)) {
            return if (cached.optBoolean("notFound")) Lookup.NotFound else Lookup.Found(parseAlbum(cached), true)
        }
        if (!online) return Lookup.Offline
        return try {
            val j = cached?.takeIf { !it.optBoolean("notFound") } ?: fetchAlbum(artist, album)
            if (j == null) {
                write(context, file, JSONObject().put("notFound", true).put("t", System.currentTimeMillis()))
                Lookup.NotFound
            } else {
                if (!j.has("desc_" + L.lang)) {
                    val s = wikiSummary(j.optString("wikidata").ifBlank { null }, null, musicOnly = true)
                    j.put("desc_" + L.lang, s?.optString("extract").orEmpty())
                    j.put("wiki_" + L.lang, s?.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page").orEmpty())
                }
                j.put("t", System.currentTimeMillis())
                write(context, file, j)
                Lookup.Found(parseAlbum(j), false)
            }
        } catch (e: Exception) {
            cached?.takeIf { !it.optBoolean("notFound") }?.let { Lookup.Found(parseAlbum(it), true) } ?: Lookup.Offline
        }
    }

    private fun fetchAlbum(artist: String, album: String): JSONObject? {
        val q = buildString {
            append("releasegroup:\"${lucene(album)}\"")
            if (!isUnknown(artist)) append(" AND artist:\"${lucene(artist)}\"")
        }
        val search = mb("release-group/?query=${enc(q)}&fmt=json&limit=5") ?: return null
        val list = search.optJSONArray("release-groups") ?: return null
        var pick: JSONObject? = null
        for (i in 0 until list.length()) {
            val g = list.getJSONObject(i)
            if (g.optInt("score") < 85) continue
            if (pick == null || norm(g.optString("title")) == norm(album)) {
                pick = g
                if (norm(g.optString("title")) == norm(album)) break
            }
        }
        pick ?: return null
        val id = pick.optString("id")
        val full = mb("release-group/$id?inc=url-rels+genres+tags+releases+artist-credits&fmt=json") ?: pick
        var label = ""
        var tracks = 0
        val firstRelease = full.optJSONArray("releases")?.let { r ->
            (0 until r.length()).map { r.getJSONObject(it) }.minByOrNull { it.optString("date").ifBlank { "9999" } }
        }
        if (firstRelease != null) {
            mb("release/${firstRelease.optString("id")}?inc=labels+media&fmt=json")?.let { rel ->
                label = rel.optJSONArray("label-info")?.optJSONObject(0)?.optJSONObject("label")?.optString("name").orEmpty()
                val media = rel.optJSONArray("media")
                if (media != null) for (i in 0 until media.length()) tracks += media.getJSONObject(i).optInt("track-count")
            }
        }
        val credit = full.optJSONArray("artist-credit")?.let { a ->
            (0 until a.length()).joinToString("") { a.getJSONObject(it).let { c -> c.optString("name") + c.optString("joinphrase") } }
        }.orEmpty()
        return JSONObject()
            .put("title", full.optString("title", album))
            .put("artist", credit.ifBlank { artist })
            .put("date", full.optString("first-release-date"))
            .put("type", full.optString("primary-type"))
            .put("label", label)
            .put("tracks", tracks)
            .put("genres", JSONArray(genresOf(full)))
            .put("wikidata", wikidataId(full.optJSONArray("relations")).orEmpty())
    }

    private fun parseAlbum(j: JSONObject): AlbumInfo {
        val lang = if (j.has("desc_" + L.lang)) L.lang else listOf("pt", "en", "es").firstOrNull { j.optString("desc_$it").isNotBlank() } ?: L.lang
        return AlbumInfo(
            title = j.optString("title"),
            artist = j.optString("artist"),
            date = j.optString("date"),
            type = j.optString("type"),
            label = j.optString("label"),
            trackCount = j.optInt("tracks"),
            genres = j.optJSONArray("genres")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty(),
            description = j.optString("desc_$lang"),
            wikiUrl = j.optString("wiki_$lang"),
        )
    }

    // ---- Música -----------------------------------------------------------------------------

    fun song(context: Context, track: Track, online: Boolean = enabled(context)): Lookup<SongInfo> {
        val file = "musica_${key(track.artist, track.title)}.json"
        val cached = read(context, file)
        val hasLyrics = read(context, lyricsFile(track))?.let { !it.optBoolean("notFound") } == true
        if (cached != null && (!stale(cached) || !online)) {
            return if (cached.optBoolean("notFound")) Lookup.NotFound else Lookup.Found(parseSong(cached, hasLyrics), true)
        }
        if (!online) return Lookup.Offline
        return try {
            val q = buildString {
                append("recording:\"${lucene(track.title)}\"")
                if (!isUnknown(track.artist)) append(" AND artist:\"${lucene(track.artist)}\"")
            }
            val list = mb("recording/?query=${enc(q)}&fmt=json&limit=10")?.optJSONArray("recordings")
            var pick: JSONObject? = null
            if (list != null) for (i in 0 until list.length()) {
                val r = list.getJSONObject(i)
                if (r.optInt("score") < 85) continue
                // Prefere a gravação com duração parecida com a do arquivo
                val len = r.optLong("length")
                val close = track.durationMs <= 0 || len <= 0 || kotlin.math.abs(len - track.durationMs) < 15_000
                if (pick == null && close) pick = r
            }
            if (pick == null) {
                write(context, file, JSONObject().put("notFound", true).put("t", System.currentTimeMillis()))
                return Lookup.NotFound
            }
            val credit = pick.optJSONArray("artist-credit")?.let { a ->
                (0 until a.length()).joinToString("") { a.getJSONObject(it).let { c -> c.optString("name") + c.optString("joinphrase") } }
            }.orEmpty()
            val j = JSONObject()
                .put("title", pick.optString("title", track.title))
                .put("artist", credit.ifBlank { track.artist })
                .put("first", pick.optString("first-release-date"))
                .put("length", pick.optLong("length"))
                .put("isrc", pick.optJSONArray("isrcs")?.optString(0).orEmpty())
                .put("genres", JSONArray(genresOf(pick)))
                .put("t", System.currentTimeMillis())
            write(context, file, j)
            Lookup.Found(parseSong(j, hasLyrics), false)
        } catch (e: Exception) {
            cached?.takeIf { !it.optBoolean("notFound") }?.let { Lookup.Found(parseSong(it, hasLyrics), true) } ?: Lookup.Offline
        }
    }

    private fun parseSong(j: JSONObject, hasLyrics: Boolean) = SongInfo(
        title = j.optString("title"),
        artist = j.optString("artist"),
        firstRelease = j.optString("first"),
        lengthMs = j.optLong("length"),
        isrc = j.optString("isrc"),
        genres = j.optJSONArray("genres")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty(),
        hasLyrics = hasLyrics,
    )

    // ---- Letras (LRCLIB) --------------------------------------------------------------------

    private fun lyricsFile(t: Track) = "letra_${key(t.artist, t.title)}.json"

    /** Letra da internet para músicas sem letra no arquivo; guardada para uso offline. */
    fun lyrics(context: Context, t: Track, online: Boolean = enabled(context)): Lyrics? {
        val file = lyricsFile(t)
        val cached = read(context, file)
        if (cached != null && (!stale(cached) || !online)) return parseLyrics(cached)
        if (!online || isUnknown(t.artist)) return null
        return try {
            val sec = (t.durationMs / 1000).coerceAtLeast(0)
            var j = get(
                "https://lrclib.net/api/get?artist_name=${enc(t.artist)}&track_name=${enc(t.title)}" +
                    (if (!isUnknown(t.album)) "&album_name=${enc(t.album)}" else "") +
                    (if (sec > 0) "&duration=$sec" else "")
            )?.let { JSONObject(it) }
            if (j == null) {
                j = get("https://lrclib.net/api/search?artist_name=${enc(t.artist)}&track_name=${enc(t.title)}")
                    ?.let { JSONArray(it) }
                    ?.let { arr ->
                        (0 until arr.length()).map { arr.getJSONObject(it) }.firstOrNull { r ->
                            val d = (r.optDouble("duration", 0.0) * 1000).toLong()
                            sec <= 0 || d <= 0 || kotlin.math.abs(d - t.durationMs) < 5_000
                        }
                    }
            }
            val synced = j?.optString("syncedLyrics").orEmpty().takeIf { it != "null" }.orEmpty()
            val plain = j?.optString("plainLyrics").orEmpty().takeIf { it != "null" }.orEmpty()
            val out = if (synced.isBlank() && plain.isBlank()) JSONObject().put("notFound", true)
            else JSONObject().put("synced", synced).put("plain", plain)
            write(context, file, out.put("t", System.currentTimeMillis()))
            parseLyrics(out)
        } catch (e: Exception) {
            cached?.let { parseLyrics(it) }
        }
    }

    private fun parseLyrics(j: JSONObject): Lyrics? {
        if (j.optBoolean("notFound")) return null
        j.optString("synced").takeIf { it.isNotBlank() }?.let { s -> Lrc.parse(s)?.let { return Lyrics.Synced(it) } }
        return j.optString("plain").takeIf { it.isNotBlank() }?.let { Lyrics.Plain(it.trim()) }
    }
}

/**
 * Baixa as informações da biblioteca inteira (artistas, álbuns e letras) para usar offline.
 * Continua rodando enquanto o app estiver aberto, mesmo fora da tela de informações.
 */
object InfoDownloader {
    data class Progress(val running: Boolean = false, val done: Int = 0, val total: Int = 0, val current: String = "")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress.asStateFlow()

    fun start(context: Context, tracks: List<Track>) {
        if (job?.isActive == true) return
        val app = context.applicationContext
        job = scope.launch {
            val artists = tracks.map { it.artist }.filterNot { OnlineInfo.isUnknown(it) }.distinct()
            val albums = tracks.filterNot { OnlineInfo.isUnknown(it.album) }.distinctBy { it.albumId }
            val total = artists.size + albums.size + tracks.size
            var done = 0
            fun step(label: String) { done++; _progress.value = Progress(true, done, total, label) }
            _progress.value = Progress(true, 0, total, "")
            for (a in artists) { if (!isActive) break; runCatching { OnlineInfo.artist(app, a, online = true) }; step(a) }
            for (t in albums) { if (!isActive) break; runCatching { OnlineInfo.album(app, t.artist, t.album, online = true) }; step(t.album) }
            for (t in tracks) { if (!isActive) break; runCatching { OnlineInfo.lyrics(app, t, online = true) }; step(t.title) }
            _progress.value = Progress(false, done, total, "")
        }
    }

    fun cancel() {
        job?.cancel()
        _progress.value = _progress.value.copy(running = false)
    }
}
