package com.hires.player

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Reamostrador sinc com janela de Kaiser (β = 9, ~90 dB de rejeição), 32 cruzamentos
 * de zero de cada lado, em ponto flutuante de 32 bits. É o mesmo tipo de filtro usado
 * por conversores de estúdio, muito mais limpo que o conversor padrão do Android.
 */
class SincResampler(inRate: Int, outRate: Int, private val channels: Int) {

    private val step = inRate.toDouble() / outRate            // amostras de entrada por saída
    private val fc = min(1.0, outRate.toDouble() / inRate) * 0.97 // corte normalizado (Nyquist = 1)
    private val halfWidth = ZERO_CROSSINGS / fc                // meia largura do filtro em amostras de entrada
    private val reach = ceil(halfWidth).toInt()
    val taps: Int get() = reach * 2

    private val table: FloatArray            // kernel amostrado de 0 a halfWidth
    private var history = FloatArray(0)      // amostras intercaladas ainda necessárias
    private var frames = 0                   // quadros válidos em history
    private var t = 0.0                      // posição da próxima saída, em quadros de history

    init {
        val size = (halfWidth * RES).toInt() + 2
        val i0Beta = besselI0(BETA)
        table = FloatArray(size) { i ->
            val x = i.toDouble() / RES
            if (x >= halfWidth) 0f else {
                val r = x / halfWidth
                val window = besselI0(BETA * sqrt(1 - r * r)) / i0Beta
                (fc * sinc(fc * x) * window).toFloat()
            }
        }
        reset()
    }

    fun reset() {
        // Começa com 'reach' quadros de silêncio para o filtro ter passado disponível
        frames = reach
        history = FloatArray(maxOf(4096, reach * 4) * channels)
        t = reach.toDouble()
    }

    /** Recebe quadros intercalados em float e devolve os quadros reamostrados. */
    fun process(input: FloatArray, inFrames: Int, out: FloatOutput) {
        ensureCapacity(frames + inFrames)
        System.arraycopy(input, 0, history, frames * channels, inFrames * channels)
        frames += inFrames

        val acc = DoubleArray(channels)
        while (t + reach < frames) {
            val center = floor(t).toInt()
            java.util.Arrays.fill(acc, 0.0)
            var j = center - reach + 1
            val end = center + reach
            while (j <= end) {
                val w = kernel(abs(j - t))
                if (w != 0f) {
                    val base = j * channels
                    for (c in 0 until channels) acc[c] += history[base + c] * w
                }
                j++
            }
            for (c in 0 until channels) out.put(acc[c].toFloat())
            t += step
        }

        // Descarta o que não será mais usado, mantendo o passado que o filtro precisa
        val keepFrom = (floor(t).toInt() - reach).coerceAtLeast(0)
        if (keepFrom > 0) {
            System.arraycopy(history, keepFrom * channels, history, 0, (frames - keepFrom) * channels)
            frames -= keepFrom
            t -= keepFrom
        }
    }

    private fun kernel(x: Double): Float {
        val pos = x * RES
        val i = pos.toInt()
        if (i >= table.size - 1) return 0f
        val f = (pos - i).toFloat()
        return table[i] + (table[i + 1] - table[i]) * f
    }

    private fun ensureCapacity(neededFrames: Int) {
        if (neededFrames * channels > history.size) {
            history = history.copyOf(maxOf(neededFrames * channels, history.size * 2))
        }
    }

    fun interface FloatOutput { fun put(v: Float) }

    companion object {
        const val ZERO_CROSSINGS = 32
        private const val RES = 1024
        private const val BETA = 9.0

        private fun sinc(x: Double) = if (x == 0.0) 1.0 else sin(PI * x) / (PI * x)

        private fun besselI0(x: Double): Double {
            var sum = 1.0
            var term = 1.0
            val q = x * x / 4
            var k = 1
            while (term > 1e-12 * sum) {
                term *= q / (k.toDouble() * k)
                sum += term
                k++
            }
            return sum
        }
    }
}

/**
 * Saída de áudio que, quando ligada, converte a faixa para a taxa do mixer do Android
 * com o [SincResampler] antes de entregar ao sistema. Assim o Android não precisa
 * reamostrar com o conversor dele. Desligada, repassa o áudio sem tocar em nada.
 */
@OptIn(UnstableApi::class)
class ResamplingAudioSink(sink: AudioSink) : ForwardingAudioSink(sink) {

    @Volatile var enabled = false
    @Volatile var targetRate = 48000

    private enum class Kind { NONE, OFF, UNSUPPORTED, SAME_RATE, INACTIVE, ACTIVE }
    @Volatile private var kind = Kind.NONE
    @Volatile private var kindInRate = 0
    @Volatile private var kindOutRate = 0
    @Volatile private var kindTaps = 0

    /** O reamostrador está convertendo a faixa atual. */
    val isActive: Boolean get() = kind == Kind.ACTIVE

    /** Descrição do que está acontecendo agora, para o painel (no idioma escolhido). */
    val status: String
        get() = when (kind) {
            Kind.NONE -> ""
            Kind.OFF -> tr("Desligado")
            Kind.UNSUPPORTED -> tr("Formato não suportado; tocando sem conversão")
            Kind.SAME_RATE -> trf("Sem conversão: a faixa já está em %1\$s", formatRate(kindInRate))
            Kind.INACTIVE -> tr("Inativo")
            Kind.ACTIVE -> trf("Ativo · %1\$s → %2\$s · sinc %3\$s pontos, 32-bit float", formatRate(kindInRate), formatRate(kindOutRate), kindTaps)
        }
    var onStatusChanged: (() -> Unit)? = null

    /** Palco (largura estéreo). Ligar/desligar vale na próxima configuração da saída. */
    @Volatile var widthOn = false
    /** 0,5 = mais estreito · 1,0 = original · 2,0 = bem mais aberto. Muda ao vivo. */
    @Volatile var width = 1.4f

    /** O Palco está atuando na faixa atual. */
    @Volatile var widthActive = false
        private set

    private var processing = false
    private var resampler: SincResampler? = null
    private var inEncoding = C.ENCODING_INVALID
    private var inRate = 48000
    private var outRate = 48000
    private var channels = 2
    private var floatIn = FloatArray(0)
    private var pending: ByteBuffer = ByteBuffer.allocateDirect(0)
    private var pendingTs = 0L
    private var hasPending = false
    // Filtro passa-baixa do sinal lateral: graves abaixo de ~150 Hz ficam no centro
    private var sideLow = 0f
    private var lowCoef = 0f

    override fun configure(inputFormat: Format, specifiedBufferSize: Int, outputChannels: IntArray?) {
        val enc = inputFormat.pcmEncoding
        val supported = inputFormat.sampleMimeType == MimeTypes.AUDIO_RAW && enc in SUPPORTED
        val inRate = inputFormat.sampleRate
        val rsActive = enabled && supported && targetRate > 0 && inRate > 0 && inRate != targetRate
        val wActive = widthOn && supported && inRate > 0 && inputFormat.channelCount == 2

        kindInRate = inRate
        kindOutRate = targetRate
        kind = when {
            rsActive -> Kind.ACTIVE
            !enabled -> Kind.OFF
            !supported -> Kind.UNSUPPORTED
            inRate == targetRate -> Kind.SAME_RATE
            else -> Kind.INACTIVE
        }
        widthActive = wActive

        if (!rsActive && !wActive) {
            processing = false
            resampler = null
            onStatusChanged?.invoke()
            super.configure(inputFormat, specifiedBufferSize, outputChannels)
            return
        }

        processing = true
        inEncoding = enc
        this.inRate = inRate
        channels = inputFormat.channelCount
        outRate = if (rsActive) targetRate else inRate
        sideLow = 0f
        lowCoef = (1.0 - kotlin.math.exp(-2.0 * PI * BASS_MONO_HZ / inRate)).toFloat()
        resampler = if (rsActive) SincResampler(inRate, targetRate, channels).also { rs -> kindTaps = rs.taps } else null
        onStatusChanged?.invoke()

        val outFormat = inputFormat.buildUpon()
            .setSampleRate(outRate)
            .setPcmEncoding(C.ENCODING_PCM_FLOAT)
            .build()
        super.configure(outFormat, 0, outputChannels)
    }

    /**
     * Palco: separa o centro (voz, baixo, bumbo) das laterais (instrumentos, ambiência)
     * em meio/lateral e ajusta a lateral. Abaixo de ~150 Hz nada muda, para os graves
     * continuarem firmes e no centro. O ganho é compensado para não estourar.
     */
    private fun applyWidth(frames: Int) {
        val w = width.coerceIn(0.5f, 2f)
        // Compensação leve: a lateral reforçada raramente chega no pico; o que passar é arredondado
        val gain = if (w > 1f) 1f / (1f + 0.25f * (w - 1f)) else 1f
        val a = lowCoef
        var low = sideLow
        var i = 0
        val n = frames * 2
        while (i < n) {
            val l = floatIn[i]
            val r = floatIn[i + 1]
            val mid = (l + r) * 0.5f
            val side = (l - r) * 0.5f
            low += a * (side - low)
            val s = low + w * (side - low)
            floatIn[i] = softClip((mid + s) * gain)
            floatIn[i + 1] = softClip((mid - s) * gain)
            i += 2
        }
        // Evita números subnormais (lentos) no silêncio
        sideLow = if (kotlin.math.abs(low) < 1e-20f) 0f else low
    }

    override fun handleBuffer(buffer: ByteBuffer, presentationTimeUs: Long, encodedAccessUnitCount: Int): Boolean {
        // Entrega primeiro o que sobrou da última vez, mesmo que a faixa nova não precise de conversão.
        // Nunca deixamos sobra pendente ao responder "true": a saída do Android exige receber
        // o mesmo buffer até o fim, e uma sobra esquecida na troca de faixa travava a reprodução.
        if (hasPending) {
            if (!super.handleBuffer(pending, pendingTs, 1)) return false
            hasPending = false
        }
        if (!processing) return super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
        if (!buffer.hasRemaining()) return true

        val frames = toFloat(buffer)
        if (widthActive) applyWidth(frames)
        val outCapacity = ((frames.toDouble() * outRate / inRate) + 64).toInt() * channels * 4
        if (pending.capacity() < outCapacity) {
            pending = ByteBuffer.allocateDirect(outCapacity * 2).order(ByteOrder.nativeOrder())
        }
        pending.clear()
        val out = pending
        val rs = resampler
        if (rs != null) {
            rs.process(floatIn, frames) { v ->
                if (out.remaining() < 4) return@process
                out.putFloat(v)
            }
        } else {
            out.asFloatBuffer().put(floatIn, 0, frames * channels)
            out.position(frames * channels * 4)
        }
        pending.flip()
        pendingTs = presentationTimeUs
        hasPending = pending.hasRemaining()
        if (hasPending && super.handleBuffer(pending, pendingTs, 1)) hasPending = false
        // Entrada já consumida; se sobrou saída, o player chama de novo e a sobra é entregue acima
        return !hasPending
    }

    /** Converte o buffer de entrada (16/24/32-bit ou float) para float intercalado. */
    private fun toFloat(buffer: ByteBuffer): Int {
        val b = buffer.order(ByteOrder.LITTLE_ENDIAN)
        val bytesPerSample = when (inEncoding) {
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_24BIT -> 3
            else -> 4
        }
        val samples = b.remaining() / bytesPerSample
        if (floatIn.size < samples) floatIn = FloatArray(samples)
        var i = 0
        when (inEncoding) {
            C.ENCODING_PCM_16BIT -> while (i < samples) { floatIn[i++] = b.short / 32768f }
            C.ENCODING_PCM_24BIT -> while (i < samples) {
                val lo = b.get().toInt() and 0xFF
                val mid = b.get().toInt() and 0xFF
                val hi = b.get().toInt()
                floatIn[i++] = ((hi shl 16) or (mid shl 8) or lo) / 8388608f
            }
            C.ENCODING_PCM_32BIT -> while (i < samples) { floatIn[i++] = b.int / 2147483648f }
            else -> while (i < samples) { floatIn[i++] = b.float }
        }
        buffer.position(buffer.limit())
        return samples / channels
    }

    override fun playToEndOfStream() {
        if (hasPending) {
            if (!super.handleBuffer(pending, pendingTs, 1)) return
            hasPending = false
        }
        super.playToEndOfStream()
    }

    override fun isEnded(): Boolean = !hasPending && super.isEnded()

    override fun hasPendingData(): Boolean = hasPending || super.hasPendingData()

    override fun flush() {
        hasPending = false
        sideLow = 0f
        resampler?.reset()
        super.flush()
    }

    override fun reset() {
        hasPending = false
        processing = false
        widthActive = false
        resampler = null
        super.reset()
    }

    /** Linear até 0,9; acima disso arredonda suavemente até 1,0 em vez de cortar. */
    private fun softClip(x: Float): Float {
        val a = kotlin.math.abs(x)
        if (a <= 0.9f) return x
        val y = 0.9f + 0.1f * kotlin.math.tanh((a - 0.9f) / 0.1f)
        return if (x < 0f) -y else y
    }

    companion object {
        private const val BASS_MONO_HZ = 150.0
        private val SUPPORTED = setOf(
            C.ENCODING_PCM_16BIT, C.ENCODING_PCM_24BIT, C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT
        )
    }
}
