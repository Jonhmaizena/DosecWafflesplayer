package com.hires.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.provider.Settings

/** Retrato da saída de áudio que o Android está usando agora. */
data class OutputInfo(
    val deviceType: String,          // "Fone com fio", "DAC USB", "Bluetooth", "Alto-falante"
    val deviceName: String,          // nome informado pelo aparelho
    val dacName: String,             // DAC que converte o sinal
    val maxRate: Int,                // maior taxa que a saída aceita (0 = não informado)
    val maxBits: Int,                // maior profundidade que a saída aceita (0 = não informado)
    val mixerRate: Int,              // taxa do mixer do Android
    val isUsb: Boolean,
    val isWired: Boolean,
    val isBluetooth: Boolean,
    val lgQuadDac: Boolean,          // aparelho LG com Hi-Fi Quad DAC e saída P2 em uso
    val quadDacState: String,        // "Ativado", "Desativado" ou "" se o sistema não informa
    val directAvailable: Boolean,    // o sistema aceita saída direta (sem mixer) para o formato atual
    val customRom: String,           // "LineageOS" etc., quando o sistema não é o original da LG
    val quadDacMode: String,         // modo de impedância do Quad DAC, quando o sistema informa
)

class OutputInspector(private val context: Context) {

    private val am = context.getSystemService(AudioManager::class.java)

    private val mediaAttrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    fun inspect(sampleRate: Int): OutputInfo {
        val device = currentDevice()
        val type = device?.type ?: AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
        val isUsb = type in USB_TYPES
        val isWired = type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        val isBt = type in BT_TYPES
        val lgModel = LgQuadDac.chip()
        val lgActive = isWired && lgModel != null
        val name = device?.productName?.toString()?.takeIf { it.isNotBlank() && it != Build.MODEL } ?: ""

        val lgState = if (lgModel != null) quadDacState() else ""
        val dac = when {
            isUsb -> name.ifEmpty { "DAC USB" }
            lgActive && lgState == "Desativado" -> "DAC interno do aparelho (Quad DAC desligado)"
            lgActive -> "LG Hi-Fi Quad DAC · ESS SABRE $lgModel"
            isWired -> "DAC interno do aparelho"
            isBt -> "DAC do fone Bluetooth" + if (name.isNotEmpty()) " ($name)" else ""
            else -> "DAC interno do aparelho"
        }

        val rates = device?.sampleRates ?: IntArray(0)
        val encodings = device?.encodings ?: IntArray(0)
        val maxBits = when {
            encodings.isEmpty() -> 0
            encodings.any { it == AudioFormat.ENCODING_PCM_FLOAT || it == AudioFormat.ENCODING_PCM_32BIT } -> 32
            encodings.any { it == AudioFormat.ENCODING_PCM_24BIT_PACKED } -> 24
            else -> 16
        }

        return OutputInfo(
            deviceType = typeLabel(type),
            deviceName = name,
            dacName = dac,
            maxRate = rates.maxOrNull() ?: 0,
            maxBits = maxBits,
            mixerRate = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 0,
            isUsb = isUsb,
            isWired = isWired,
            isBluetooth = isBt,
            lgQuadDac = lgActive,
            quadDacState = lgState,
            directAvailable = sampleRate > 0 && directSupported(sampleRate),
            customRom = customRom(),
            quadDacMode = if (lgModel != null) quadDacMode() else "",
        )
    }

    /** Nome da ROM quando o sistema não é o original do fabricante. */
    private fun customRom(): String {
        val id = (Build.DISPLAY + " " + Build.HOST + " " + Build.VERSION.INCREMENTAL).lowercase()
        return when {
            "lineage" in id -> "LineageOS"
            "crdroid" in id -> "crDroid"
            "evolution" in id -> "Evolution X"
            "pixelexperience" in id || "pixel_experience" in id -> "Pixel Experience"
            else -> ""
        }
    }

    /** Dispositivo pelo qual a música está saindo. */
    private fun currentDevice(): AudioDeviceInfo? {
        val outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        if (Build.VERSION.SDK_INT >= 33) {
            val routed = runCatching { am.getAudioDevicesForAttributes(mediaAttrs) }.getOrNull()
            val first = routed?.firstOrNull()
            if (first != null) {
                outputs.firstOrNull { it.type == first.type && (first.address.isEmpty() || it.address == first.address) }
                    ?.let { return it }
                outputs.firstOrNull { it.type == first.type }?.let { return it }
            }
        }
        // Antes do Android 13: segue a mesma prioridade que o sistema usa.
        val priority = listOf(
            USB_TYPES,
            setOf(AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET),
            BT_TYPES,
            setOf(AudioDeviceInfo.TYPE_BUILTIN_SPEAKER),
        )
        for (group in priority) outputs.firstOrNull { it.type in group }?.let { return it }
        return null
    }

    private fun directSupported(rate: Int): Boolean {
        val encodings = intArrayOf(
            AudioFormat.ENCODING_PCM_FLOAT,
            AudioFormat.ENCODING_PCM_24BIT_PACKED,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        return encodings.any { enc ->
            runCatching {
                val format = AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setEncoding(enc)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
                @Suppress("DEPRECATION")
                AudioTrack.isDirectPlaybackSupported(format, mediaAttrs)
            }.getOrDefault(false)
        }
    }

    /**
     * A LG não documenta uma API pública para o estado do Quad DAC. Tentamos as chaves
     * conhecidas do sistema; se nenhuma responder, devolvemos "" e o app avisa o usuário.
     */
    private fun quadDacState(): String {
        // LineageOS (hardware/lge): o painel Quad DAC grava o estado nestas propriedades
        for (prop in listOf("persist.vendor.audio.hifi.enabled", "persist.vendor.lge.audio.hifi_dac")) {
            parseOnOff(getprop(prop))?.let { return it }
        }
        val resolver = context.contentResolver
        for (key in listOf("hifi_dac", "hifi_quad_dac", "quad_dac", "lge_hifi_dac", "hifi_dac_enable")) {
            val v = runCatching { Settings.System.getString(resolver, key) }.getOrNull()
                ?: runCatching { Settings.Global.getString(resolver, key) }.getOrNull()
            parseOnOff(v)?.let { return it }
        }
        for (key in listOf("hifi_dac", "lge_hifi_dac", "hifi_dac_status")) {
            val raw = runCatching { am.getParameters(key) }.getOrNull() ?: continue
            parseOnOff(raw.substringAfter('=', ""))?.let { return it }
        }
        return ""
    }

    /** Modo de impedância do ES9218 (LineageOS: persist.vendor.audio.ess.mode). */
    private fun quadDacMode(): String = when (getprop("persist.vendor.audio.ess.mode")) {
        "0" -> "Normal"
        "1" -> "Alta impedância"
        "2" -> "AUX / alta impedância"
        else -> ""
    }

    /** Lê uma propriedade do sistema; volta vazio se o Android não permitir a leitura. */
    private fun getprop(key: String): String = runCatching {
        val p = ProcessBuilder("getprop", key).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        out
    }.getOrDefault("")

    private fun parseOnOff(v: String?): String? = when (v?.trim()?.lowercase()) {
        "1", "on", "true", "enable", "enabled" -> "Ativado"
        "0", "off", "false", "disable", "disabled" -> "Desativado"
        else -> null
    }

    companion object {
        val USB_TYPES = setOf(
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY
        )
        val BT_TYPES = setOf(
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER
        )

        fun typeLabel(type: Int) = when (type) {
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Fone com fio (P2)"
            in USB_TYPES -> "DAC USB"
            in BT_TYPES -> "Bluetooth"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Alto-falante"
            AudioDeviceInfo.TYPE_HDMI -> "HDMI"
            else -> "Saída de áudio"
        }
    }
}

/** Aparelhos LG que saíram de fábrica com o Hi-Fi Quad DAC da ESS. */
object LgQuadDac {
    // Codinome do aparelho (Build.DEVICE) → chip
    private val byDevice = mapOf(
        "elsa" to "ES9218",        // V20
        "joan" to "ES9218P",       // V30 / V30+
        "judyp" to "ES9218P",      // V35
        "judyln" to "ES9218P",     // G7
        "judypn" to "ES9218P",     // V40
        "flashlmdd" to "ES9218PV", // V50
        "alphalm" to "ES9218PV",   // G8
        "betalm" to "ES9218PV",    // G8s
        "mh2lm" to "ES9218PV",     // G8X / V50S
        "timelm" to "ES9218PV",    // V60
    )

    // Prefixo do modelo (Build.MODEL) → chip, para variantes de operadora
    private val byModel = listOf(
        "LM-V600" to "ES9218PV", "LM-V510" to "ES9218PV", "LM-V500" to "ES9218PV", "LM-V450" to "ES9218PV",
        "LM-G850" to "ES9218PV", "LM-G820" to "ES9218PV", "LM-G810" to "ES9218PV",
        "LM-V409" to "ES9218P", "LM-V405" to "ES9218P", "LM-V350" to "ES9218P", "LM-V300" to "ES9218P",
        "LM-G710" to "ES9218P",
        "H930" to "ES9218P", "H931" to "ES9218P", "H932" to "ES9218P", "H933" to "ES9218P",
        "US998" to "ES9218P", "LS998" to "ES9218P", "VS996" to "ES9218P",
        "H990" to "ES9218", "H910" to "ES9218", "H915" to "ES9218", "H918" to "ES9218",
        "US996" to "ES9218", "LS997" to "ES9218", "VS995" to "ES9218",
    )

    /** Chip do Quad DAC deste aparelho, ou null se não for um LG com Quad DAC. */
    fun chip(): String? {
        if (!Build.MANUFACTURER.equals("LGE", ignoreCase = true) &&
            !Build.MANUFACTURER.equals("LG", ignoreCase = true)
        ) return null
        byDevice[Build.DEVICE.lowercase()]?.let { return it }
        val model = Build.MODEL.uppercase()
        return byModel.firstOrNull { (prefix, _) -> model.contains(prefix) }?.second
    }
}
