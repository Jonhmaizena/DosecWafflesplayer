package com.hires.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Size
import androidx.annotation.OptIn
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSourceBitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.ListeningExecutorService

/**
 * Carrega a capa para a notificação, a tela de bloqueio, o relógio e o Android Auto.
 *
 * Ordem: capa embutida que o player já leu → capa embutida lida direto do arquivo →
 * miniatura do Android → disco da Maizeninha. Assim a notificação mostra a mesma capa
 * que aparece dentro do app.
 */
@OptIn(UnstableApi::class)
class ArtworkLoader(
    private val context: Context,
    private val executor: ListeningExecutorService,
) : BitmapLoader {

    private val base = DataSourceBitmapLoader(context)

    override fun supportsMimeType(mimeType: String): Boolean = base.supportsMimeType(mimeType)

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = base.decodeBitmap(data)

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        val id = uri.takeIf { it.authority == CoverProvider.AUTHORITY }?.lastPathSegment?.toLongOrNull()
            ?: return base.loadBitmap(uri)
        return executor.submit<Bitmap> {
            CoverStore.bitmap(context, id, 512) ?: BitmapFactory.decodeResource(context.resources, R.drawable.default_cover)
        }
    }

    override fun loadBitmapFromMetadata(metadata: MediaMetadata): ListenableFuture<Bitmap>? {
        metadata.artworkData?.let { return decodeBitmap(it) }
        // Capa servida pelo app (content://…capas/capa/<id>): lida direto do cache
        metadata.artworkUri?.takeIf { it.authority == CoverProvider.AUTHORITY }?.lastPathSegment?.toLongOrNull()?.let { id ->
            return executor.submit<Bitmap> {
                CoverStore.bitmap(context, id, 512) ?: BitmapFactory.decodeResource(context.resources, R.drawable.default_cover)
            }
        }
        val trackUri = metadata.extras?.getString(Track.EXTRA_TRACK_URI)?.let(Uri::parse)
        if (trackUri != null) {
            return executor.submit<Bitmap> { coverFor(trackUri) }
        }
        return metadata.artworkUri?.let { loadBitmap(it) }
    }

    private fun coverFor(uri: Uri): Bitmap {
        // 1) Capa embutida no arquivo (FLAC, MP3, M4A…)
        runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, uri)
                r.embeddedPicture?.let { bytes ->
                    decodeScaled(bytes)?.let { return it }
                }
            } finally {
                runCatching { r.release() }
            }
        }
        // 2) Miniatura que o Android gera para a música
        runCatching { return context.contentResolver.loadThumbnail(uri, Size(512, 512), null) }
        // 3) Disco da Maizeninha
        return BitmapFactory.decodeResource(context.resources, R.drawable.default_cover)
    }

    /** Reduz capas muito grandes: a notificação não precisa de mais que ~512 px. */
    private fun decodeScaled(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
