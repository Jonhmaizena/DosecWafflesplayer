package com.hires.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import kotlin.math.ln
import kotlin.math.roundToInt

/** Um fone da base do AutoEQ. */
data class HeadphoneEntry(val name: String, val path: String, val source: String, val rig: String) {
    /** in-ear, over-ear ou earbud, pela pasta da medição. */
    val kind: String
        get() = when {
            "in-ear" in path -> "in-ear"
            "earbud" in path -> "earbud"
            else -> "over-ear"
        }
}

/** Correção salva no aparelho: 15 ganhos + pré-amplificação. */
data class SavedHeadphone(val name: String, val source: String, val gains: FloatArray, val preamp: Float) {
    val presetName: String get() = "🎧 $name"
}

/**
 * Correções de fone do projeto AutoEQ (github.com/jaakkopasanen/AutoEq, licença MIT):
 * medições de laboratório de milhares de fones e a curva que deixa cada um neutro.
 *
 * A lista de fones é baixada uma vez e guardada (a busca funciona offline depois).
 * A correção escolhida é convertida para as 15 bandas do equalizador e salva no aparelho.
 */
object HeadphoneEq {
    private const val BASE = "https://raw.githubusercontent.com/jaakkopasanen/AutoEq/master/results/"
    private const val UA = "TomMusicPlayer/7.2"
    private const val INDEX_MAX_AGE = 30L * 24 * 3600 * 1000

    private fun dir(context: Context) = File(context.filesDir, "autoeq").apply { mkdirs() }
    private fun indexFile(context: Context) = File(dir(context), "INDEX.md")

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private var cached: List<HeadphoneEntry>? = null

    /** Lista de fones (da internet na primeira vez; depois, do aparelho). */
    @Synchronized
    fun index(context: Context): List<HeadphoneEntry> {
        cached?.let { return it }
        val f = indexFile(context)
        val old = !f.exists() || System.currentTimeMillis() - f.lastModified() > INDEX_MAX_AGE
        if (old) {
            runCatching {
                val text = get(BASE + "INDEX.md")
                if (text.contains("](./")) {
                    val tmp = File(f.path + ".tmp")
                    tmp.writeText(text)
                    tmp.renameTo(f)
                }
            }
        }
        if (!f.exists()) throw java.io.IOException("offline")
        val list = parse(f.readText())
        cached = list
        return list
    }

    private val LINE = Regex("""^- \[(.+?)]\(\./(.+)\) by (.+?)(?: on (.+))?$""")

    private fun parse(text: String): List<HeadphoneEntry> = text.lineSequence().mapNotNull { line ->
        val m = LINE.find(line.trim()) ?: return@mapNotNull null
        HeadphoneEntry(m.groupValues[1], m.groupValues[2], m.groupValues[3], m.groupValues[4])
    }.toList()

    /** Fontes mais confiáveis primeiro (medições de referência). */
    private fun rank(e: HeadphoneEntry) = when (e.source) {
        "oratory1990" -> 0
        "crinacle" -> 1
        "Rtings" -> 2
        "Innerfidelity" -> 3
        "HypetheSonics" -> 4
        else -> 5
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()

    fun search(context: Context, query: String, limit: Int = 60): List<HeadphoneEntry> {
        val words = norm(query).split(' ').filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val all = index(context)
        // Busca sem separadores também acha "wh1000xm4" para "WH-1000XM4"
        val joined = words.joinToString("")
        return all.asSequence()
            .filter { e ->
                val n = norm(e.name)
                words.all { it in n } || joined in n.replace(" ", "")
            }
            // Uma medição por fone: fica a da fonte mais confiável
            .groupBy { norm(it.name) }
            .values
            .map { list -> list.minWith(compareBy<HeadphoneEntry>({ rank(it) }, { it.path.length })) }
            .sortedWith(compareBy<HeadphoneEntry>({ norm(it.name) != norm(query) }, { it.name.length }, { it.name }))
            .take(limit)
    }

    /** Baixa a curva do fone e converte para as 15 bandas do equalizador. */
    fun download(context: Context, e: HeadphoneEntry): SavedHeadphone {
        val folder = e.path.trimEnd('/')
        val fileName = folder.substringAfterLast('/')
        val text = get("$BASE$folder/$fileName%20GraphicEQ.txt")
        val curve = parseGraphicEq(text)
        if (curve.size < 10) throw java.io.IOException("Curva inválida")
        val (gains, preamp) = toBands(curve)
        val name = runCatching { URLDecoder.decode(fileName, "UTF-8") }.getOrDefault(e.name)
        val saved = SavedHeadphone(name, e.source + if (e.rig.isNotBlank()) " · ${e.rig}" else "", gains, preamp)
        save(context, saved)
        return saved
    }

    /** "GraphicEQ: 20 -0.2; 21 -0.2; …" → pares (frequência, ganho). */
    fun parseGraphicEq(text: String): List<Pair<Float, Float>> =
        text.substringAfter("GraphicEQ:").split(';').mapNotNull { p ->
            val parts = p.trim().split(Regex("\\s+"))
            if (parts.size < 2) null
            else {
                val f = parts[0].toFloatOrNull()
                val g = parts[1].toFloatOrNull()
                if (f == null || g == null || f <= 0f) null else f to g
            }
        }.sortedBy { it.first }

    /**
     * Cada banda do equalizador cobre uma faixa de frequências (até o seu corte).
     * O ganho da banda é a média da curva do AutoEQ nessa faixa, em escala logarítmica.
     * Depois a curva é nivelada para que os médios (500 Hz–2 kHz) fiquem em 0 dB e a
     * pré-amplificação reserva espaço para os reforços, evitando distorção.
     */
    fun toBands(curve: List<Pair<Float, Float>>): Pair<FloatArray, Float> {
        val gains = FloatArray(EqBands.COUNT)
        for (b in 0 until EqBands.COUNT) {
            val lo = if (b == 0) 20f else EqBands.cutoffs[b - 1]
            val hi = EqBands.cutoffs[b]
            var sum = 0.0
            var weight = 0.0
            for (i in 0 until curve.size - 1) {
                val (f0, g0) = curve[i]
                val (f1, g1) = curve[i + 1]
                val a = maxOf(f0, lo)
                val z = minOf(f1, hi)
                if (z <= a) continue
                val w = ln(z.toDouble() / a)
                sum += (g0 + g1) / 2.0 * w
                weight += w
            }
            gains[b] = if (weight > 0) (sum / weight).toFloat() else interp(curve, EqBands.centers[b])
        }
        // Nivela pelos médios
        val mids = (0 until EqBands.COUNT).filter { EqBands.centers[it] in 500f..2000f }
        val ref = mids.map { gains[it] }.average().toFloat()
        for (i in gains.indices) {
            gains[i] = ((gains[i] - ref) * 2).roundToInt() / 2f
            gains[i] = gains[i].coerceIn(-EqBands.MAX_DB, EqBands.MAX_DB)
        }
        val maxBoost = gains.maxOrNull()?.coerceAtLeast(0f) ?: 0f
        val preamp = (-(maxBoost * 2).roundToInt() / 2f).coerceIn(EqBands.PREAMP_MIN, 0f)
        return gains to preamp
    }

    private fun interp(curve: List<Pair<Float, Float>>, f: Float): Float {
        if (f <= curve.first().first) return curve.first().second
        if (f >= curve.last().first) return curve.last().second
        for (i in 0 until curve.size - 1) {
            val (f0, g0) = curve[i]
            val (f1, g1) = curve[i + 1]
            if (f in f0..f1) {
                val t = (ln(f.toDouble() / f0) / ln(f1.toDouble() / f0)).toFloat()
                return g0 + (g1 - g0) * t
            }
        }
        return 0f
    }

    // ---- Fones salvos -----------------------------------------------------------------------

    private fun prefs(context: Context) = context.getSharedPreferences("fones", Context.MODE_PRIVATE)

    fun saved(context: Context): List<SavedHeadphone> {
        val arr = runCatching { JSONArray(prefs(context).getString("lista", "[]")) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                val g = o.getJSONArray("g")
                SavedHeadphone(
                    o.getString("n"), o.optString("s"),
                    FloatArray(EqBands.COUNT) { g.optDouble(it, 0.0).toFloat() },
                    o.optDouble("p", 0.0).toFloat(),
                )
            }.getOrNull()
        }
    }

    private fun write(context: Context, list: List<SavedHeadphone>) {
        val arr = JSONArray()
        list.forEach { h ->
            arr.put(JSONObject().put("n", h.name).put("s", h.source).put("p", h.preamp.toDouble())
                .put("g", JSONArray().apply { h.gains.forEach { put(it.toDouble()) } }))
        }
        prefs(context).edit().putString("lista", arr.toString()).apply()
    }

    fun save(context: Context, h: SavedHeadphone) {
        write(context, listOf(h) + saved(context).filter { it.name != h.name })
    }

    fun remove(context: Context, name: String) {
        write(context, saved(context).filter { it.name != name })
    }
}
