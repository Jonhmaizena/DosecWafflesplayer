package com.hires.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.Normalizer
import kotlin.math.roundToInt

/** Letra usada no indicador da barra de rolagem: sem acento, maiúscula; números viram "#". */
fun indexLetter(text: String): String {
    val c = text.firstOrNull { it.isLetterOrDigit() } ?: return "•"
    if (c.isDigit()) return "#"
    val plain = Normalizer.normalize(c.toString(), Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")
    return plain.uppercase().ifEmpty { "•" }
}

/** Barra de rolagem rápida para listas ([LazyListState]). */
@Composable
fun FastScroller(
    state: LazyListState,
    itemCount: Int,
    headerItems: Int = 0,
    label: (Int) -> String,
    modifier: Modifier = Modifier,
) {
    val info = state.layoutInfo
    FastScrollerImpl(
        itemCount = itemCount,
        firstVisible = { (state.firstVisibleItemIndex - headerItems).coerceAtLeast(0) },
        visibleCount = { info.visibleItemsInfo.size },
        scrolling = state.isScrollInProgress,
        scrollTo = { state.scrollToItem(it + headerItems) },
        label = label,
        modifier = modifier,
    )
}

/** Barra de rolagem rápida para grades ([LazyGridState]). */
@Composable
fun FastScroller(
    state: LazyGridState,
    itemCount: Int,
    label: (Int) -> String,
    modifier: Modifier = Modifier,
) {
    val info = state.layoutInfo
    FastScrollerImpl(
        itemCount = itemCount,
        firstVisible = { state.firstVisibleItemIndex },
        visibleCount = { info.visibleItemsInfo.size },
        scrolling = state.isScrollInProgress,
        scrollTo = { state.scrollToItem(it) },
        label = label,
        modifier = modifier,
    )
}

/**
 * Trilho à direita da lista. Aparece ao rolar; arrastando o marcador, a lista pula direto
 * para a posição, e um balão mostra a letra inicial do item naquele ponto.
 */
@Composable
private fun FastScrollerImpl(
    itemCount: Int,
    firstVisible: () -> Int,
    visibleCount: () -> Int,
    scrolling: Boolean,
    scrollTo: suspend (Int) -> Unit,
    label: (Int) -> String,
    modifier: Modifier,
) {
    if (itemCount < 20 || rememberIsTv()) return
    val scope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var visible by remember { mutableStateOf(false) }

    // Mostra enquanto rola ou arrasta; some 1,5 s depois
    LaunchedEffect(scrolling, dragging) {
        if (scrolling || dragging) visible = true
        else { delay(1500); visible = false }
    }

    val maxStart = (itemCount - visibleCount()).coerceAtLeast(1)
    val fraction = if (dragging) dragFraction else (firstVisible().toFloat() / maxStart).coerceIn(0f, 1f)
    val index = ((if (dragging) dragFraction else fraction) * (itemCount - 1)).roundToInt().coerceIn(0, itemCount - 1)

    BoxWithConstraints(modifier.fillMaxHeight().width(48.dp)) {
        val density = LocalDensity.current
        val thumbH = 52.dp
        val trackPx = with(density) { (maxHeight - thumbH).toPx() }.coerceAtLeast(1f)
        val thumbY = (fraction * trackPx).roundToInt()

        fun jump(y: Float) {
            val f = ((y - with(density) { thumbH.toPx() } / 2) / trackPx).coerceIn(0f, 1f)
            dragFraction = f
            val target = (f * (itemCount - 1)).roundToInt().coerceIn(0, itemCount - 1)
            scope.launch { scrollTo(target) }
        }

        AnimatedVisibility(visible = visible || dragging, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .width(48.dp)
                    .pointerInput(itemCount) {
                        detectTapGestures(onPress = { o ->
                            dragging = true
                            jump(o.y)
                            tryAwaitRelease()
                            dragging = false
                        })
                    }
                    .pointerInput(itemCount) {
                        detectVerticalDragGestures(
                            onDragStart = { o -> dragging = true; jump(o.y) },
                            onDragEnd = { dragging = false },
                            onDragCancel = { dragging = false },
                            onVerticalDrag = { change, _ -> change.consume(); jump(change.position.y) },
                        )
                    }
            ) {
                // marcador
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset { IntOffset(0, thumbY) }
                        .padding(end = 4.dp)
                        .size(width = 8.dp, height = thumbH)
                        .background(if (dragging) Gold else Gold.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                )
            }
        }

        // Balão com a letra, ao lado do marcador
        if (dragging) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset { IntOffset(with(density) { (-56).dp.roundToPx() }, (thumbY - with(density) { 6.dp.roundToPx() }).coerceAtLeast(0)) }
                    .size(64.dp)
                    .background(Gold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    indexLetter(label(index)),
                    color = if (AppTheme.dark) Color(0xFF1A1305) else Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.headlineMedium,
                )
            }
        }
    }
}
