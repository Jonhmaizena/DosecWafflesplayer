package com.hires.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.hires.player.R
import kotlinx.coroutines.delay

/**
 * Logo do Dosec Waffles Music na abertura: 1,6 s parado + 0,4 s de dissolução = 2 s no total.
 * Aparece só ao abrir o app, não ao girar a tela.
 */
@Composable
fun SplashOverlay() {
    var visible by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        if (visible) {
            delay(1600)
            visible = false
        }
    }
    AnimatedVisibility(visible = visible, exit = fadeOut(tween(400))) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painterResource(R.drawable.splash_logo),
                contentDescription = "Dosec Waffles Music",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp)
            )
        }
    }
}
