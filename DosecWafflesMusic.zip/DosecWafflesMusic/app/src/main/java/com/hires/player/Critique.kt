package com.hires.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Parte de uma crítica: resumo, bastidores/curiosidades ou recepção da crítica. */
data class CritSection(val group: String, val heading: String, val text: String) {
    companion object {
        const val SUMMARY = "summary"
        const val CONTEXT = "context"
        const val RECEPTION = "reception"
    }
}

/** Nota dada por uma publicação (ex.: AllMusic 5/5). */
data class CritScore(val source: String, val value: String)

data class CritLink(val label: String, val url: String)

/** Crítica completa de um álbum ou de uma música, já no idioma do app. */
data class CritiqueDoc(
    val title: String,
    val sections: List<CritSection>,
    val scores: List<CritScore>,
    val links: List<CritLink>,
    /** Idioma do texto original (Wikipedia). */
    val sourceLang: String,
    /** Foi traduzido automaticamente para o idioma do app. */
    val translated: Boolean,
    /** Não deu para traduzir neste aparelho: o texto está no idioma original. */
    val translationFailed: Boolean,
    val wikiUrl: String,
)

/**
 * "Crítica": junta o que foi escrito sobre o álbum e a música que estão tocando —
 * bastidores, curiosidades, recepção da crítica e notas das publicações —
 * a partir da Wikipedia e do Wikidata, traduz para o idioma do app e guarda no aparelho.
 */
object Critica {
    private const val RETRY_MS = 7L * 24 * 3600 * 1000
    private const val MAX_CHARS = 24_000
    private val LANGS = listOf("pt", "en", "es")

    private fun dir(context: Context) = File(context.filesDir, "critica").apply { mkdirs() }

    fun cacheSize(context: Context): Long = dir(context).listFiles()?.sumOf { it.length() } ?: 0L

    fun clearCache(context: Context) { dir(context).listFiles()?.forEach { it.delete() } }

    // ---- API --------------------------------------------------------------------------------

    fun album(context: Context, track: Track, online: Boolean, stage: (String) -> Unit = {}): Lookup<CritiqueDoc> {
        if (OnlineInfo.isUnknown(track.album)) return Lookup.NotFound
        val file = "album_${OnlineInfo.hash(track.artist, track.album)}_${L.lang}.json"
        return cachedOr(context, file, online) {
            stage(tr("Procurando o álbum…"))
            // Usa o código do Wikidata achado pelo MusicBrainz; se não houver, procura direto no Wikidata
            OnlineInfo.album(context, track.artist, track.album, online = true)
            val qid = OnlineInfo.albumWikidata(context, track.artist, track.album)
                ?: searchWikidata(cleanTitle(track.album), track.artist, listOf("album", "ep", "soundtrack", "compilation", "live"))
            qid?.let { build(it, track, isAlbum = true, stage = stage) }
        }
    }

    fun song(context: Context, track: Track, online: Boolean, stage: (String) -> Unit = {}): Lookup<CritiqueDoc> {
        if (OnlineInfo.isUnknown(track.artist) || track.title.isBlank()) return Lookup.NotFound
        val file = "musica_${OnlineInfo.hash(track.artist, track.title)}_${L.lang}.json"
        return cachedOr(context, file, online) {
            stage(tr("Procurando a música…"))
            val qid = searchWikidata(cleanTitle(track.title), track.artist, listOf("song", "single", "cancao", "cancion", "musica", "composition"))
            qid?.let { build(it, track, isAlbum = false, stage = stage) }
        }
    }

    private fun cachedOr(context: Context, file: String, online: Boolean, fetch: () -> CritiqueDoc?): Lookup<CritiqueDoc> {
        val f = File(dir(context), file)
        val cached = runCatching { JSONObject(f.readText()) }.getOrNull()
        if (cached != null) {
            val notFound = cached.optBoolean("notFound")
            val old = notFound && System.currentTimeMillis() - cached.optLong("t") > RETRY_MS
            // Se a tradução falhou antes, tenta de novo quando houver internet
            val retryTranslation = !notFound && cached.optBoolean("trFail") && online
            if (!online || (!old && !retryTranslation)) {
                return if (notFound) Lookup.NotFound else Lookup.Found(fromJson(cached), true)
            }
        }
        if (!online) return Lookup.Offline
        return try {
            val doc = fetch()
            val j = doc?.let { toJson(it) } ?: JSONObject().put("notFound", true)
            j.put("t", System.currentTimeMillis())
            runCatching {
                val tmp = File(f.path + ".tmp")
                tmp.writeText(j.toString())
                tmp.renameTo(f)
            }
            if (doc == null) Lookup.NotFound else Lookup.Found(doc, false)
        } catch (e: Exception) {
            cached?.takeIf { !it.optBoolean("notFound") }?.let { Lookup.Found(fromJson(it), true) } ?: Lookup.Offline
        }
    }

    // ---- Montagem ---------------------------------------------------------------------------

    private fun build(qid: String, track: Track, isAlbum: Boolean, stage: (String) -> Unit): CritiqueDoc? {
        val entity = getJson(
            "https://www.wikidata.org/w/api.php?action=wbgetentities&ids=$qid&props=sitelinks%7Cclaims" +
                "&sitefilter=enwiki%7Cptwiki%7Ceswiki&format=json"
        )?.optJSONObject("entities")?.optJSONObject(qid) ?: return null
        val sitelinks = entity.optJSONObject("sitelinks")
        val claims = entity.optJSONObject("claims")
        val titles: Map<String, String> = LANGS.mapNotNull { lang ->
            val t: String? = sitelinks?.optJSONObject("${lang}wiki")?.optString("title")?.takeIf { it.isNotBlank() }
            if (t == null) null else Pair(lang, t)
        }.toMap()

        val scores = if (claims != null) scores(claims) else emptyList()
        val links = links(claims, track, isAlbum)

        // Texto: no idioma do app se for bom o bastante; senão o inglês (mais completo), traduzido
        stage(tr("Lendo a Wikipedia…"))
        val target = L.lang
        val native: Triple<String, String, List<CritSection>>? = titles[target]?.let { t -> article(target, t)?.let { Triple(target, t, it) } }
        var chosen: Triple<String, String, List<CritSection>>? = native
        if (target != "en" && titles["en"] != null) {
            val nativeLen = native?.third?.sumOf { it.text.length } ?: 0
            val nativeHasReception = native?.third?.any { it.group == CritSection.RECEPTION } == true
            if (nativeLen < 2500 || !nativeHasReception) {
                val en = article("en", titles["en"]!!)
                val enLen = en?.sumOf { it.text.length } ?: 0
                if (en != null && enLen > nativeLen * 2) chosen = Triple("en", titles["en"]!!, en)
            }
        }
        if (chosen == null) {
            // Nem no idioma do app nem em inglês: usa o que houver
            for ((lang, t) in titles) {
                val a = article(lang, t) ?: continue
                chosen = Triple(lang, t, a)
                break
            }
        }
        if (chosen == null && scores.isEmpty()) return null

        val srcLang = chosen?.first ?: target
        var sections = chosen?.third.orEmpty()
        var translated = false
        var failed = false
        if (sections.isNotEmpty() && srcLang != target) {
            stage(tr("Traduzindo…"))
            try {
                // Traduz títulos e parágrafos (os títulos de subseção começam com "§ ")
                val pieces = ArrayList<String>()
                sections.forEach { s ->
                    pieces += s.heading
                    s.text.split('\n').forEach { p -> pieces += p.removePrefix("§ ") }
                }
                val out = Tradutor.translate(pieces, srcLang, target) { done, total ->
                    stage(trf("Traduzindo… %1\$s%%", done * 100 / total))
                }
                var i = 0
                sections = sections.map { s ->
                    val heading = out[i++]
                    val text = s.text.split('\n').joinToString("\n") { p ->
                        val t = out[i++]
                        if (p.startsWith("§ ")) "§ $t" else t
                    }
                    s.copy(heading = heading, text = text)
                }
                translated = true
            } catch (e: Exception) {
                failed = true
            }
        }
        val wikiUrl = chosen?.let { (lang, t, _) ->
            "https://$lang.wikipedia.org/wiki/" + OnlineInfo.urlEncode(t.replace(' ', '_')).replace("%2F", "/")
        }.orEmpty()
        return CritiqueDoc(
            title = if (isAlbum) track.album else track.title,
            sections = sections,
            scores = scores,
            links = links,
            sourceLang = srcLang,
            translated = translated,
            translationFailed = failed,
            wikiUrl = wikiUrl,
        )
    }

    // ---- Wikidata ---------------------------------------------------------------------------

    private fun getJson(url: String): JSONObject? = OnlineInfo.http(url)?.let { JSONObject(it) }

    /** "Song Title (Remastered 2009)" → "Song Title". */
    private fun cleanTitle(s: String) = s
        .replace(Regex("""\s*[(\[][^)\]]*(remaster|deluxe|edition|edição|edición|version|versão|versión|mono|stereo|live|ao vivo|en vivo|bonus|anniversary|expanded|mix)[^)\]]*[)\]]""", RegexOption.IGNORE_CASE), "")
        .replace(Regex("""\s+-\s+.*(remaster|version|mix|live|mono|stereo).*$""", RegexOption.IGNORE_CASE), "")
        .trim()
        .ifBlank { s }

    /**
     * Procura no Wikidata pelo título e confere pela descrição
     * (ex.: "1959 studio album by Miles Davis", "song by The Beatles").
     */
    private fun searchWikidata(title: String, artist: String, kinds: List<String>): String? {
        if (title.isBlank()) return null
        val res = getJson(
            "https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${OnlineInfo.urlEncode(title)}" +
                "&language=en&uselang=en&type=item&limit=20&format=json"
        )?.optJSONArray("search") ?: return null
        val a = OnlineInfo.normalize(artist)
        val t = OnlineInfo.normalize(title)
        var best: String? = null
        for (i in 0 until res.length()) {
            val r = res.getJSONObject(i)
            val desc = r.optString("description")
            val d = OnlineInfo.normalize(desc)
            val words = java.text.Normalizer.normalize(desc.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")
            if (a.isNotBlank() && a !in d) continue
            if (kinds.none { it in words }) continue
            val label = OnlineInfo.normalize(r.optString("label"))
            if (label == t) return r.optString("id")
            if (best == null) best = r.optString("id")
        }
        return best
    }

    /** Notas das publicações (propriedade P444, com a publicação em P447). */
    private fun scores(claims: JSONObject): List<CritScore> {
        val arr = claims.optJSONArray("P444") ?: return emptyList()
        val raw = ArrayList<Pair<String, String>>() // (id da publicação, nota)
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val value = c.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optString("value").orEmpty()
            val by = c.optJSONObject("qualifiers")?.optJSONArray("P447")?.optJSONObject(0)
                ?.optJSONObject("datavalue")?.optJSONObject("value")?.optString("id").orEmpty()
            if (value.isNotBlank() && by.isNotBlank() && raw.none { it.first == by }) raw += by to value
        }
        if (raw.isEmpty()) return emptyList()
        val ids = raw.take(12).joinToString("%7C") { it.first }
        val labels = runCatching {
            getJson("https://www.wikidata.org/w/api.php?action=wbgetentities&ids=$ids&props=labels&languages=${L.lang}%7Cen&format=json")
                ?.optJSONObject("entities")
        }.getOrNull()
        return raw.take(12).mapNotNull { (id, value) ->
            val l = labels?.optJSONObject(id)?.optJSONObject("labels")
            val name = l?.optJSONObject(L.lang)?.optString("value")?.takeIf { it.isNotBlank() }
                ?: l?.optJSONObject("en")?.optString("value")?.takeIf { it.isNotBlank() }
                ?: return@mapNotNull null
            CritScore(name, value)
        }
    }

    private fun claimString(claims: JSONObject?, prop: String): String? =
        claims?.optJSONArray(prop)?.optJSONObject(0)?.optJSONObject("mainsnak")
            ?.optJSONObject("datavalue")?.optString("value")?.takeIf { it.isNotBlank() && !it.startsWith("{") }

    /** Links para ler as resenhas completas nos sites das publicações. */
    private fun links(claims: JSONObject?, track: Track, isAlbum: Boolean): List<CritLink> {
        val q = OnlineInfo.urlEncode(listOf(track.artist, if (isAlbum) track.album else track.title).joinToString(" "))
        val out = ArrayList<CritLink>()
        if (isAlbum) {
            out += claimString(claims, "P1243")?.let { CritLink("AllMusic", "https://www.allmusic.com/album/$it") }
                ?: CritLink("AllMusic", "https://www.allmusic.com/search/albums/$q")
            out += CritLink("Pitchfork", "https://pitchfork.com/search/?query=$q")
            claimString(claims, "P1712")?.let { out += CritLink("Metacritic", "https://www.metacritic.com/$it") }
            claimString(claims, "P1954")?.let { out += CritLink("Discogs", "https://www.discogs.com/master/$it") }
            out += CritLink("Rate Your Music", "https://rateyourmusic.com/search?searchterm=$q&searchtype=l")
        } else {
            out += CritLink("AllMusic", "https://www.allmusic.com/search/songs/$q")
            out += CritLink("Genius", "https://genius.com/search?q=$q")
            out += CritLink("Songfacts", "https://www.songfacts.com/search/songs/$q")
        }
        return out
    }

    // ---- Wikipedia --------------------------------------------------------------------------

    /** Artigo inteiro em texto, dividido em seções úteis (sem listas de faixas, créditos, paradas…). */
    private fun article(lang: String, title: String): List<CritSection>? {
        val j = runCatching {
            getJson(
                "https://$lang.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exsectionformat=wiki" +
                    "&redirects=1&format=json&formatversion=2&titles=${OnlineInfo.urlEncode(title)}"
            )
        }.getOrNull() ?: return null
        val text = j.optJSONObject("query")?.optJSONArray("pages")?.optJSONObject(0)?.optString("extract").orEmpty()
        if (text.isBlank()) return null
        return parse(text).takeIf { it.isNotEmpty() }
    }

    private val HEADING = Regex("""^(={2,6})\s*(.+?)\s*\1\s*$""")

    /** Seções que não são crítica nem curiosidade. */
    private val SKIP = listOf(
        "track", "faixa", "lista de canc", "canciones", "tracklist", "personnel", "ficha tecnica", "credit",
        "musicos", "personal", "integrantes", "chart", "parada", "tabela", "posicion", "posicoes", "certific",
        "reference", "referenc", "notas", "notes", "external", "ligacoes", "enlaces", "bibliograf",
        "release history", "historico de lanc", "historial de lanz", "see also", "ver tambem", "vease",
        "fontes", "fuentes", "sources", "further reading", "leitura adicional", "lectura adicional",
        "formatos", "formats", "edition", "edicoes", "ediciones", "sales", "vendas", "ventas",
    )

    private val RECEPTION = listOf(
        "recep", "critic", "review", "resenh", "avaliac", "acolh", "legacy", "legado",
        "accolade", "premi", "reconhec", "impact", "influen", "ranking", "elogio",
    )

    private fun plain(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}"), "")

    internal fun parse(text: String): List<CritSection> {
        val out = ArrayList<CritSection>()
        var heading: String? = null // null = introdução
        var skip = false
        val buf = StringBuilder()
        var total = 0

        fun flush() {
            val body = buf.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
                // Remove subtítulos que ficaram sem texto
                .let { ls -> ls.filterIndexed { i, l -> !l.startsWith("§ ") || (i + 1 < ls.size && !ls[i + 1].startsWith("§ ")) } }
                .joinToString("\n")
                .take(8000)
            buf.setLength(0)
            if (skip || body.length < 40 || total >= MAX_CHARS) return
            val group = when {
                heading == null -> CritSection.SUMMARY
                RECEPTION.any { it in plain(heading!!) } -> CritSection.RECEPTION
                else -> CritSection.CONTEXT
            }
            val clipped = body.take(MAX_CHARS - total)
            total += clipped.length
            out += CritSection(group, heading.orEmpty(), clipped)
        }

        for (line in text.lines()) {
            val m = HEADING.matchEntire(line.trim())
            if (m != null) {
                val level = m.groupValues[1].length
                val h = m.groupValues[2].trim()
                if (level == 2) {
                    flush()
                    heading = h
                    skip = SKIP.any { it in plain(h) }
                } else if (!skip) {
                    // Subseção: vira um subtítulo dentro da seção (se ela própria não for descartável)
                    if (SKIP.none { it in plain(h) }) buf.append("§ ").append(h).append('\n')
                }
                continue
            }
            if (!skip) buf.append(line).append('\n')
        }
        flush()
        return out
    }

    // ---- Cache (JSON) -----------------------------------------------------------------------

    private fun toJson(d: CritiqueDoc) = JSONObject()
        .put("title", d.title)
        .put("src", d.sourceLang)
        .put("tr", d.translated)
        .put("trFail", d.translationFailed)
        .put("wiki", d.wikiUrl)
        .put("sections", JSONArray().apply {
            d.sections.forEach { put(JSONObject().put("g", it.group).put("h", it.heading).put("x", it.text)) }
        })
        .put("scores", JSONArray().apply { d.scores.forEach { put(JSONObject().put("s", it.source).put("v", it.value)) } })
        .put("links", JSONArray().apply { d.links.forEach { put(JSONObject().put("l", it.label).put("u", it.url)) } })

    private fun fromJson(j: JSONObject): CritiqueDoc {
        fun arr(name: String) = j.optJSONArray(name)?.let { a -> (0 until a.length()).map { a.getJSONObject(it) } }.orEmpty()
        return CritiqueDoc(
            title = j.optString("title"),
            sections = arr("sections").map { CritSection(it.optString("g"), it.optString("h"), it.optString("x")) },
            scores = arr("scores").map { CritScore(it.optString("s"), it.optString("v")) },
            links = arr("links").map { CritLink(it.optString("l"), it.optString("u")) },
            sourceLang = j.optString("src"),
            translated = j.optBoolean("tr"),
            translationFailed = j.optBoolean("trFail"),
            wikiUrl = j.optString("wiki"),
        )
    }
}
