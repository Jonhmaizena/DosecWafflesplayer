package com.hires.player

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.CommandButton
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.MoreExecutors
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

/**
 * Serviço de reprodução.
 *
 * Decodificação: FFmpeg em software (bit-exato para FLAC, ALAC, WAV, AIFF), com o
 * decodificador do Android como reserva. Saída em PCM float de 32 bits, o que preserva
 * arquivos de 24 bits e desliga todos os processadores de áudio do player: sem
 * equalizador, sem normalização, sem pular silêncio e sem mudança de velocidade.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {

    private var session: MediaLibrarySession? = null
    private lateinit var autoLibrary: AutoLibrary
    // Leitura da biblioteca para o Android Auto fora da thread principal
    private val libraryExecutor = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())
    private lateinit var player: ExoPlayer
    private lateinit var bitPerfect: BitPerfectController
    private lateinit var inspector: OutputInspector
    private lateinit var eq: EqController
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    // Arquivo
    private var codec = ""
    private var srcRate = 0
    private var srcBits = 0
    private var channels = 0
    private var bitrateKbps = 0
    /** Música a que o formato acima pertence (evita mostrar no carro dados da faixa anterior). */
    private var formatMediaId: String? = null
    // Cadeia de reprodução
    private var decoderName = ""
    private var outEncoding = C.ENCODING_INVALID
    private var outRate = 0
    private var bpStatus = ""
    private lateinit var resamplingSink: ResamplingAudioSink
    private var resamplerOn = false
    private var widthOn = false      // Palco (largura estéreo)
    private var widthAmount = 1.4f
    private var userBp = false   // o usuário ligou a conexão direta
    private var autoBp = true    // ligar sozinho ao conectar um DAC USB

    override fun onCreate() {
        super.onCreate()
        L.init(this)

        // Saída com o reamostrador de alta qualidade (ligado ou desligado pelo usuário)
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                val base = DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
                return ResamplingAudioSink(base).also { sink ->
                    sink.onStatusChanged = { main.post { publishExtras() } }
                    resamplingSink = sink
                }
            }
        }
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
            .setEnableAudioFloatOutput(true)

        player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setSkipSilenceEnabled(false)
            .build()
        player.volume = 1f // volume digital do app sempre em 100%: nenhuma redução de bits

        // Sessão de áudio fixa para o equalizador se prender a ela
        val audioSession = getSystemService(AudioManager::class.java).generateAudioSessionId()
        player.setAudioSessionId(audioSession)
        eq = EqController(this)

        bitPerfect = BitPerfectController(this)
        // Bit-perfect só existe com o equalizador totalmente desligado
        widthOn = prefs.getBoolean(KEY_W_ON, false)
        widthAmount = prefs.getFloat(KEY_W_AMT, 1.4f)
        userBp = prefs.getBoolean(KEY_BP, false)
        autoBp = prefs.getBoolean(KEY_BP_AUTO, true)
        refreshDirectMode()
        eq.attach(audioSession)
        bpStatus = if (bitPerfect.enabled) tr("Aguardando a faixa") else tr("Desligado")
        inspector = OutputInspector(this)

        // Reamostrador e bit-perfect não convivem: o bit-perfect exige a taxa original
        resamplerOn = prefs.getBoolean(KEY_RS, false)
        configureResampler()

        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) = onNewTrackFormat(tracks)

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                refreshWidget()
                updateFavoriteButton()
                saveQueue()
                outputRetries = 0
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) skippedInARow = 0
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                refreshWidget()
                saveQueue()
                main.removeCallbacks(periodicSave)
                if (isPlaying) main.postDelayed(periodicSave, 10_000)
            }

            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) = refreshWidget()

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = saveQueue()
            override fun onRepeatModeChanged(repeatMode: Int) = saveQueue()

            // Um erro numa faixa não pode parar a fila inteira
            override fun onPlayerError(error: PlaybackException) = recoverFrom(error)
        })
        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioDecoderInitialized(
                eventTime: AnalyticsListener.EventTime,
                decoderName: String,
                initializedTimestampMs: Long,
                initializationDurationMs: Long
            ) {
                this@PlaybackService.decoderName = decoderName
                publishExtras()
            }

            override fun onAudioTrackInitialized(
                eventTime: AnalyticsListener.EventTime,
                audioTrackConfig: AudioSink.AudioTrackConfig
            ) {
                outEncoding = audioTrackConfig.encoding
                outRate = audioTrackConfig.sampleRate
                publishExtras()
            }
        })

        getSystemService(AudioManager::class.java).registerAudioDeviceCallback(deviceCallback, main)

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        autoLibrary = AutoLibrary(this)
        session = MediaLibrarySession.Builder(this, player, SessionCallback())
            .setSessionActivity(openApp)
            // Capa da música na notificação, tela de bloqueio e Android Auto
            .setBitmapLoader(ArtworkLoader(this, libraryExecutor))
            .build()
        // Coração de favoritar no Android Auto e na notificação
        FavoriteSync.listen(favoriteListener)
        updateFavoriteButton()
        publishExtras()
        restoreQueue()
        instance = this
        refreshWidget()
    }

    // ---- Widget ---------------------------------------------------------------------------

    private var widgetCoverId: Long? = null
    private var widgetCover: android.graphics.Bitmap? = null

    /** Atualiza o widget com a música atual, a capa e o estado tocar/pausar. */
    fun refreshWidget() {
        main.post {
            if (instance !== this) return@post
            val item = player.currentMediaItem
            val md = player.mediaMetadata
            val title = (md.title ?: item?.mediaMetadata?.title)?.toString()
                ?: getString(R.string.app_name)
            val artist = (md.artist ?: item?.mediaMetadata?.artist)?.toString()
                ?: getString(R.string.widget_idle)
            val id = item?.mediaId?.toLongOrNull()
            val playing = player.isPlaying || (player.playWhenReady && player.playbackState == Player.STATE_BUFFERING)
            if (id != null && id == widgetCoverId && widgetCover != null) {
                PlayerWidget.update(this, title, artist, id, playing, widgetCover)
                return@post
            }
            PlayerWidget.update(this, title, artist, id, playing, null)
            if (id == null) return@post
            runCatching { io.execute {
                val cover = runCatching { CoverStore.bitmap(this, id, 256) }.getOrNull()
                main.post {
                    if (instance !== this) return@post
                    if (player.currentMediaItem?.mediaId?.toLongOrNull() != id) return@post
                    widgetCoverId = id
                    widgetCover = cover
                    PlayerWidget.update(this, title, artist, id, player.isPlaying, cover)
                }
            } }
        }
    }

    /** Botões do widget (anterior, tocar/pausar, próxima). */
    fun widgetCommand(action: String) {
        main.post {
            if (player.mediaItemCount == 0) return@post
            when (action) {
                PlayerWidget.ACTION_PLAY_PAUSE -> {
                    if (player.isPlaying) player.pause()
                    else {
                        if (player.playbackState == Player.STATE_IDLE) player.prepare()
                        if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition()
                        player.play()
                    }
                }
                PlayerWidget.ACTION_NEXT -> player.seekToNext()
                PlayerWidget.ACTION_PREV -> player.seekToPrevious()
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveQueue()
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        FavoriteSync.stop(favoriteListener)
        saveQueue()
        runCatching {
            PlayerWidget.update(
                this,
                player.mediaMetadata.title?.toString() ?: getString(R.string.app_name),
                player.mediaMetadata.artist?.toString() ?: getString(R.string.widget_idle),
                player.currentMediaItem?.mediaId?.toLongOrNull(), false, widgetCover,
            )
        }
        main.removeCallbacks(periodicSave)
        getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(deviceCallback)
        bitPerfect.clear()
        eq.release()
        session?.run {
            player.release()
            release()
        }
        session = null
        io.shutdown()
        libraryExecutor.shutdown()
        super.onDestroy()
    }

    // ---- Última música tocada ---------------------------------------------------------------

    private val lastQueue by lazy { getSharedPreferences("ultima_fila", Context.MODE_PRIVATE) }

    private val periodicSave = object : Runnable {
        override fun run() {
            saveQueue()
            if (player.isPlaying) main.postDelayed(this, 10_000)
        }
    }

    /** Guarda a fila, a música atual e o ponto onde parou, para voltar ao abrir o app. */
    private fun saveQueue() {
        if (player.mediaItemCount == 0) return
        val ids = (0 until player.mediaItemCount).joinToString(",") { player.getMediaItemAt(it).mediaId }
        lastQueue.edit()
            .putString("ids", ids)
            .putString("atual", player.currentMediaItem?.mediaId.orEmpty())
            .putInt("indice", player.currentMediaItemIndex)
            .putLong("posicao", player.currentPosition.coerceAtLeast(0))
            .putBoolean("aleatorio", player.shuffleModeEnabled)
            .putInt("repetir", player.repeatMode)
            .apply()
    }

    /** Fila salva, para retomar a reprodução quando o player ainda está vazio. */
    private fun savedQueueItems(): MediaSession.MediaItemsWithStartPosition? {
        val ids = lastQueue.getString("ids", null)?.split(",")?.filter { it.isNotBlank() } ?: return null
        if (ids.isEmpty()) return null
        val currentId = lastQueue.getString("atual", "") ?: ""
        val savedIndex = lastQueue.getInt("indice", 0)
        val position = lastQueue.getLong("posicao", 0L)
        val items = ids.mapNotNull { id -> autoLibrary.resolve(MediaItem.Builder().setMediaId(id).build()) }
        if (items.isEmpty()) return null
        val index = items.indexOfFirst { it.mediaId == currentId }.takeIf { it >= 0 }
            ?: savedIndex.coerceIn(0, items.size - 1)
        val stillSameSong = items[index].mediaId == currentId
        return MediaSession.MediaItemsWithStartPosition(items, index, if (stillSameSong) position else 0L)
    }

    /** Volta a fila salva, pausada no ponto onde parou (sem tocar sozinha). */
    private fun restoreQueue() {
        val ids = lastQueue.getString("ids", null)?.split(",")?.filter { it.isNotBlank() } ?: return
        if (ids.isEmpty()) return
        val currentId = lastQueue.getString("atual", "") ?: ""
        val savedIndex = lastQueue.getInt("indice", 0)
        val position = lastQueue.getLong("posicao", 0L)
        val shuffle = lastQueue.getBoolean("aleatorio", false)
        val repeat = lastQueue.getInt("repetir", Player.REPEAT_MODE_OFF)
        libraryExecutor.execute {
            // Só volta o que ainda existe no aparelho
            val items = ids.mapNotNull { id -> autoLibrary.resolve(MediaItem.Builder().setMediaId(id).build()) }
            if (items.isEmpty()) return@execute
            val index = items.indexOfFirst { it.mediaId == currentId }.takeIf { it >= 0 }
                ?: savedIndex.coerceIn(0, items.size - 1)
            val stillSameSong = items[index].mediaId == currentId
            main.post {
                if (player.mediaItemCount > 0) return@post // o usuário já escolheu outra coisa
                player.setMediaItems(items, index, if (stillSameSong) position else 0L)
                player.shuffleModeEnabled = shuffle
                player.repeatMode = repeat
                player.playWhenReady = false
                player.prepare()
            }
        }
    }

    // ---- Recuperação de erros ---------------------------------------------------------------

    private var outputRetries = 0
    private var skippedInARow = 0

    /**
     * Se a saída de áudio falhar (troca de DAC, mudança de taxa), tenta de novo na mesma faixa.
     * Se a faixa em si não tocar (arquivo corrompido ou formato não suportado), pula para a próxima.
     */
    private fun recoverFrom(error: PlaybackException) {
        val audioOutput = error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
        if (audioOutput && outputRetries < 3) {
            outputRetries++
            main.postDelayed({ player.prepare(); player.play() }, 300)
            return
        }
        if (player.hasNextMediaItem() && skippedInARow < player.mediaItemCount) {
            skippedInARow++
            main.post {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    // ---- Formato do arquivo atual ------------------------------------------------------

    private fun onNewTrackFormat(tracks: Tracks) {
        val group = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 } ?: return
        val format = group.getTrackFormat(0)
        val mime = format.sampleMimeType
        val rate = format.sampleRate
        val ch = format.channelCount
        val pcmBits = when (format.pcmEncoding) {
            C.ENCODING_PCM_16BIT -> 16
            C.ENCODING_PCM_24BIT -> 24
            C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 32
            else -> 0
        }
        val uri = player.currentMediaItem?.localConfiguration?.uri

        // FLAC/ALAC não trazem a profundidade de bits no formato; lemos do arquivo.
        io.execute {
            val info = readFileInfo(uri)
            main.post {
                codec = codecName(mime)
                srcRate = if (rate > 0) rate else info.rate
                srcBits = if (isLossy(mime)) 0 else if (pcmBits > 0) pcmBits else info.bits
                channels = ch
                bitrateKbps = info.bitrateKbps
                formatMediaId = player.currentMediaItem?.mediaId
                applyBitPerfect(restartIfChanged = false)
            }
        }
    }

    private data class FileInfo(val bits: Int, val rate: Int, val bitrateKbps: Int)

    private fun readFileInfo(uri: Uri?): FileInfo {
        if (uri == null) return FileInfo(0, 0, 0)
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            fun key(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
            FileInfo(
                bits = if (Build.VERSION.SDK_INT >= 31) key(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE) else 0,
                rate = if (Build.VERSION.SDK_INT >= 31) key(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE) else 0,
                bitrateKbps = key(MediaMetadataRetriever.METADATA_KEY_BITRATE) / 1000,
            )
        } catch (e: Exception) {
            FileInfo(0, 0, 0)
        } finally {
            runCatching { r.release() }
        }
    }

    // ---- Bit-perfect e saída ---------------------------------------------------------------

    /**
     * Decide se a conexão direta fica ligada: pelo usuário, ou sozinha quando há um
     * DAC USB conectado e a opção automática está ativa. Nunca com o equalizador ligado.
     */
    private fun refreshDirectMode() {
        bitPerfect.enabled = !eq.state.enabled && !widthOn &&
            (userBp || (autoBp && bitPerfect.usbDacConnected()))
    }

    private fun applyBitPerfect(restartIfChanged: Boolean) {
        refreshDirectMode()
        configureResampler()
        val (status, changed) = bitPerfect.apply(srcRate)
        bpStatus = status
        publishExtras()
        // A nova configuração da saída só vale quando a trilha de áudio é reaberta.
        if (changed && restartIfChanged && player.mediaItemCount > 0) reopenOutput()
    }

    private fun reopenOutput() {
        val index = player.currentMediaItemIndex
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        player.stop()
        player.seekTo(index, pos)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    /** Liga ou desliga o reamostrador e aponta para a taxa atual do mixer do Android. */
    private fun configureResampler() {
        val mixer = getSystemService(AudioManager::class.java)
            .getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        resamplingSink.targetRate = mixer
        resamplingSink.enabled = resamplerOn && !bitPerfect.enabled
        resamplingSink.widthOn = widthOn && !bitPerfect.enabled
        resamplingSink.width = widthAmount
    }

    private fun publishExtras() {
        val s = session ?: return
        val out = runCatching { inspector.inspect(srcRate) }.getOrNull()
        val direct = bitPerfect.active

        val path = when {
            out == null -> ""
            direct -> tr("Direto ao DAC, sem mixer (bit-perfect)")
            bitPerfect.nativeRate ->
                trf("Mixer do Android na taxa da faixa (%1\$s), sem reamostragem → DAC USB", formatRate(srcRate))
            resamplingSink.isActive && !out.isBluetooth ->
                trf("Reamostrado pelo app (sinc, alta qualidade) → mixer do Android em %1\$s sem nova reamostragem", formatRate(out.mixerRate)) +
                    effectsSuffix()
            eq.state.enabled || resamplingSink.widthActive -> tr("Mixer do Android") +
                (if (out.mixerRate > 0) trf(" em %1\$s", formatRate(out.mixerRate)) else "") + effectsSuffix()
            out.isBluetooth -> tr("Mixer do Android → recomprimido pelo codec Bluetooth")
            out.mixerRate > 0 && srcRate > 0 && out.mixerRate == srcRate ->
                trf("Mixer do Android em %1\$s · sem reamostragem", formatRate(out.mixerRate))
            out.mixerRate > 0 && srcRate > 0 ->
                trf("Mixer do Android · reamostrado de %1\$s para %2\$s", formatRate(srcRate), formatRate(out.mixerRate))
            else -> tr("Mixer do Android")
        }

        val extras = Bundle().apply {
            putString(EX_CODEC, codec)
            putInt(EX_RATE, srcRate)
            putInt(EX_BITS, srcBits)
            putInt(EX_CHANNELS, channels)
            putInt(EX_BITRATE, bitrateKbps)
            putString(EX_DECODER, decoderLabel(decoderName))
            putString(EX_APP_OUT, appOutputLabel())
            putBoolean(EX_BP_ENABLED, bitPerfect.enabled)
            putBoolean(EX_BP_AUTO, autoBp)
            putBoolean(EX_BP_NATIVE, bitPerfect.nativeRate)
            putString(EX_BP_DIAG, bitPerfect.diagnostics)
            putString(EX_BP_STATUS, bpStatus)
            putBoolean(EX_DIRECT, direct)
            putString(EX_PATH, path)
            putString(
                EX_PROCESSING,
                listOfNotNull(
                    if (eq.state.enabled) trf("Equalizador 15 bandas · %1\$s · limitador", tr(eq.state.preset)) else null,
                    if (widthOn) trf("Palco %1\$s%% (graves no centro)", (widthAmount * 100).toInt()) else null,
                ).joinToString(" · ")
                    .ifEmpty { tr("Nenhum: sem EQ, efeitos, normalização ou ajuste de velocidade") }
            )
            putBoolean(EX_W_ON, widthOn)
            putFloat(EX_W_AMT, widthAmount)
            eq.state.toBundle(this)
            putBoolean(EX_RS_ON, resamplerOn)
            putBoolean(EX_RS_ACTIVE, resamplingSink.isActive)
            putString(
                EX_RS_STATUS,
                when {
                    !resamplerOn -> tr("Desligado")
                    bitPerfect.enabled -> tr("Pausado: conexão direta ao DAC USB em uso")
                    else -> resamplingSink.status.ifEmpty { tr("Aguardando a faixa") }
                }
            )
            if (out != null) {
                putString(EX_DEV_TYPE, out.deviceType)
                putString(EX_DAC, out.dacName)
                putInt(EX_DEV_MAX_RATE, out.maxRate)
                putInt(EX_DEV_MAX_BITS, out.maxBits)
                putBoolean(EX_LG_QUAD, out.lgQuadDac)
                putBoolean(EX_LG_PHONE, LgQuadDac.chip() != null)
                putString(EX_LG_STATE, out.quadDacState)
                putString(EX_ROM, out.customRom)
                putString(EX_LG_MODE, out.quadDacMode)
                putBoolean(EX_USB, out.isUsb)
                putBoolean(EX_DIRECT_AVAILABLE, out.directAvailable)
            }
        }
        s.setSessionExtras(extras)
        updateCarInfo(direct)
    }

    private fun effectsSuffix(): String = buildString {
        if (eq.state.enabled) append(tr(" · com equalizador"))
        if (resamplingSink.widthActive) append(tr(" · com Palco"))
    }

    private fun appOutputLabel(): String {
        if (outRate <= 0) return ""
        val enc = when (outEncoding) {
            C.ENCODING_PCM_FLOAT -> tr("32-bit float")
            C.ENCODING_PCM_32BIT -> "32-bit"
            C.ENCODING_PCM_24BIT -> "24-bit"
            C.ENCODING_PCM_16BIT -> "16-bit"
            else -> "PCM"
        }
        return "${enc} · ${formatRate(outRate)}"
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) =
            main.postDelayed({ applyBitPerfect(restartIfChanged = true) }, 300).let { }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) =
            main.postDelayed({ applyBitPerfect(restartIfChanged = false) }, 300).let { }
    }

    // ---- Sessão --------------------------------------------------------------------------

    // ---- Informações do arquivo no Android Auto ---------------------------------------------

    /**
     * Mostra no carro, abaixo do título, o mesmo resumo de qualidade do celular:
     * "Artista · HI-RES · FLAC · 24-bit · 96 kHz · Bit-perfect".
     * Troca só os dados exibidos da faixa atual; o áudio continua sem interrupção.
     */
    private fun updateCarInfo(direct: Boolean) {
        val item = player.currentMediaItem ?: return
        if (item.mediaId != formatMediaId || (codec.isEmpty() && srcRate <= 0)) return
        val hiRes = srcBits > 16 || srcRate > 48000
        val info = listOfNotNull(
            if (hiRes) "HI-RES" else null,
            codec.ifEmpty { null },
            if (srcBits > 0) "${srcBits}-bit" else null,
            formatRate(srcRate).ifEmpty { null },
            if (srcBits == 0 && bitrateKbps > 0) "$bitrateKbps kbps" else null,
            when {
                direct -> "Bit-perfect"
                eq.state.enabled -> "EQ"
                else -> null
            },
        ).joinToString(" · ")
        if (info.isEmpty()) return
        val artist = item.mediaMetadata.artist?.toString().orEmpty()
        val line = if (artist.isBlank()) info else "$artist · $info"
        if (item.mediaMetadata.subtitle?.toString() == line) return
        val index = player.currentMediaItemIndex
        val updated = item.buildUpon()
            .setMediaMetadata(item.mediaMetadata.buildUpon().setSubtitle(line).setDescription(info).build())
            .build()
        runCatching { player.replaceMediaItem(index, updated) }
    }

    // ---- Favoritar pelo Android Auto e pela notificação -------------------------------------

    private val favorites by lazy { LibraryStore(this) }

    // Favoritos mudados no app: atualiza o coração do carro
    private val favoriteListener: (String) -> Unit = { source -> if (source != "servico") updateFavoriteButton() }

    private fun currentTrackId(): Long? = player.currentMediaItem?.mediaId?.toLongOrNull()?.takeIf { it >= 0 }

    /** Mostra o coração cheio (favorita) ou vazio para a música que está tocando. */
    @androidx.annotation.OptIn(UnstableApi::class)
    private fun updateFavoriteButton() {
        val s = session ?: return
        val id = currentTrackId()
        if (id == null) {
            s.setCustomLayout(ImmutableList.of())
            return
        }
        val fav = id in favorites.load().favorites
        @Suppress("DEPRECATION")
        val button = CommandButton.Builder()
            .setDisplayName(if (fav) tr("Remover dos favoritos") else tr("Favoritar"))
            .setIconResId(if (fav) R.drawable.ic_fav_on else R.drawable.ic_fav_off)
            .setSessionCommand(SessionCommand(CMD_FAVORITE, Bundle.EMPTY))
            .build()
        s.setCustomLayout(ImmutableList.of(button))
    }

    private fun toggleCurrentFavorite() {
        val id = currentTrackId() ?: return
        val lib = favorites.load()
        val updated = if (id in lib.favorites) lib.copy(favorites = lib.favorites - id)
        else lib.copy(favorites = listOf(id) + lib.favorites)
        runCatching { favorites.save(updated) }
        updateFavoriteButton()
        FavoriteSync.changed("servico") // o app aberto recarrega os favoritos
    }

    private inner class SessionCallback : MediaLibrarySession.Callback {

        // Tocar pelo widget, fone Bluetooth ou sistema com o player vazio: retoma a última fila
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
            libraryExecutor.submit<MediaSession.MediaItemsWithStartPosition> {
                val saved = savedQueueItems() ?: throw UnsupportedOperationException("Nenhuma fila salva")
                val shuffle = lastQueue.getBoolean("aleatorio", false)
                val repeat = lastQueue.getInt("repetir", Player.REPEAT_MODE_OFF)
                main.post { player.shuffleModeEnabled = shuffle; player.repeatMode = repeat }
                saved
            }

        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SET_BITPERFECT, Bundle.EMPTY))
                .add(SessionCommand(CMD_REFRESH_OUTPUT, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_EQ, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_RESAMPLER, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_BP_AUTO, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_WIDTH, Bundle.EMPTY))
                .add(SessionCommand(CMD_LANGUAGE, Bundle.EMPTY))
                .add(SessionCommand(CMD_FAVORITE, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CMD_SET_BITPERFECT -> {
                    val on = args.getBoolean(ARG_ENABLED)
                    // Processamento no app que sai do caminho: a saída precisa ser reaberta
                    val dspOff = on && (widthOn || resamplerOn)
                    // Ligar o bit-perfect desliga o equalizador por completo
                    if (on && eq.state.enabled) eq.update(eq.state.copy(enabled = false))
                    if (on && widthOn) {
                        widthOn = false
                        prefs.edit().putBoolean(KEY_W_ON, false).apply()
                        configureResampler()
                    }
                    if (on && resamplerOn) {
                        resamplerOn = false
                        prefs.edit().putBoolean(KEY_RS, false).apply()
                        configureResampler()
                    }
                    userBp = on
                    // Desligar à mão também desliga o modo automático, senão ele voltaria sozinho
                    if (!on) autoBp = false
                    prefs.edit().putBoolean(KEY_BP, userBp).putBoolean(KEY_BP_AUTO, autoBp).apply()
                    applyBitPerfect(restartIfChanged = !dspOff)
                    if (dspOff && player.mediaItemCount > 0) reopenOutput()
                }
                CMD_SET_BP_AUTO -> {
                    autoBp = args.getBoolean(ARG_ENABLED)
                    prefs.edit().putBoolean(KEY_BP_AUTO, autoBp).apply()
                    applyBitPerfect(restartIfChanged = true)
                }
                CMD_REFRESH_OUTPUT -> { configureResampler(); publishExtras() }
                // Coração no Android Auto / notificação: marca ou desmarca a música atual
                CMD_FAVORITE -> toggleCurrentFavorite()
                // Idioma trocado: refaz os textos do painel no idioma novo
                CMD_LANGUAGE -> { applyBitPerfect(restartIfChanged = false); refreshWidget() }
                CMD_SET_RESAMPLER -> {
                    val on = args.getBoolean(ARG_ENABLED)
                    resamplerOn = on
                    prefs.edit().putBoolean(KEY_RS, on).apply()
                    if (on && bitPerfect.enabled) {
                        userBp = false
                        autoBp = false
                        prefs.edit().putBoolean(KEY_BP, false).putBoolean(KEY_BP_AUTO, false).apply()
                        applyBitPerfect(restartIfChanged = false)
                    }
                    configureResampler()
                    // A saída precisa ser reaberta para trocar a taxa entregue ao Android
                    if (player.mediaItemCount > 0) reopenOutput()
                    publishExtras()
                }
                CMD_SET_WIDTH -> {
                    val on = args.getBoolean(ARG_ENABLED)
                    widthAmount = args.getFloat(ARG_AMOUNT, widthAmount).coerceIn(0.5f, 2f)
                    val toggled = on != widthOn
                    widthOn = on
                    prefs.edit().putBoolean(KEY_W_ON, on).putFloat(KEY_W_AMT, widthAmount).apply()
                    // Palco ligado desliga a conexão direta (desligado, a automática pode voltar)
                    val wasDirect = bitPerfect.enabled
                    refreshDirectMode()
                    configureResampler()
                    if (wasDirect != bitPerfect.enabled) applyBitPerfect(restartIfChanged = false)
                    // Ligar/desligar muda o formato entregue ao Android: reabre a saída.
                    // Só mudar a intensidade vale na hora, sem interromper.
                    if ((toggled || wasDirect != bitPerfect.enabled) && player.mediaItemCount > 0) reopenOutput()
                    publishExtras()
                }
                CMD_SET_EQ -> {
                    val newState = EqState.fromBundle(args)
                    // Ligar o equalizador desliga o bit-perfect: os dois não convivem
                    val wasDirect = bitPerfect.enabled
                    eq.update(newState)
                    refreshDirectMode()
                    // Ligar o equalizador desliga a conexão direta (e desligá-lo pode religar a automática)
                    if (wasDirect != bitPerfect.enabled) applyBitPerfect(restartIfChanged = true)
                    else publishExtras()
                }
                else -> return super.onCustomCommand(session, controller, customCommand, args)
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        // Itens vindos do app ou do carro chegam sem o endereço do arquivo; reconstruímos aqui.
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> = libraryExecutor.submit<MutableList<MediaItem>> {
            mediaItems.mapNotNull { autoLibrary.resolve(it) }.toMutableList()
        }

        // Tocar a partir do carro: uma faixa vira a lista inteira; um pedido de voz vira uma busca.
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
            libraryExecutor.submit<MediaSession.MediaItemsWithStartPosition> {
                val (items, index) = autoLibrary.resolveForPlayback(mediaItems, startIndex)
                val safeIndex = if (items.isEmpty()) 0 else index.coerceIn(0, items.size - 1)
                MediaSession.MediaItemsWithStartPosition(
                    items,
                    safeIndex,
                    if (index == startIndex) startPositionMs else androidx.media3.common.C.TIME_UNSET
                )
            }

        // ---- Navegação (Android Auto) ----

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(autoLibrary.root(), params))

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
            libraryExecutor.submit<LibraryResult<ImmutableList<MediaItem>>> {
                val all = autoLibrary.children(parentId)
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(ImmutableList.copyOf(all.subList(from, to)), params)
            }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> = libraryExecutor.submit<LibraryResult<MediaItem>> {
            autoLibrary.item(mediaId)?.let { LibraryResult.ofItem(it, null) }
                ?: LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
        }

        override fun onSearch(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<Void>> {
            libraryExecutor.execute {
                val count = autoLibrary.search(query).size
                main.post { session.notifySearchResultChanged(browser, query, count, params) }
            }
            return Futures.immediateFuture(LibraryResult.ofVoid())
        }

        override fun onGetSearchResult(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
            libraryExecutor.submit<LibraryResult<ImmutableList<MediaItem>>> {
                val all = autoLibrary.searchItems(query)
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(ImmutableList.copyOf(all.subList(from, to)), params)
            }
    }

    companion object {
        /** Serviço em execução (para o widget mandar comandos direto ao player). */
        @Volatile var instance: PlaybackService? = null
            private set

        const val CMD_SET_BITPERFECT = "hires.SET_BITPERFECT"
        const val CMD_REFRESH_OUTPUT = "hires.REFRESH_OUTPUT"
        const val CMD_SET_EQ = "hires.SET_EQ"
        const val CMD_SET_RESAMPLER = "hires.SET_RESAMPLER"
        const val CMD_SET_WIDTH = "hires.SET_WIDTH"
        const val CMD_LANGUAGE = "hires.LANGUAGE"
        const val CMD_FAVORITE = "dosec.FAVORITE"
        const val ARG_AMOUNT = "amount"
        const val EX_W_ON = "w_on"
        const val EX_W_AMT = "w_amt"
        private const val KEY_W_ON = "palco"
        private const val KEY_W_AMT = "palco_amt"
        const val EX_RS_ON = "rs_on"
        const val EX_RS_STATUS = "rs_status"
        const val EX_RS_ACTIVE = "rs_active"
        private const val KEY_RS = "resampler"
        const val EX_PROCESSING = "processing"
        const val ARG_ENABLED = "enabled"

        const val EX_CODEC = "codec"
        const val EX_RATE = "rate"
        const val EX_BITS = "bits"
        const val EX_CHANNELS = "channels"
        const val EX_BITRATE = "bitrate"
        const val EX_DECODER = "decoder"
        const val EX_APP_OUT = "app_out"
        const val EX_BP_ENABLED = "bp_enabled"
        const val EX_BP_STATUS = "bp_status"
        const val EX_DIRECT = "direct"
        const val EX_DIRECT_AVAILABLE = "direct_available"
        const val EX_PATH = "path"
        const val EX_DEV_TYPE = "dev_type"
        const val EX_DAC = "dac"
        const val EX_DEV_MAX_RATE = "dev_max_rate"
        const val EX_DEV_MAX_BITS = "dev_max_bits"
        const val EX_LG_QUAD = "lg_quad"
        const val EX_LG_PHONE = "lg_phone"
        const val EX_LG_STATE = "lg_state"
        const val EX_ROM = "rom"
        const val EX_LG_MODE = "lg_mode"
        const val EX_USB = "usb"
        private const val KEY_BP = "bitperfect"
        private const val KEY_BP_AUTO = "bitperfect_auto"
        const val CMD_SET_BP_AUTO = "hires.SET_BP_AUTO"
        const val EX_BP_AUTO = "bp_auto"
        const val EX_BP_NATIVE = "bp_native"
        const val EX_BP_DIAG = "bp_diag"

        fun codecName(mime: String?): String = when (mime) {
            MimeTypes.AUDIO_FLAC -> "FLAC"
            MimeTypes.AUDIO_ALAC -> "ALAC"
            MimeTypes.AUDIO_RAW -> "PCM"
            MimeTypes.AUDIO_WAV -> "WAV"
            MimeTypes.AUDIO_MPEG -> "MP3"
            MimeTypes.AUDIO_AAC -> "AAC"
            MimeTypes.AUDIO_OPUS -> tr("Opus")
            MimeTypes.AUDIO_VORBIS -> tr("Vorbis")
            null -> ""
            else -> mime.substringAfter('/').uppercase()
        }

        fun isLossy(mime: String?) = mime in setOf(
            MimeTypes.AUDIO_MPEG, MimeTypes.AUDIO_AAC, MimeTypes.AUDIO_OPUS, MimeTypes.AUDIO_VORBIS
        )

        fun decoderLabel(name: String): String = when {
            name.isEmpty() -> ""
            name.contains("ffmpeg", ignoreCase = true) -> tr("FFmpeg (software, bit-exato)")
            else -> trf("Android MediaCodec (%1\$s)", name)
        }
    }
}
