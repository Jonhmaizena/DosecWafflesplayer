package com.hires.player

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/**
 * Árvore de navegação para o Android Auto (e qualquer outro controle de mídia):
 *
 *   raiz
 *   ├── Músicas      → faixas
 *   ├── Favoritas    → faixas
 *   ├── Playlists    → playlist → faixas
 *   ├── Álbuns       → álbum → faixas
 *   └── Artistas     → artista → faixas
 *
 * O ID de uma faixa leva junto a lista de onde ela veio ("t/<lista>/<id>"), para que
 * tocar uma música no carro coloque a lista inteira na fila, começando por ela.
 */
class AutoLibrary(private val context: Context) {

    private val store = LibraryStore(context)
    private var tracks: List<Track> = emptyList()
    private var byId: Map<Long, Track> = emptyMap()
    private var loadedAt = 0L

    private val defaultArt: Uri =
        Uri.parse("android.resource://${context.packageName}/${R.drawable.default_cover}")

    /** Recarrega a biblioteca do aparelho, no máximo a cada 60 s. */
    @Synchronized
    private fun ensureLoaded() {
        if (!hasPermission()) { tracks = emptyList(); byId = emptyMap(); return }
        if (tracks.isNotEmpty() && SystemClock.elapsedRealtime() - loadedAt < 60_000) return
        tracks = runCatching { MusicRepository.load(context) }.getOrDefault(emptyList())
        byId = tracks.associateBy { it.id }
        loadedAt = SystemClock.elapsedRealtime()
    }

    private fun hasPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_AUDIO
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    }

    fun root(): MediaItem = folder(ROOT, tr("Tom Music Player"), MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)

    /** Filhos de um nó da árvore. */
    fun children(parentId: String): List<MediaItem> {
        ensureLoaded()
        return when {
            parentId == ROOT -> listOf(
                folder(SONGS, tr("Músicas"), MediaMetadata.MEDIA_TYPE_FOLDER_MIXED, subtitle = trf("%1\$s faixas", tracks.size)),
                folder(FAVORITES, tr("Favoritas"), MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS),
                folder(PLAYLISTS, tr("Playlists"), MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS),
                folder(ALBUMS, tr("Álbuns"), MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS, grid = true),
                folder(ARTISTS, tr("Artistas"), MediaMetadata.MEDIA_TYPE_FOLDER_ARTISTS),
            )
            parentId == PLAYLISTS -> store.load().playlists.map {
                folder("${PLAYLIST_PREFIX}${it.id}", it.name, MediaMetadata.MEDIA_TYPE_PLAYLIST,
                    subtitle = trf("%1\$s faixas", it.trackIds.size))
            }
            parentId == ALBUMS -> MusicRepository.albums(tracks).map { g ->
                folder("${ALBUM_PREFIX}${g.tracks.first().albumId}", g.title, MediaMetadata.MEDIA_TYPE_ALBUM,
                    subtitle = g.subtitle, art = CoverProvider.uriFor(g.tracks.first().id))
            }
            parentId == ARTISTS -> MusicRepository.artists(tracks).map { g ->
                folder("${ARTIST_PREFIX}${Uri.encode(g.title)}", g.title, MediaMetadata.MEDIA_TYPE_ARTIST,
                    subtitle = g.subtitle)
            }
            else -> tracksOf(parentId).map { playable(it, parentId) }
        }
    }

    /** Faixas de uma lista (Músicas, Favoritas, playlist, álbum ou artista). */
    fun tracksOf(parentId: String): List<Track> {
        ensureLoaded()
        return when {
            parentId == SONGS -> tracks
            parentId == FAVORITES -> store.load().favorites.mapNotNull { byId[it] }
            parentId.startsWith(PLAYLIST_PREFIX) -> {
                val id = parentId.removePrefix(PLAYLIST_PREFIX)
                store.load().playlists.firstOrNull { it.id == id }?.trackIds?.mapNotNull { byId[it] } ?: emptyList()
            }
            parentId.startsWith(ALBUM_PREFIX) -> {
                val albumId = parentId.removePrefix(ALBUM_PREFIX).toLongOrNull()
                MusicRepository.albums(tracks.filter { it.albumId == albumId }).firstOrNull()?.tracks ?: emptyList()
            }
            parentId.startsWith(ARTIST_PREFIX) -> {
                val name = Uri.decode(parentId.removePrefix(ARTIST_PREFIX))
                MusicRepository.artists(tracks.filter { it.artist == name }).firstOrNull()?.tracks ?: emptyList()
            }
            else -> emptyList()
        }
    }

    fun item(mediaId: String): MediaItem? {
        ensureLoaded()
        parsePlayable(mediaId)?.let { (parent, id) -> byId[id]?.let { return playable(it, parent) } }
        if (mediaId == ROOT) return root()
        return children(ROOT).firstOrNull { it.mediaId == mediaId }
    }

    fun search(query: String): List<Track> {
        ensureLoaded()
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return tracks.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
    }

    fun searchItems(query: String): List<MediaItem> = search(query).map { playable(it, SONGS) }

    /**
     * Transforma o que o carro pediu para tocar em uma fila de verdade.
     * Retorna a fila (com URIs) e a posição inicial.
     */
    fun resolveForPlayback(requested: List<MediaItem>, startIndex: Int): Pair<List<MediaItem>, Int> {
        ensureLoaded()
        // Pedido por voz: "tocar X no Maizeninha"
        if (requested.size == 1) {
            val one = requested[0]
            val query = one.requestMetadata.searchQuery
            if (!query.isNullOrBlank() && one.mediaId.isEmpty()) {
                val found = search(query.toString()).ifEmpty { tracks.shuffled() }
                return found.map { it.toMediaItem(defaultArt) } to 0
            }
            // Uma faixa escolhida numa lista: toca a lista inteira a partir dela
            parsePlayable(one.mediaId)?.let { (parent, id) ->
                val list = tracksOf(parent).ifEmpty { listOfNotNull(byId[id]) }
                val index = list.indexOfFirst { it.id == id }.coerceAtLeast(0)
                return list.map { it.toMediaItem(defaultArt) } to index
            }
            // Uma pasta escolhida (ex.: "tocar a playlist")
            val folderTracks = tracksOf(one.mediaId)
            if (folderTracks.isNotEmpty()) return folderTracks.map { it.toMediaItem(defaultArt) } to 0
        }
        return requested.mapNotNull { resolve(it) } to startIndex.coerceAtLeast(0)
    }

    /** Garante que um item tenha o endereço do arquivo, venha de onde vier. */
    fun resolve(item: MediaItem): MediaItem? {
        if (item.localConfiguration != null) return item
        item.requestMetadata.mediaUri?.let { return item.buildUpon().setUri(it).build() }
        ensureLoaded()
        val id = parsePlayable(item.mediaId)?.second ?: item.mediaId.toLongOrNull() ?: return null
        return byId[id]?.toMediaItem(defaultArt)
    }

    private fun folder(
        id: String,
        title: String,
        type: Int,
        subtitle: String? = null,
        grid: Boolean = false,
        art: Uri? = null,
    ): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setIsBrowsable(true)
                .setIsPlayable(id != ROOT && id != PLAYLISTS && id != ALBUMS && id != ARTISTS)
                .setMediaType(type)
                .setArtworkUri(art ?: defaultArt)
                .setExtras(Bundle().apply {
                    // Estilo de exibição no Android Auto: lista (1) ou grade (2)
                    putInt(CONTENT_STYLE_BROWSABLE, if (grid) 2 else 1)
                    putInt(CONTENT_STYLE_PLAYABLE, 1)
                })
                .build()
        )
        .build()

    private fun playable(track: Track, parentId: String): MediaItem = MediaItem.Builder()
        .setMediaId("${TRACK_PREFIX}${Uri.encode(parentId)}/${track.id}")
        .setUri(track.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .setSubtitle("${track.artist} · ${track.formatLabel}")
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkUri(CoverProvider.uriFor(track.id))
                .build()
        )
        .build()

    private fun parsePlayable(mediaId: String): Pair<String, Long>? {
        if (!mediaId.startsWith(TRACK_PREFIX)) return null
        val rest = mediaId.removePrefix(TRACK_PREFIX)
        val slash = rest.lastIndexOf('/')
        if (slash < 0) return null
        val id = rest.substring(slash + 1).toLongOrNull() ?: return null
        return Uri.decode(rest.substring(0, slash)) to id
    }

    companion object {
        const val ROOT = "root"
        const val SONGS = "songs"
        const val FAVORITES = "favorites"
        const val PLAYLISTS = "playlists"
        const val ALBUMS = "albums"
        const val ARTISTS = "artists"
        const val PLAYLIST_PREFIX = "playlist:"
        const val ALBUM_PREFIX = "album:"
        const val ARTIST_PREFIX = "artist:"
        const val TRACK_PREFIX = "t/"

        private const val CONTENT_STYLE_BROWSABLE = "android.media.browse.CONTENT_STYLE_BROWSABLE_HINT"
        private const val CONTENT_STYLE_PLAYABLE = "android.media.browse.CONTENT_STYLE_PLAYABLE_HINT"
    }
}
