package com.hires.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat

/**
 * Widget do player na tela inicial: capa, música, artista e os botões
 * anterior, tocar/pausar e próxima. Tocar na capa abre o app.
 */
class PlayerWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        // Mostra a última música salva; a capa é lida fora da thread principal
        val service = PlaybackService.instance
        if (service != null) { service.refreshWidget(); return }
        val s = saved(context)
        push(context, s.title, s.artist, playing = false, cover = null)
        val id = s.trackId ?: return
        val pending = goAsync()
        Thread {
            try {
                val cover = runCatching { CoverStore.bitmap(context, id, 256) }.getOrNull()
                push(context, s.title, s.artist, playing = false, cover = cover)
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.hires.player.widget.PLAY_PAUSE"
        const val ACTION_NEXT = "com.hires.player.widget.NEXT"
        const val ACTION_PREV = "com.hires.player.widget.PREV"

        private data class Saved(val title: String, val artist: String, val trackId: Long?)

        private fun prefs(context: Context) = context.getSharedPreferences("widget", Context.MODE_PRIVATE)

        private fun saved(context: Context): Saved {
            val p = prefs(context)
            return Saved(
                p.getString("titulo", null) ?: context.getString(R.string.app_name),
                p.getString("artista", null) ?: context.getString(R.string.widget_idle),
                p.getLong("id", -1L).takeIf { it >= 0 },
            )
        }

        /** Chamado pelo serviço quando a música, a capa ou o play/pausa mudam. */
        fun update(context: Context, title: String, artist: String, trackId: Long?, playing: Boolean, cover: Bitmap?) {
            prefs(context).edit()
                .putString("titulo", title)
                .putString("artista", artist)
                .putLong("id", trackId ?: -1L)
                .apply()
            push(context, title, artist, playing, cover)
        }

        private fun push(context: Context, title: String, artist: String, playing: Boolean, cover: Bitmap?) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, PlayerWidget::class.java)
            val ids = runCatching { manager.getAppWidgetIds(component) }.getOrNull() ?: return
            if (ids.isEmpty()) return

            val v = RemoteViews(context.packageName, R.layout.widget_player)
            v.setTextViewText(R.id.w_title, title)
            v.setTextViewText(R.id.w_artist, artist)
            if (cover != null) v.setImageViewBitmap(R.id.w_cover, rounded(cover))
            else v.setImageViewResource(R.id.w_cover, R.drawable.default_cover)
            v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)

            val open = PendingIntent.getActivity(
                context, 10,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_cover, open)
            v.setOnClickPendingIntent(R.id.w_text, open)
            v.setOnClickPendingIntent(R.id.w_play, action(context, ACTION_PLAY_PAUSE, 11))
            v.setOnClickPendingIntent(R.id.w_next, action(context, ACTION_NEXT, 12))
            v.setOnClickPendingIntent(R.id.w_prev, action(context, ACTION_PREV, 13))
            runCatching { manager.updateAppWidget(component, v) }
        }

        private fun action(context: Context, action: String, code: Int): PendingIntent =
            PendingIntent.getBroadcast(
                context, code,
                Intent(context, WidgetActionReceiver::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        /** Cantos arredondados na capa (o widget não arredonda imagens sozinho). */
        private fun rounded(src: Bitmap): Bitmap {
            val size = minOf(src.width, src.height)
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply {
                    val m = android.graphics.Matrix()
                    m.setTranslate(-(src.width - size) / 2f, -(src.height - size) / 2f)
                    setLocalMatrix(m)
                }
            }
            val r = size * 0.12f
            c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, paint)
            return out
        }
    }
}

/** Recebe os toques nos botões do widget. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val service = PlaybackService.instance
        if (service != null) {
            service.widgetCommand(action)
            return
        }
        // Player fechado: tocar abre o serviço e retoma a última fila salva
        if (action == PlayerWidget.ACTION_PLAY_PAUSE) {
            val start = Intent(context, PlaybackService::class.java)
                .setAction(Intent.ACTION_MEDIA_BUTTON)
                .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            runCatching { ContextCompat.startForegroundService(context, start) }
                .onFailure {
                    // Sem permissão para iniciar em segundo plano: abre o app
                    runCatching {
                        context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
        } else {
            runCatching {
                context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
