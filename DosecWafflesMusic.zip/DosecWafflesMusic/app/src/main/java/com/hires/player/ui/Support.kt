package com.hires.player.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Icon
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hires.player.R
import com.hires.player.tr

/** Canal do DOSEC no YouTube. */
const val DOSEC_CHANNEL = "https://www.youtube.com/@avaliasom"

/** Dedicatória e link do canal do DOSEC (fim do player e janela de apoio). */
@Composable
fun DosecFooter() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            tr("Da Comunidade do Dosec para você"),
            textAlign = TextAlign.Center,
            color = Gold,
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Italic,
            style = MaterialTheme.typography.titleSmall,
        )
        OutlinedButton(
            onClick = {
                runCatching {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DOSEC_CHANNEL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            },
            modifier = Modifier.tvFocus(),
        ) {
            Icon(Icons.Filled.SmartDisplay, null, tint = Color(0xFFFF0033))
            Spacer(Modifier.width(8.dp))
            Text(tr("Canal do DOSEC no YouTube"))
        }
        Text("youtube.com/@avaliasom", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Dados do PIX e do Bitcoin de apoio ao projeto. */
object Pix {
    const val KEY = "jonatanamancio@yahoo.com.br"
    const val NAME = "Jonatan Amancio Ribeiro"
    const val AMOUNT = "R$ 5,00"

    /** Código "PIX copia e cola" (BR Code estático, R$ 5,00). O mesmo do QR code. */
    const val BR_CODE =
        "00020101021126780014br.gov.bcb.pix0127jonatanamancio@yahoo.com.br0225Apoio Dosec Waffles Music" +
            "52040000530398654045.005802BR5923JONATAN AMANCIO RIBEIRO6014BELO HORIZONTE62070503***6304F841"

    const val BITCOIN = "bc1q3xk9wulxvgwnngv2gakza2k4j69wpenk6xl8mj"
}

/** "Apoiar o projeto do DOSEC": PIX de R$ 5,00 ou Bitcoin, com QR code e botões de copiar. */
@Composable
fun SupportDialog(onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf<String?>(null) }
    var bitcoin by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Apoiar o projeto do DOSEC"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    tr("Gostou do Dosec Waffles Music? Ajude a manter o app vivo e sem anúncios com um PIX de R$ 5,00."),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium,
                )
                // Meta de arrecadação
                Text(
                    tr("Ao chegar a R$ 1.000,00 em apoios, o app ganha novas funcionalidades!"),
                    textAlign = TextAlign.Center,
                    color = Gold,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Gold.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !bitcoin, onClick = { bitcoin = false; copied = null },
                        label = { Text("PIX") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = MaterialTheme.colorScheme.onPrimary),
                        modifier = Modifier.tvFocus(RoundedCornerShape(8.dp))
                    )
                    FilterChip(
                        selected = bitcoin, onClick = { bitcoin = true; copied = null },
                        label = { Text("Bitcoin") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = MaterialTheme.colorScheme.onPrimary),
                        modifier = Modifier.tvFocus(RoundedCornerShape(8.dp))
                    )
                }
                Image(
                    painterResource(if (bitcoin) R.drawable.btc_qr else R.drawable.pix_qr),
                    if (bitcoin) tr("QR code do Bitcoin") else tr("QR code do PIX"),
                    modifier = Modifier
                        .size(220.dp)
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(6.dp)
                )
                if (!bitcoin) {
                    Text(Pix.AMOUNT, style = MaterialTheme.typography.headlineSmall, color = Gold, fontWeight = FontWeight.ExtraBold)
                    Text(tr("Abra o app do seu banco, escolha PIX › Ler QR code, ou use o código copia e cola."),
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(
                        onClick = { clipboard.setText(AnnotatedString(Pix.BR_CODE)); copied = tr("Código PIX copiado") },
                        modifier = Modifier.fillMaxWidth().tvFocus()
                    ) { Text(tr("Copiar código PIX (copia e cola)")) }
                    OutlinedButton(
                        onClick = { clipboard.setText(AnnotatedString(Pix.KEY)); copied = tr("Chave PIX copiada") },
                        modifier = Modifier.fillMaxWidth().tvFocus()
                    ) { Text(tr("Copiar chave PIX")) }
                    Text(
                        tr("Chave PIX (e-mail)") + ":\n" + Pix.KEY + "\n" + Pix.NAME,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else {
                    Text(tr("Envie qualquer valor em Bitcoin (rede Bitcoin, não Lightning) para o endereço abaixo."),
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(Pix.BITCOIN, textAlign = TextAlign.Center, style = TechStyle)
                    Button(
                        onClick = { clipboard.setText(AnnotatedString(Pix.BITCOIN)); copied = tr("Endereço Bitcoin copiado") },
                        modifier = Modifier.fillMaxWidth().tvFocus()
                    ) { Text(tr("Copiar endereço Bitcoin")) }
                }
                copied?.let { Text(it, color = Gold, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(2.dp))
                Text(tr("Obrigado pelo apoio!"), style = MaterialTheme.typography.titleSmall)
                DosecFooter()
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fechar")) } },
    )
}
