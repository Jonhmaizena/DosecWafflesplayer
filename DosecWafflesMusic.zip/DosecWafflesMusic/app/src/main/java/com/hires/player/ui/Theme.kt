package com.hires.player.ui

import android.content.Context
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hires.player.R
import com.hires.player.Track
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Gold = Color(0xFFE8B04A)
val GoldDim = Color(0xFF8A6A2E)

private val Scheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF1A1305),
    secondary = Color(0xFFB9BCC4),
    background = Color(0xFF0F1012),
    onBackground = Color(0xFFECECEE),
    surface = Color(0xFF0F1012),
    onSurface = Color(0xFFECECEE),
    surfaceVariant = Color(0xFF1E1F23),
    onSurfaceVariant = Color(0xFF9EA1AA),
    surfaceContainer = Color(0xFF17181B),
    surfaceContainerHigh = Color(0xFF1E1F23),
    outline = Color(0xFF34363C),
)

private val AppType = Typography().run {
    copy(
        titleLarge = titleLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
        headlineSmall = headlineSmall.copy(fontWeight = FontWeight.Bold),
    )
}

/** Fonte monoespaçada para dados técnicos (taxa, bits, codec). */
val TechStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 0.3.sp)

@Composable
fun HiResTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppType, content = content)
}

private object ArtCache {
    private val cache = LruCache<String, ImageBitmap>(120)
    private val missing = HashSet<String>()

    fun key(t: Track) = if (t.albumId > 0) "a${t.albumId}" else "t${t.id}"

    suspend fun load(ctx: Context, t: Track): ImageBitmap? {
        val key = key(t)
        cache.get(key)?.let { return it }
        if (synchronized(missing) { key in missing }) return null
        return withContext(Dispatchers.IO) {
            try {
                ctx.contentResolver.loadThumbnail(t.uri, Size(512, 512), null)
                    .asImageBitmap().also { cache.put(key, it) }
            } catch (e: Exception) {
                synchronized(missing) { missing.add(key) }
                null
            }
        }
    }
}

/** Capa do álbum lida da arte embutida no arquivo. */
@Composable
fun ArtImage(track: Track?, modifier: Modifier = Modifier, corner: Dp = 6.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, track?.let { ArtCache.key(it) }) {
        value = if (track == null || track.id < 0) null else ArtCache.load(ctx, track)
    }
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val image = bmp
        if (image != null) {
            Image(image, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            // Sem capa no arquivo: usa a arte padrão do Dosec Waffles Music
            Image(
                painterResource(R.drawable.default_cover), null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
