package com.hires.player.ui

import com.hires.player.tr
import com.hires.player.trf
import android.content.Context
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.isActive
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hires.player.R
import com.hires.player.Track
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// Paleta azul do Tom Music Player, com versão clara e escura.
// O nome "Gold" ficou do tema antigo: é a cor de destaque do app, e muda com o tema.
val Gold: Color get() = if (AppTheme.dark) Color(0xFF64B5F6) else Color(0xFF1976D2)
val GoldDim: Color get() = if (AppTheme.dark) Color(0xFF1E4F7A) else Color(0xFF90CAF9)
val SkyBlue = Color(0xFF29B6F6)       // azul céu
val Aqua = Color(0xFF00ACC1)          // água-marinha
val Sunny = Color(0xFFFFC93C)         // amarelo sol (detalhes)

/** Tema claro ou escuro, escolhido pelo usuário e lembrado entre aberturas. */
object AppTheme {
    var dark by mutableStateOf(false)
        private set

    fun load(context: Context) {
        dark = context.getSharedPreferences("aparencia", Context.MODE_PRIVATE).getBoolean("tema_escuro", false)
    }

    fun set(context: Context, value: Boolean) {
        dark = value
        context.getSharedPreferences("aparencia", Context.MODE_PRIVATE).edit().putBoolean("tema_escuro", value).apply()
    }
}

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1976D2),
    onPrimary = Color.White,
    secondary = Aqua,
    onSecondary = Color.White,
    tertiary = Sunny,
    background = Color(0xFFF3F9FF),
    onBackground = Color(0xFF1B2A4A),
    surface = Color(0xFFF3F9FF),
    onSurface = Color(0xFF1B2A4A),
    surfaceVariant = Color(0xFFDDEEFF),
    onSurfaceVariant = Color(0xFF5A6E8C),
    surfaceContainer = Color(0xFFE1F2FD),
    surfaceContainerHigh = Color(0xFFE8F3FF),
    outline = Color(0xFFB8D8F5),
)

// Fundo escuro: azul-marinho profundo (não preto puro), destaques em azul claro
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF64B5F6),
    onPrimary = Color(0xFF0B1A2E),
    secondary = Color(0xFF4DD0E1),
    onSecondary = Color(0xFF00252B),
    tertiary = Sunny,
    background = Color(0xFF0D1626),
    onBackground = Color(0xFFE6EEF8),
    surface = Color(0xFF0D1626),
    onSurface = Color(0xFFE6EEF8),
    surfaceVariant = Color(0xFF1A2638),
    onSurfaceVariant = Color(0xFF9FB2CC),
    surfaceContainer = Color(0xFF14213A),
    surfaceContainerHigh = Color(0xFF1C2A44),
    outline = Color(0xFF2C3E58),
)

private val AppType = Typography().run {
    copy(
        titleLarge = titleLarge.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = 0.sp),
        titleMedium = titleMedium.copy(fontWeight = FontWeight.Bold),
        headlineSmall = headlineSmall.copy(fontWeight = FontWeight.Bold),
    )
}

/** Fonte monoespaçada para dados técnicos (taxa, bits, codec). */
val TechStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 0.3.sp)

@Composable
fun HiResTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (AppTheme.dark) DarkScheme else LightScheme, typography = AppType, content = content)
}

private object ArtCache {
    private val cache = LruCache<String, ImageBitmap>(120)
    private val missing = HashSet<String>()

    fun key(t: Track) = if (t.albumId > 0) "a${t.albumId}" else "t${t.id}"

    suspend fun load(ctx: Context, t: Track): ImageBitmap? {
        val key = key(t)
        cache.get(key)?.let { return it }
        if (synchronized(missing) { key in missing }) return null
        return withContext(Dispatchers.IO) {
            try {
                ctx.contentResolver.loadThumbnail(t.uri, Size(512, 512), null)
                    .asImageBitmap().also { cache.put(key, it) }
            } catch (e: Exception) {
                synchronized(missing) { missing.add(key) }
                null
            }
        }
    }
}

/**
 * Capa do álbum lida da arte embutida no arquivo.
 * Sem capa, mostra o disco da Maizeninha. Com [playing] informado (tela Tocando agora
 * e mini player), o disco gira enquanto a música toca e para quando ela pausa.
 */
@Composable
fun ArtImage(track: Track?, modifier: Modifier = Modifier, corner: Dp = 6.dp, playing: Boolean? = null) {
    val ctx = LocalContext.current
    // first = já terminou de procurar a capa; second = a capa (ou null se não houver)
    val art by produceState<Pair<Boolean, ImageBitmap?>>(false to null, track?.let { ArtCache.key(it) }) {
        value = false to null
        value = true to (if (track == null || track.id < 0) null else ArtCache.load(ctx, track))
    }
    val (loaded, image) = art

    if (image == null && playing != null) {
        // Disco girando: sem cantos nem fundo, só o vinil redondo
        Box(modifier, contentAlignment = Alignment.Center) {
            if (loaded || track == null) SpinningDisc(playing, Modifier.fillMaxSize())
        }
        return
    }

    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (image != null) {
            Image(image, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else if (loaded || track == null) {
            // Sem capa no arquivo: usa a arte padrão do Tom Music Player
            Image(
                painterResource(R.drawable.default_cover), null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/** O logo da Maizeninha como um disco de vinil: gira tocando, para na pausa. */
@Composable
fun SpinningDisc(playing: Boolean, modifier: Modifier = Modifier) {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        while (isActive) {
            // Uma volta a cada 3,6 s (velocidade calma, parecida com um toca-discos)
            val target = angle.value + 360f
            angle.animateTo(target, tween(durationMillis = 3600, easing = LinearEasing))
            angle.snapTo(angle.value % 360f)
        }
    }
    Image(
        painterResource(R.drawable.default_cover),
        contentDescription = tr("Disco do Tom Music Player"),
        contentScale = ContentScale.Crop,
        modifier = modifier
            .aspectRatio(1f)
            .graphicsLayer { rotationZ = angle.value }
            .clip(CircleShape)
    )
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
