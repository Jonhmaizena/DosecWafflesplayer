package com.hires.player

import android.content.Context
import android.net.Uri
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.Charset

data class LyricLine(val timeMs: Long, val text: String)

sealed class Lyrics {
    /** Letra com tempo de cada linha (LRC, SYLT): acompanha a música. */
    data class Synced(val lines: List<LyricLine>) : Lyrics()
    /** Letra sem tempo: mostrada inteira, para rolar. */
    data class Plain(val text: String) : Lyrics()
}

/** Tudo o que foi lido das tags do arquivo. */
data class FileTags(
    val fields: List<Pair<String, String>>,   // chave (maiúscula) → valor
    val vendor: String,                       // software que gravou as tags (FLAC/OGG)
    val lyrics: Lyrics?,
)

/** De onde o arquivo parece ter vindo, e por quê. */
data class FileOrigin(val name: String, val evidence: String, val known: Boolean = true) {
    companion object { const val UNKNOWN = "Desconhecida" }
}

/**
 * Leitor de tags feito à mão (sem bibliotecas), para FLAC, OGG/Opus, MP3 (ID3v2 e ID3v1),
 * M4A/ALAC/AAC (MP4), WAV e AIFF. Lê só o necessário do começo (ou do fim) do arquivo.
 */
object TagReader {

    private val UTF8 = Charsets.UTF_8
    private val LATIN1 = Charsets.ISO_8859_1

    fun read(context: Context, uri: Uri): FileTags {
        val fields = ArrayList<Pair<String, String>>()
        var vendor = ""
        var syncedText: List<LyricLine>? = null
        var plainText: String? = null

        fun lyricsCandidate(text: String) {
            if (text.isBlank()) return
            val parsed = Lrc.parse(text)
            if (parsed != null) { if (syncedText == null) syncedText = parsed } else if (plainText == null) plainText = text.trim()
        }

        runCatching {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).channel.use { ch ->
                    val size = ch.size()
                    val head = readAt(ch, 0, 12)
                    val tag = String(head, 0, 4, LATIN1)
                    val sink = object : Sink {
                        override fun field(key: String, value: String) {
                            val k = key.uppercase()
                            fields += k to value
                            if (k in LYRIC_KEYS) lyricsCandidate(value)
                        }
                        override fun vendor(v: String) { vendor = v }
                        override fun synced(lines: List<LyricLine>) { if (syncedText == null && lines.isNotEmpty()) syncedText = lines }
                        override fun plainLyrics(text: String) = lyricsCandidate(text)
                    }
                    when {
                        tag == "fLaC" -> parseFlac(ch, 4, sink)
                        tag.startsWith("ID3") -> {
                            val end = parseId3(ch, 0, sink)
                            // FLAC com ID3 na frente
                            if (end + 4 <= size && String(readAt(ch, end, 4), LATIN1) == "fLaC") parseFlac(ch, end + 4, sink)
                        }
                        tag == "OggS" -> parseOgg(ch, sink)
                        String(head, 4, 4, LATIN1) == "ftyp" -> parseMp4(ch, sink)
                        tag == "RIFF" && String(head, 8, 4, LATIN1) == "WAVE" -> parseRiff(ch, sink)
                        tag == "FORM" -> parseAiff(ch, sink)
                    }
                    // ID3v1 no fim (MP3 antigos): comentário de 30 bytes
                    if (size > 128) {
                        val v1 = readAt(ch, size - 128, 128)
                        if (String(v1, 0, 3, LATIN1) == "TAG") {
                            val comment = String(v1, 97, 30, LATIN1).trim('\u0000', ' ')
                            if (comment.isNotEmpty()) sink.field("COMMENT", comment)
                        }
                    }
                }
            }
        }

        val lyrics = syncedText?.let { Lyrics.Synced(it) } ?: plainText?.let { Lyrics.Plain(it) }
        return FileTags(fields, vendor, lyrics)
    }

    private val LYRIC_KEYS = setOf("LYRICS", "UNSYNCEDLYRICS", "UNSYNCED LYRICS", "SYNCEDLYRICS", "LYRIC", "©LYR", "TXXX:LYRICS")

    private interface Sink {
        fun field(key: String, value: String)
        fun vendor(v: String)
        fun synced(lines: List<LyricLine>)
        fun plainLyrics(text: String)
    }

    // ---- utilidades de leitura ----------------------------------------------------------

    private fun readAt(ch: FileChannel, pos: Long, len: Int): ByteArray {
        val buf = ByteBuffer.allocate(len)
        var p = pos
        while (buf.hasRemaining()) {
            val n = ch.read(buf, p)
            if (n <= 0) break
            p += n
        }
        return buf.array().copyOf(buf.position())
    }

    private fun u32le(b: ByteArray, o: Int) =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    private fun u32be(b: ByteArray, o: Int) =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun syncsafe(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or
            ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)

    // ---- FLAC -------------------------------------------------------------------------------

    private fun parseFlac(ch: FileChannel, start: Long, sink: Sink) {
        var pos = start
        repeat(64) {
            val h = readAt(ch, pos, 4)
            if (h.size < 4) return
            val last = (h[0].toInt() and 0x80) != 0
            val type = h[0].toInt() and 0x7F
            val len = ((h[1].toInt() and 0xFF) shl 16) or ((h[2].toInt() and 0xFF) shl 8) or (h[3].toInt() and 0xFF)
            if (type == 4 && len in 1..(16 shl 20)) parseVorbisComment(readAt(ch, pos + 4, len), 0, sink)
            pos += 4 + len
            if (last) return
        }
    }

    /** Bloco de comentários Vorbis (FLAC, OGG Vorbis, Opus). */
    private fun parseVorbisComment(b: ByteArray, start: Int, sink: Sink) {
        var o = start
        if (o + 4 > b.size) return
        val vendorLen = u32le(b, o).toInt(); o += 4
        if (vendorLen < 0 || o + vendorLen > b.size) return
        sink.vendor(String(b, o, vendorLen, UTF8)); o += vendorLen
        if (o + 4 > b.size) return
        val count = u32le(b, o).toInt(); o += 4
        repeat(count.coerceAtMost(4096)) {
            if (o + 4 > b.size) return
            val len = u32le(b, o).toInt(); o += 4
            if (len < 0 || o + len > b.size) return
            val entry = String(b, o, len, UTF8); o += len
            val eq = entry.indexOf('=')
            if (eq > 0) sink.field(entry.substring(0, eq), entry.substring(eq + 1))
        }
    }

    // ---- OGG Vorbis / Opus --------------------------------------------------------------

    private fun parseOgg(ch: FileChannel, sink: Sink) {
        val b = readAt(ch, 0, 512 * 1024)
        val text = String(b, LATIN1)
        val vorbis = text.indexOf("\u0003vorbis")
        val opus = text.indexOf("OpusTags")
        when {
            vorbis >= 0 -> parseVorbisComment(b, vorbis + 7, sink)
            opus >= 0 -> parseVorbisComment(b, opus + 8, sink)
        }
    }

    // ---- ID3v2 (MP3, e dentro de WAV/AIFF) -------------------------------------------------

    /** Lê uma tag ID3v2 que começa em [start]; devolve a posição logo depois dela. */
    private fun parseId3(ch: FileChannel, start: Long, sink: Sink): Long {
        val h = readAt(ch, start, 10)
        if (h.size < 10 || String(h, 0, 3, LATIN1) != "ID3") return start
        val size = syncsafe(h, 6)
        val body = readAt(ch, start + 10, size.coerceAtMost(32 shl 20))
        parseId3Body(body, h[3].toInt(), h[5].toInt(), sink)
        return start + 10 + size + if ((h[5].toInt() and 0x10) != 0) 10 else 0
    }

    private fun parseId3Bytes(b: ByteArray, sink: Sink) {
        if (b.size < 10 || String(b, 0, 3, LATIN1) != "ID3") return
        val size = syncsafe(b, 6).coerceAtMost(b.size - 10)
        parseId3Body(b.copyOfRange(10, 10 + size), b[3].toInt(), b[5].toInt(), sink)
    }

    private fun parseId3Body(b: ByteArray, version: Int, flags: Int, sink: Sink) {
        if (version < 3) return // ID3v2.2 (muito antigo) não é lido
        var o = 0
        if ((flags and 0x40) != 0 && b.size >= 4) {
            o = if (version == 4) syncsafe(b, 0) else (u32be(b, 0).toInt() + 4)
        }
        while (o + 10 <= b.size) {
            val id = String(b, o, 4, LATIN1)
            if (id[0] == '\u0000') break
            val len = if (version == 4) syncsafe(b, o + 4) else u32be(b, o + 4).toInt()
            o += 10
            if (len <= 0 || o + len > b.size) break
            val f = b.copyOfRange(o, o + len)
            o += len
            runCatching { id3Frame(id, f, sink) }
        }
    }

    private fun id3Frame(id: String, f: ByteArray, sink: Sink) {
        when {
            id == "TXXX" -> {
                val enc = f[0].toInt()
                val (desc, next) = readString(f, 1, enc)
                val value = decode(f, next, f.size, enc)
                sink.field("TXXX:${desc.uppercase()}", value)
                if (desc.contains("lyric", ignoreCase = true)) sink.plainLyrics(value)
            }
            id.startsWith("T") -> sink.field(ID3_NAMES[id] ?: id, decode(f, 1, f.size, f[0].toInt()).replace('\u0000', '/'))
            id == "COMM" -> {
                val enc = f[0].toInt()
                val (_, next) = readString(f, 4, enc)
                sink.field("COMMENT", decode(f, next, f.size, enc))
            }
            id == "USLT" -> {
                val enc = f[0].toInt()
                val (_, next) = readString(f, 4, enc)
                sink.plainLyrics(decode(f, next, f.size, enc))
            }
            id == "SYLT" -> {
                val enc = f[0].toInt()
                val tsFormat = f[4].toInt()
                var (_, o) = readString(f, 6, enc)
                if (tsFormat != 2) return // só tempo em milissegundos
                val lines = ArrayList<LyricLine>()
                while (o < f.size) {
                    val (text, next) = readString(f, o, enc)
                    if (next + 4 > f.size) break
                    lines += LyricLine(u32be(f, next), text.trim('\n', '\r', ' '))
                    o = next + 4
                }
                sink.synced(lines.filter { it.text.isNotEmpty() }.sortedBy { it.timeMs })
            }
            id == "WXXX" -> {
                val enc = f[0].toInt()
                val (_, next) = readString(f, 1, enc)
                sink.field("URL", String(f, next, f.size - next, LATIN1).trim('\u0000'))
            }
            id.startsWith("W") -> sink.field("URL", String(f, LATIN1).trim('\u0000'))
            id == "PRIV" -> {
                val end = f.indexOf(0)
                if (end > 0) sink.field("PRIV", String(f, 0, end, LATIN1))
            }
        }
    }

    private val ID3_NAMES = mapOf(
        "TSSE" to "ENCODER", "TENC" to "ENCODED-BY", "TPUB" to "PUBLISHER", "TCOP" to "COPYRIGHT",
        "TMED" to "MEDIA", "TIT2" to "TITLE", "TPE1" to "ARTIST", "TALB" to "ALBUM", "TOWN" to "OWNER",
    )

    private fun charset(enc: Int): Charset = when (enc) {
        1 -> Charsets.UTF_16
        2 -> Charsets.UTF_16BE
        3 -> UTF8
        else -> LATIN1
    }

    /** Lê um texto terminado em zero; devolve o texto e a posição depois do terminador. */
    private fun readString(b: ByteArray, start: Int, enc: Int): Pair<String, Int> {
        val wide = enc == 1 || enc == 2
        var i = start
        if (wide) {
            while (i + 1 < b.size && !(b[i].toInt() == 0 && b[i + 1].toInt() == 0)) i += 2
            return String(b, start, (i - start).coerceAtLeast(0), charset(enc)) to (i + 2).coerceAtMost(b.size)
        }
        while (i < b.size && b[i].toInt() != 0) i++
        return String(b, start, i - start, charset(enc)) to (i + 1).coerceAtMost(b.size)
    }

    private fun decode(b: ByteArray, start: Int, end: Int, enc: Int): String =
        if (start >= end) "" else String(b, start, end - start, charset(enc)).trimEnd('\u0000')

    // ---- MP4 / M4A ------------------------------------------------------------------------

    private fun parseMp4(ch: FileChannel, sink: Sink) {
        val size = ch.size()
        var pos = 0L
        while (pos + 8 <= size) {
            val h = readAt(ch, pos, 16)
            var boxSize = u32be(h, 0)
            val type = String(h, 4, 4, LATIN1)
            var header = 8
            if (boxSize == 1L && h.size >= 16) {
                boxSize = (u32be(h, 8) shl 32) or u32be(h, 12); header = 16
            } else if (boxSize == 0L) boxSize = size - pos
            if (boxSize < header) return
            if (type == "moov") {
                if (boxSize > (32 shl 20)) return
                val moov = readAt(ch, pos + header, (boxSize - header).toInt())
                walkMp4(moov, 0, moov.size, sink)
                return
            }
            pos += boxSize
        }
    }

    private fun walkMp4(b: ByteArray, start: Int, end: Int, sink: Sink) {
        var o = start
        while (o + 8 <= end) {
            val size = u32be(b, o).toInt()
            if (size < 8 || o + size > end) return
            val type = String(b, o + 4, 4, LATIN1)
            when (type) {
                "udta", "ilst" -> walkMp4(b, o + 8, o + size, sink)
                "meta" -> walkMp4(b, o + 12, o + size, sink) // meta tem 4 bytes de versão/flags
                else -> if (isIlstParent(b, start)) mp4Item(type, b, o + 8, o + size, sink)
            }
            o += size
        }
    }

    // Os itens de metadados ficam dentro de 'ilst': identificamos pelo pai
    private fun isIlstParent(b: ByteArray, start: Int): Boolean =
        start >= 8 && String(b, start - 4, 4, LATIN1) == "ilst"

    private fun mp4Item(type: String, b: ByteArray, start: Int, end: Int, sink: Sink) {
        var name = type
        var o = start
        while (o + 8 <= end) {
            val size = u32be(b, o).toInt()
            if (size < 8 || o + size > end) return
            when (String(b, o + 4, 4, LATIN1)) {
                "name" -> name = "----:" + String(b, o + 12, size - 12, UTF8)
                "data" -> {
                    val dataType = u32be(b, o + 8).toInt() and 0xFFFFFF
                    if (dataType == 1 || dataType == 2 || dataType == 0) {
                        val value = String(b, o + 16, size - 16, UTF8)
                        val key = when (type) {
                            "©lyr" -> "LYRICS"
                            "©too" -> "ENCODER"
                            "©cmt" -> "COMMENT"
                            "©nam" -> "TITLE"
                            "cprt" -> "COPYRIGHT"
                            "©pub" -> "PUBLISHER"
                            else -> name
                        }
                        sink.field(key, value)
                    } else if (type == "apID" || type == "purd" || type == "sonm") {
                        sink.field(type, "presente")
                    }
                }
            }
            o += size
        }
        if (type == "apID" || type == "purd") sink.field("ITUNES_PURCHASE", type)
    }

    // ---- WAV e AIFF -------------------------------------------------------------------------

    private fun parseRiff(ch: FileChannel, sink: Sink) {
        val size = ch.size()
        var pos = 12L
        while (pos + 8 <= size) {
            val h = readAt(ch, pos, 12)
            val id = String(h, 0, 4, LATIN1)
            val len = u32le(h, 4)
            when {
                id == "LIST" && h.size >= 12 && String(h, 8, 4, LATIN1) == "INFO" && len < (4 shl 20) -> {
                    val body = readAt(ch, pos + 12, (len - 4).toInt())
                    var o = 0
                    while (o + 8 <= body.size) {
                        val sid = String(body, o, 4, LATIN1)
                        val sl = u32le(body, o + 4).toInt()
                        if (sl < 0 || o + 8 + sl > body.size) break
                        val v = String(body, o + 8, sl, LATIN1).trim('\u0000', ' ')
                        sink.field(RIFF_NAMES[sid] ?: sid, v)
                        o += 8 + sl + (sl and 1)
                    }
                }
                (id == "id3 " || id == "ID3 ") && len < (32 shl 20) -> parseId3Bytes(readAt(ch, pos + 8, len.toInt()), sink)
            }
            pos += 8 + len + (len and 1)
        }
    }

    private val RIFF_NAMES = mapOf("ISFT" to "ENCODER", "ICMT" to "COMMENT", "ICOP" to "COPYRIGHT", "ISRC" to "SOURCE", "INAM" to "TITLE")

    private fun parseAiff(ch: FileChannel, sink: Sink) {
        val size = ch.size()
        var pos = 12L
        while (pos + 8 <= size) {
            val h = readAt(ch, pos, 8)
            val id = String(h, 0, 4, LATIN1)
            val len = u32be(h, 4)
            if ((id == "ID3 " || id == "id3 ") && len < (32 shl 20)) parseId3Bytes(readAt(ch, pos + 8, len.toInt()), sink)
            pos += 8 + len + (len and 1)
        }
    }

    // ---- Origem -----------------------------------------------------------------------------

    private class Rule(val name: String, val needles: List<String>)

    private val RULES = listOf(
        Rule("Qobuz (loja de música em alta resolução)", listOf("qobuz")),
        Rule("Tidal", listOf("tidal")),
        Rule("Deezer", listOf("deezer", "deemix")),
        Rule("Bandcamp", listOf("bandcamp")),
        Rule("HDtracks", listOf("hdtracks")),
        Rule("7digital", listOf("7digital")),
        Rule("Amazon Music", listOf("amazon.com", "amazon music", "amazon song id")),
        Rule("Apple Music / iTunes Store", listOf("itunes_purchase", "itunes store", "apple music")),
        Rule("Beatport", listOf("beatport")),
        Rule("Bleep", listOf("bleep.com")),
        Rule("Spotify (gravado da plataforma, com perdas na origem)", listOf("spotify", "spotdl")),
        Rule("YouTube (baixado, com perdas na origem)", listOf("youtube", "yt-dlp", "youtube-dl", "youtu.be")),
        Rule("SoundCloud", listOf("soundcloud")),
        Rule("CD original (extraído com Exact Audio Copy)", listOf("exact audio copy", "eac ")),
        Rule("CD original (extraído com XLD)", listOf("x lossless decoder", "xld ")),
        Rule("CD original (extraído com dBpoweramp)", listOf("dbpoweramp")),
        Rule("CD original (extraído com CUETools)", listOf("cuetools")),
        Rule("CD original (extraído com fre:ac)", listOf("fre:ac")),
    )

    /** Descobre a origem pelas tags; se nada indicar, a origem é "Desconhecida". */
    fun origin(tags: FileTags): FileOrigin {
        val all = tags.fields.map { (k, v) -> k to v } + ("VENDOR" to tags.vendor)
        for (rule in RULES) {
            for ((k, v) in all) {
                val hay = "${k} ${v}".lowercase() + " "
                if (rule.needles.any { hay.contains(it) }) return FileOrigin(tr(rule.name), evidence(k, v))
            }
        }
        // Mídia de origem declarada (SOURCE / MEDIA / SOURCEMEDIA)
        all.firstOrNull { (k, _) -> k in setOf("SOURCEMEDIA", "MEDIA", "SOURCE", "MEDIATYPE", "TXXX:SOURCE", "TXXX:MEDIA") }
            ?.let { (k, v) ->
                val lv = v.lowercase()
                val name = when {
                    "cd" in lv -> "CD"
                    "vinyl" in lv || "vinil" in lv || "lp" == lv.trim() -> tr("Disco de vinil (digitalizado)")
                    "web" in lv || "digital" in lv -> tr("Loja digital (WEB)")
                    "cassette" in lv || "tape" in lv -> tr("Fita cassete (digitalizada)")
                    "sacd" in lv -> "SACD"
                    "dvd" in lv -> "DVD"
                    else -> null
                }
                if (name != null) return FileOrigin(name, evidence(k, v))
            }
        // Pista mais fraca: convertido com FFmpeg
        all.firstOrNull { (_, v) -> v.lowercase().let { it.contains("lavf") || it.contains("lavc") || it.contains("ffmpeg") } }
            ?.let { (k, v) -> return FileOrigin(tr("Convertido com FFmpeg (origem anterior desconhecida)"), evidence(k, v)) }
        val encoder = all.firstOrNull { (k, _) -> k == "ENCODER" || k == "ENCODED-BY" }?.second
            ?: tags.vendor.takeIf { it.isNotBlank() }
        return FileOrigin(
            tr(FileOrigin.UNKNOWN),
            if (encoder != null) trf("Nenhuma tag indica a origem. Software que gravou o arquivo: %1\$s", encoder.take(60))
            else tr("Nenhuma tag indica a origem do arquivo"),
            known = false,
        )
    }

    private fun evidence(key: String, value: String): String {
        val v = value.replace('\n', ' ').trim().let { if (it.length > 70) it.take(67) + "…" else it }
        val k = key.removePrefix("TXXX:").removePrefix("----:")
        return trf("Encontrado na tag %1\$s: \"%2\$s\"", k, v)
    }
}

/** Leitor de letras no formato LRC: "[01:23.45]texto". */
object Lrc {
    private val TIME = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val OFFSET = Regex("""\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)

    /** Devolve as linhas com tempo, ou null se o texto não for uma letra sincronizada. */
    fun parse(text: String): List<LyricLine>? {
        val offset = OFFSET.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val lines = ArrayList<LyricLine>()
        for (raw in text.lineSequence()) {
            val stamps = TIME.findAll(raw).toList()
            if (stamps.isEmpty()) continue
            val lyric = raw.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.take(3).toLong() }
                lines += LyricLine((min * 60_000 + sec * 1000 + ms - offset).coerceAtLeast(0), lyric)
            }
        }
        if (lines.size < 3) return null
        return lines.sortedBy { it.timeMs }
    }
}
