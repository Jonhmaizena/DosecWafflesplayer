package com.hires.player.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.TextButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.hires.player.TagInfo
import com.hires.player.formatRate
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.hires.player.PlayerUi
import com.hires.player.PlayerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    ui: PlayerUi,
    isFavorite: Boolean,
    onAddToPlaylist: (com.hires.player.Track) -> Unit,
    onOpenEq: () -> Unit,
    onClose: () -> Unit,
) {
    val track = ui.current ?: return
    var showQueue by remember { mutableStateOf(false) }
    var savingQueue by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf<Float?>(null) }

    BackHandler { if (showQueue) showQueue = false else onClose() }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Fechar") }
                Text(
                    "Tocando agora",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onOpenEq) {
                    Icon(Icons.Filled.GraphicEq, "Equalizador", tint = if (ui.eq.enabled) Gold else MaterialTheme.colorScheme.onSurface)
                }
                IconButton(onClick = { showQueue = true }) {
                    Icon(Icons.AutoMirrored.Filled.QueueMusic, "Fila")
                }
            }

            Column(
                Modifier.widthIn(max = 520.dp).padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(12.dp))
                EmbeddedArt(ui.tags.artwork, track, Modifier.fillMaxWidth().aspectRatio(1f))
                Spacer(Modifier.height(24.dp))

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        track.title,
                        style = MaterialTheme.typography.headlineSmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onAddToPlaylist(track) }) {
                        Icon(Icons.AutoMirrored.Filled.PlaylistAdd, "Adicionar à playlist")
                    }
                    IconButton(onClick = { vm.toggleFavorite(track) }) {
                        Icon(
                            if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            if (isFavorite) "Remover dos favoritos" else "Favoritar",
                            tint = if (isFavorite) Gold else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Text(
                    listOf(track.artist, track.album).filter { it.isNotBlank() }.joinToString(" · "),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )
                TagLine(ui.tags)
                Spacer(Modifier.height(12.dp))
                QualityBadge(ui)

                Spacer(Modifier.height(16.dp))
                val dur = ui.durationMs.coerceAtLeast(1L)
                val fraction = dragging ?: (ui.positionMs.toFloat() / dur).coerceIn(0f, 1f)
                Slider(
                    value = fraction,
                    onValueChange = { dragging = it },
                    onValueChangeFinished = {
                        dragging?.let { vm.seekTo((it * dur).toLong()) }
                        dragging = null
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Gold,
                        activeTrackColor = Gold,
                        inactiveTrackColor = MaterialTheme.colorScheme.outline,
                    )
                )
                Row(Modifier.fillMaxWidth()) {
                    Text(
                        formatTime((fraction * dur).toLong()), style = TechStyle,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(ui.durationMs), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = vm::toggleShuffle) {
                        Icon(
                            Icons.Filled.Shuffle, "Aleatório",
                            tint = if (ui.shuffle) Gold else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = vm::previous, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Filled.SkipPrevious, "Anterior", Modifier.size(36.dp))
                    }
                    FilledIconButton(
                        onClick = vm::togglePlay,
                        modifier = Modifier.size(72.dp),
                        shape = CircleShape,
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold)
                    ) {
                        Icon(
                            if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            "Tocar ou pausar",
                            Modifier.size(40.dp)
                        )
                    }
                    IconButton(onClick = vm::next, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Filled.SkipNext, "Próxima", Modifier.size(36.dp))
                    }
                    IconButton(onClick = vm::cycleRepeat) {
                        Icon(
                            if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                            "Repetir",
                            tint = if (ui.repeatMode == Player.REPEAT_MODE_OFF)
                                MaterialTheme.colorScheme.onSurfaceVariant else Gold
                        )
                    }
                }

                Spacer(Modifier.height(24.dp))
                AudioChainCard(
                    ui,
                    onToggleBitPerfect = vm::setBitPerfect,
                    onToggleResampler = vm::setResampler,
                    onOpenEq = onOpenEq,
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (showQueue) {
        ModalBottomSheet(
            onDismissRequest = { showQueue = false },
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Fila · ${ui.queue.size} faixas",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { savingQueue = true }) { Text("Salvar como playlist", color = Gold) }
            }
            QueueList(ui, onJump = vm::jumpTo, onRemove = vm::removeFromQueue)
        }
    }
    if (savingQueue) {
        NameDialog(
            title = "Salvar fila como playlist",
            initial = "",
            confirm = "Salvar",
            onConfirm = { vm.saveQueueAsPlaylist(it); savingQueue = false; showQueue = false },
            onDismiss = { savingQueue = false },
        )
    }
}

@Composable
private fun QualityBadge(ui: PlayerUi) {
    val q = ui.quality
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (q.isHiRes) {
            Text(
                "HI-RES",
                style = TechStyle,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .background(Gold, RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            q.label().ifEmpty { ui.current?.formatLabel ?: "" },
            style = TechStyle,
            color = if (q.isHiRes) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmbeddedArt(bytes: ByteArray?, track: com.hires.player.Track, modifier: Modifier) {
    val bitmap = remember(bytes) {
        bytes?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull() }
    }
    if (bitmap != null) {
        Image(
            bitmap, "Capa do álbum",
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(RoundedCornerShape(12.dp))
        )
    } else {
        ArtImage(track, modifier, corner = 12.dp)
    }
}

@Composable
private fun TagLine(tags: TagInfo) {
    val parts = listOfNotNull(
        tags.albumArtist.ifBlank { null }?.let { "Artista do álbum: $it" },
        tags.year.takeIf { it > 0 }?.toString(),
        tags.genre.ifBlank { null },
        tags.composer.ifBlank { null }?.let { "Comp.: $it" },
        tags.trackOf.ifBlank { null }?.let { "Faixa $it" },
        tags.disc.takeIf { it > 0 }?.let { "Disco $it" },
    )
    if (parts.isEmpty()) return
    Spacer(Modifier.height(4.dp))
    Text(
        parts.joinToString(" · "),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AudioChainCard(
    ui: PlayerUi,
    onToggleBitPerfect: (Boolean) -> Unit,
    onToggleResampler: (Boolean) -> Unit,
    onOpenEq: () -> Unit,
) {
    val c = ui.chain
    val q = ui.quality
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
            .padding(16.dp)
    ) {
        // Resposta direta: está ligado direto ao DAC?
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(10.dp)
                    .background(if (c.direct) Gold else MaterialTheme.colorScheme.outline, CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                if (c.direct) "Conectado direto ao DAC" else "Não conectado direto ao DAC",
                fontWeight = FontWeight.SemiBold,
                color = if (c.direct) Gold else MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            c.dacName.ifEmpty { "Identificando a saída…" },
            style = MaterialTheme.typography.titleMedium,
        )
        if (c.deviceType.isNotEmpty()) {
            val caps = listOfNotNull(
                c.deviceType,
                c.deviceMaxBits.takeIf { it > 0 }?.let { "até $it-bit" },
                c.deviceMaxRate.takeIf { it > 0 }?.let { "até ${formatRate(it)}" },
            ).joinToString(" · ")
            Text(caps, style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(14.dp))
        Text("CADEIA DE ÁUDIO", style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        ChainRow("Arquivo", listOfNotNull(
            q.label().ifEmpty { null },
            q.bitrateKbps.takeIf { it > 0 }?.let { "$it kbps" }
        ).joinToString(" · "))
        ChainRow("Decodificador", c.decoder)
        ChainRow("Processamento", ui.processing.ifEmpty { "Nenhum" })
        ChainRow("App → Android", c.appOutput)
        ChainRow("Caminho", c.path)
        if (!c.direct && c.directAvailable && !c.usb) {
            Text(
                "A saída aceita modo direto para este formato; a escolha final é do sistema do aparelho.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Só aparece quando a saída em uso é o Quad DAC da LG (fone P2 num LG compatível)
        if (c.lgQuadDacInUse) {
            Spacer(Modifier.height(14.dp))
            Text("LG HI-FI QUAD DAC", style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            val msg = when (c.lgState) {
                "Ativado" -> "Em uso na saída P2."
                "Desativado" -> "Desligado no sistema. Ative em Ajustes › Som › Hi-Fi Quad DAC."
                else -> "Fone P2 conectado. O sistema não informa se o Quad DAC está ligado; confira em Ajustes › Som."
            }
            Text(msg, style = MaterialTheme.typography.bodySmall)
            TextButton(
                onClick = {
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                },
                contentPadding = PaddingValues(0.dp)
            ) { Text("Abrir ajustes de som", color = Gold) }
        }

        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Bit-perfect via DAC USB", fontWeight = FontWeight.Medium)
                Text(
                    ui.bitPerfectStatus.ifEmpty { if (ui.bitPerfectOn) "Ligado" else "Desligado" },
                    style = TechStyle,
                    color = if (ui.bitPerfectStatus.startsWith("Ativo")) Gold
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = ui.bitPerfectOn && !ui.eq.enabled,
                onCheckedChange = onToggleBitPerfect,
                enabled = !ui.eq.enabled,
                colors = SwitchDefaults.colors(checkedTrackColor = Gold)
            )
        }
        if (ui.eq.enabled) {
            Text(
                "O bit-perfect só funciona com o equalizador desligado.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
            TextButton(onClick = onOpenEq, contentPadding = PaddingValues(0.dp)) {
                Text("Abrir equalizador", color = Gold)
            }
        }

        // Reamostrador de alta qualidade, logo abaixo do bit-perfect
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Reamostrador de alta qualidade", fontWeight = FontWeight.Medium)
                Text(
                    ui.resamplerStatus.ifEmpty { if (ui.resamplerOn) "Ligado" else "Desligado" },
                    style = TechStyle,
                    color = if (ui.resamplerActive) Gold else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = ui.resamplerOn,
                onCheckedChange = onToggleResampler,
                colors = SwitchDefaults.colors(checkedTrackColor = Gold)
            )
        }
        Text(
            if (ui.resamplerOn)
                "O app converte a faixa para a taxa do Android com um filtro de estúdio, em vez do conversor padrão do sistema. Ligar o bit-perfect desliga o reamostrador."
            else
                "Útil sem DAC USB: evita o conversor simples do Android. Não funciona junto com o bit-perfect.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun ChainRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(110.dp)
        )
        Text(value, style = TechStyle, modifier = Modifier.weight(1f))
    }
}
