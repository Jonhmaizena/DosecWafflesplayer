package com.hires.player.ui

import com.hires.player.tr
import com.hires.player.trf
import android.content.Intent
import android.graphics.BitmapFactory
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Info
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.clickable
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.TextButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.hires.player.TagInfo
import com.hires.player.formatRate
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.OutlinedButton
import com.hires.player.PlayerUi
import com.hires.player.PlayerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    ui: PlayerUi,
    isFavorite: Boolean,
    onAddToPlaylist: (com.hires.player.Track) -> Unit,
    onOpenEq: () -> Unit,
    onAnalyze: (com.hires.player.Track) -> Unit,
    onInfo: (com.hires.player.Track) -> Unit,
    onCritique: (com.hires.player.Track) -> Unit,
    onRecommend: (com.hires.player.Track) -> Unit,
    onClose: () -> Unit,
) {
    val track = ui.current ?: return
    var showQueue by remember { mutableStateOf(false) }
    var savingQueue by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf<Float?>(null) }

    BackHandler { if (showQueue) showQueue = false else onClose() }

    // Na TV, o foco do controle remoto já começa no botão de tocar/pausar
    val tv = rememberIsTv()
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(tv) {
        if (tv) {
            kotlinx.coroutines.delay(400) // espera a tela terminar de entrar
            runCatching { playFocus.requestFocus() }
        }
    }

    // Capa ou letra no mesmo espaço (botão de aspas no topo alterna)
    var showLyrics by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    val artOrLyrics: @Composable (Modifier) -> Unit = { m ->
        if (showLyrics) LyricsView(ui.lyrics, ui.extrasLoading, ui.positionMs, onSeek = vm::seekTo, modifier = m)
        else EmbeddedArt(ui.tags.artwork, track, ui.isPlaying, m)
    }

    // Detalhes da faixa e controles (iguais no celular e na TV)
    val details: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                track.title,
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { onAddToPlaylist(track) }) {
                Icon(Icons.AutoMirrored.Filled.PlaylistAdd, tr("Adicionar à playlist"))
            }
            IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { vm.toggleFavorite(track) }) {
                Icon(
                    if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    if (isFavorite) tr("Remover dos favoritos") else tr("Favoritar"),
                    tint = if (isFavorite) Gold else MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Text(
            listOf(track.artist, track.album).filter { it.isNotBlank() }.joinToString(" · "),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
        TagLine(ui.tags)
        OriginLine(ui.origin, ui.extrasLoading)
        Spacer(Modifier.height(12.dp))
        QualityBadge(ui)

        Spacer(Modifier.height(16.dp))
        val dur = ui.durationMs.coerceAtLeast(1L)
        val fraction = dragging ?: (ui.positionMs.toFloat() / dur).coerceIn(0f, 1f)
        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.seekTo((it * dur).toLong()) }
                dragging = null
            },
            colors = SliderDefaults.colors(
                thumbColor = Gold,
                activeTrackColor = Gold,
                inactiveTrackColor = MaterialTheme.colorScheme.outline,
            )
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                formatTime((fraction * dur).toLong()), style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.weight(1f))
            Text(formatTime(ui.durationMs), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = vm::toggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle, tr("Aleatório"),
                    tint = if (ui.shuffle) Gold else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = vm::previous, modifier = Modifier.tvFocus(CircleShape).size(56.dp)) {
                Icon(Icons.Filled.SkipPrevious, tr("Anterior"), Modifier.size(36.dp))
            }
            FilledIconButton(
                onClick = vm::togglePlay,
                modifier = Modifier.focusRequester(playFocus).tvFocus(CircleShape).size(72.dp),
                shape = CircleShape,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold)
            ) {
                Icon(
                    if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    tr("Tocar ou pausar"),
                    Modifier.size(40.dp)
                )
            }
            IconButton(onClick = vm::next, modifier = Modifier.tvFocus(CircleShape).size(56.dp)) {
                Icon(Icons.Filled.SkipNext, tr("Próxima"), Modifier.size(36.dp))
            }
            IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = vm::cycleRepeat) {
                Icon(
                    if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    tr("Repetir"),
                    tint = if (ui.repeatMode == Player.REPEAT_MODE_OFF)
                        MaterialTheme.colorScheme.onSurfaceVariant else Gold
                )
            }
        }

        // Crítica do álbum/música e gaveta de recomendações
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { onCritique(track) }, modifier = Modifier.weight(1f).tvFocus()) {
                Icon(Icons.Filled.RateReview, null, Modifier.size(18.dp), tint = Gold)
                Spacer(Modifier.width(8.dp))
                Text(tr("Crítica"), maxLines = 1)
            }
            OutlinedButton(onClick = { onRecommend(track) }, modifier = Modifier.weight(1f).tvFocus()) {
                Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp), tint = Gold)
                Spacer(Modifier.width(8.dp))
                Text(tr("Recomendações"), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(Modifier.height(24.dp))
        AudioChainCard(
            ui,
            onToggleBitPerfect = vm::setBitPerfect,
            onToggleResampler = vm::setResampler,
            onToggleAuto = vm::setBitPerfectAuto,
            onOpenEq = onOpenEq,
        )
        Spacer(Modifier.height(24.dp))
        DosecFooter()
        Spacer(Modifier.height(24.dp))
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        BoxWithConstraints(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // Tela deitada e larga (TV, tablet): capa à esquerda, controles à direita
            val wide = maxWidth > maxHeight && maxWidth >= 600.dp
            val artSize = (maxHeight - 96.dp).coerceIn(160.dp, 420.dp)
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, tr("Fechar")) }
                    Text(
                        tr("Tocando agora"),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { showLyrics = !showLyrics }) {
                        Icon(
                            Icons.Filled.FormatQuote, tr("Letra"),
                            tint = when {
                                showLyrics -> Gold
                                ui.lyrics != null -> MaterialTheme.colorScheme.onSurface
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { onInfo(track) }) {
                        Icon(Icons.Filled.Info, tr("Sobre a música"))
                    }
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { onAnalyze(track) }) {
                        Icon(Icons.Filled.Insights, tr("Analisar espectro"))
                    }
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onOpenEq) {
                        Icon(Icons.Filled.GraphicEq, tr("Equalizador"), tint = if (ui.eq.enabled || ui.widthOn) Gold else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { showQueue = true }) {
                        Icon(Icons.AutoMirrored.Filled.QueueMusic, tr("Fila"))
                    }
                }

                if (wide) {
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 32.dp),
                        horizontalArrangement = Arrangement.spacedBy(40.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        artOrLyrics(Modifier.size(artSize))
                        Column(
                            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Spacer(Modifier.height(16.dp))
                            details()
                        }
                    }
                } else {
                    Column(
                        Modifier
                            .widthIn(max = 520.dp)
                            .fillMaxWidth()
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(Modifier.height(12.dp))
                        artOrLyrics(Modifier.fillMaxWidth().aspectRatio(1f))
                        Spacer(Modifier.height(24.dp))
                        details()
                    }
                }
            }
        }
    }

    if (showQueue) {
        ModalBottomSheet(
            onDismissRequest = { showQueue = false },
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    trf("Fila · %1\$s faixas", ui.queue.size),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { savingQueue = true }) { Text(tr("Salvar como playlist"), color = Gold) }
            }
            QueueList(ui, onJump = vm::jumpTo, onRemove = vm::removeFromQueue)
        }
    }
    if (savingQueue) {
        NameDialog(
            title = tr("Salvar fila como playlist"),
            initial = "",
            confirm = tr("Salvar"),
            onConfirm = { vm.saveQueueAsPlaylist(it); savingQueue = false; showQueue = false },
            onDismiss = { savingQueue = false },
        )
    }
}

@Composable
private fun QualityBadge(ui: PlayerUi) {
    val q = ui.quality
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (q.isHiRes) {
            Text(
                "HI-RES",
                style = TechStyle,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .background(Gold, RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            q.label().ifEmpty { ui.current?.formatLabel ?: "" },
            style = TechStyle,
            color = if (q.isHiRes) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmbeddedArt(bytes: ByteArray?, track: com.hires.player.Track, playing: Boolean, modifier: Modifier) {
    val bitmap = remember(bytes) {
        bytes?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull() }
    }
    if (bitmap != null) {
        Image(
            bitmap, tr("Capa do álbum"),
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(RoundedCornerShape(12.dp))
        )
    } else {
        ArtImage(track, modifier, corner = 12.dp, playing = playing)
    }
}

@Composable
private fun TagLine(tags: TagInfo) {
    val parts = listOfNotNull(
        tags.albumArtist.ifBlank { null }?.let { trf("Artista do álbum: %1\$s", it) },
        tags.year.takeIf { it > 0 }?.toString(),
        tags.genre.ifBlank { null },
        tags.composer.ifBlank { null }?.let { trf("Comp.: %1\$s", it) },
        tags.trackOf.ifBlank { null }?.let { trf("Faixa %1\$s", it) },
        tags.disc.takeIf { it > 0 }?.let { trf("Disco %1\$s", it) },
    )
    if (parts.isEmpty()) return
    Spacer(Modifier.height(4.dp))
    Text(
        parts.joinToString(" · "),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AudioChainCard(
    ui: PlayerUi,
    onToggleBitPerfect: (Boolean) -> Unit,
    onToggleResampler: (Boolean) -> Unit,
    onToggleAuto: (Boolean) -> Unit,
    onOpenEq: () -> Unit,
) {
    val c = ui.chain
    val q = ui.quality
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
            .padding(16.dp)
    ) {
        // Luz de status do DAC: verde = DAC externo/Quad DAC conectado, vermelha = não conectado
        val dacConnected = c.usb || (c.lgQuadDacInUse && c.lgState != "Desativado")
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusLight(on = dacConnected)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    if (dacConnected) tr("DAC conectado") else tr("DAC não conectado"),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (dacConnected) LedGreen else LedRed
                )
                Text(
                    when {
                        c.direct -> tr("Conexão direta (bit-perfect)")
                        ui.nativeRate -> tr("Sem reamostragem, pelo mixer do Android")
                        dacConnected -> tr("Pelo mixer do Android")
                        else -> tr("Usando o DAC interno ou Bluetooth")
                    },
                    style = TechStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            c.dacName.ifEmpty { tr("Identificando a saída…") },
            style = MaterialTheme.typography.titleMedium,
        )
        if (c.deviceType.isNotEmpty()) {
            val caps = listOfNotNull(
                c.deviceType,
                c.deviceMaxBits.takeIf { it > 0 }?.let { trf("até %1\$s-bit", it) },
                c.deviceMaxRate.takeIf { it > 0 }?.let { trf("até %1\$s", formatRate(it)) },
            ).joinToString(" · ")
            Text(caps, style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(14.dp))
        Text(tr("CADEIA DE ÁUDIO"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        ChainRow(tr("Arquivo"), listOfNotNull(
            q.label().ifEmpty { null },
            q.bitrateKbps.takeIf { it > 0 }?.let { trf("%1\$s kbps", it) }
        ).joinToString(" · "))
        ChainRow(tr("Decodificador"), c.decoder)
        ChainRow(tr("Processamento"), ui.processing.ifEmpty { tr("Nenhum") })
        ChainRow(tr("App → Android"), c.appOutput)
        ChainRow(tr("Caminho"), c.path)
        if (!c.direct && c.directAvailable && !c.usb) {
            Text(
                tr("A saída aceita modo direto para este formato; a escolha final é do sistema do aparelho."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Só aparece quando a saída em uso é o Quad DAC da LG (fone P2 num LG compatível)
        if (c.lgQuadDacInUse) {
            Spacer(Modifier.height(14.dp))
            Text("LG HI-FI QUAD DAC", style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            val lineage = c.customRom == "LineageOS"
            val msg = when (c.lgState) {
                "Ativado" -> tr("Ligado e em uso na saída P2.") +
                    if (c.lgMode.isNotEmpty()) trf(" Modo: %1\$s.", c.lgMode) else ""
                "Desativado" ->
                    if (lineage) tr("Desligado. Ative no painel Quad DAC da LineageOS.")
                    else tr("Desligado no sistema. Ative em Ajustes › Som › Hi-Fi Quad DAC.")
                else ->
                    if (lineage) tr("Fone P2 conectado. O Android não deixou o app ler o estado do Quad DAC; confira no painel Quad DAC.")
                    else tr("Fone P2 conectado. O sistema não informa se o Quad DAC está ligado; confira em Ajustes › Som.")
            }
            Text(msg, style = MaterialTheme.typography.bodySmall)
            TextButton(
                onClick = {
                    // Na LineageOS abre o painel Quad DAC (com impedância); senão, os ajustes de som
                    val panel = Intent().setComponent(
                        android.content.ComponentName(
                            "org.lineageos.settings.device.dac",
                            "org.lineageos.settings.device.dac.QuadDACPanelActivity"
                        )
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    val sound = Intent(Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { ctx.startActivity(if (lineage) panel else sound) }
                        .onFailure { runCatching { ctx.startActivity(sound) } }
                },
                contentPadding = PaddingValues(0.dp)
            ) { Text(if (lineage) tr("Abrir painel Quad DAC") else tr("Abrir ajustes de som"), color = Gold) }
        }

        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Conexão direta ao DAC USB (bit-perfect)"), fontWeight = FontWeight.Medium)
                Text(
                    ui.bitPerfectStatus.ifEmpty { if (ui.bitPerfectOn) tr("Ligado") else tr("Desligado") },
                    style = TechStyle,
                    color = if (ui.chain.direct) Gold
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = ui.bitPerfectOn && !ui.eq.enabled && !ui.widthOn,
                onCheckedChange = onToggleBitPerfect,
                enabled = !ui.eq.enabled && !ui.widthOn,
                colors = SwitchDefaults.colors(checkedTrackColor = Gold)
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .tvFocus().clickable(enabled = !ui.eq.enabled && !ui.widthOn) { onToggleAuto(!ui.bitPerfectAuto) }
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = ui.bitPerfectAuto,
                onCheckedChange = onToggleAuto,
                enabled = !ui.eq.enabled && !ui.widthOn,
                colors = CheckboxDefaults.colors(checkedColor = Gold)
            )
            Text(tr("Ligar sozinho ao conectar um DAC USB"), style = MaterialTheme.typography.bodySmall)
        }
        if (c.usb && ui.usbDiagnostics.isNotEmpty()) {
            Text(
                trf("O que o Android oferece para este DAC: %1\$s", ui.usbDiagnostics),
                style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        if (ui.eq.enabled || ui.widthOn) {
            Text(
                when {
                    ui.eq.enabled && ui.widthOn -> tr("O bit-perfect só funciona com o equalizador e o Palco desligados.")
                    ui.widthOn -> tr("O bit-perfect só funciona com o Palco desligado.")
                    else -> tr("O bit-perfect só funciona com o equalizador desligado.")
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
            TextButton(onClick = onOpenEq, contentPadding = PaddingValues(0.dp)) {
                Text(if (ui.widthOn && !ui.eq.enabled) tr("Abrir Palco") else tr("Abrir equalizador"), color = Gold)
            }
        }

        // Reamostrador de alta qualidade, logo abaixo do bit-perfect
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Reamostrador de alta qualidade"), fontWeight = FontWeight.Medium)
                Text(
                    ui.resamplerStatus.ifEmpty { if (ui.resamplerOn) tr("Ligado") else tr("Desligado") },
                    style = TechStyle,
                    color = if (ui.resamplerActive) Gold else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = ui.resamplerOn,
                onCheckedChange = onToggleResampler,
                colors = SwitchDefaults.colors(checkedTrackColor = Gold)
            )
        }
        Text(
            if (ui.resamplerOn)
                tr("O app converte a faixa para a taxa do Android com um filtro de estúdio, em vez do conversor padrão do sistema. Ligar o bit-perfect desliga o reamostrador.")
            else
                tr("Útil sem DAC USB: evita o conversor simples do Android. Não funciona junto com o bit-perfect."),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun ChainRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(110.dp)
        )
        Text(value, style = TechStyle, modifier = Modifier.weight(1f))
    }
}

private val LedGreen = androidx.compose.ui.graphics.Color(0xFF2EBD5A)
private val LedRed = androidx.compose.ui.graphics.Color(0xFFE5484D)

/** Luz de LED com brilho: verde quando ligada, vermelha quando desligada. */
@Composable
private fun StatusLight(on: Boolean) {
    val color = if (on) LedGreen else LedRed
    Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        // brilho em volta da luz
        Box(Modifier.size(22.dp).background(color.copy(alpha = 0.22f), CircleShape))
        Box(Modifier.size(14.dp).background(color, CircleShape))
        // reflexo, para parecer um LED
        Box(
            Modifier
                .size(5.dp)
                .offset(x = (-2).dp, y = (-2).dp)
                .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f), CircleShape)
        )
    }
}

/** Origem do arquivo, lida das tags. Toque para ver em qual tag a pista foi encontrada. */
@Composable
private fun OriginLine(origin: com.hires.player.FileOrigin?, loading: Boolean) {
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 4.dp)
            .tvFocus()
            .clickable(enabled = origin != null) { open = !open }
    ) {
        Text(
            when {
                origin != null -> trf("Origem: %1\$s", origin.name)
                loading -> tr("Origem: verificando…")
                else -> tr("Origem: Desconhecida")
            },
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = if (origin?.known == true) Gold else MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (open && origin != null) {
            Text(origin.evidence, style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Letra: sincronizada (linha atual em destaque, acompanha a música) ou texto corrido. */
@Composable
private fun LyricsView(
    lyrics: com.hires.player.Lyrics?,
    loading: Boolean,
    positionMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        when (lyrics) {
            null -> Text(
                if (loading) tr("Procurando a letra nos metadados…")
                else tr("Esta música não tem letra nos metadados do arquivo"),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
            is com.hires.player.Lyrics.Plain -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
            ) {
                Text(tr("LETRA (SEM SINCRONIZAÇÃO)"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Text(lyrics.text, style = MaterialTheme.typography.bodyLarge)
            }
            is com.hires.player.Lyrics.Synced -> {
                val lines = lyrics.lines
                // Linha atual: a última que já começou (com um pequeno adiantamento)
                val current = lines.indexOfLast { it.timeMs <= positionMs + 150 }
                val listState = androidx.compose.foundation.lazy.rememberLazyListState()
                LaunchedEffect(current) {
                    if (current >= 0) listState.animateScrollToItem((current - 2).coerceAtLeast(0))
                }
                androidx.compose.foundation.lazy.LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 24.dp)
                ) {
                    items(lines.size) { i ->
                        val line = lines[i]
                        val isCurrent = i == current
                        Text(
                            line.text.ifEmpty { "♪" },
                            style = if (isCurrent) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyLarge,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = when {
                                isCurrent -> Gold
                                i < current -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .tvFocus()
                                .clickable { onSeek(line.timeMs) } // toque numa linha para ir até ela
                                .padding(vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
