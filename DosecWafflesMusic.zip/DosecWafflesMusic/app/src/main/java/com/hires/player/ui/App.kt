package com.hires.player.ui

import com.hires.player.tr
import com.hires.player.trf
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hires.player.Group
import com.hires.player.MusicRepository
import com.hires.player.PlayerUi
import com.hires.player.PlayerViewModel
import com.hires.player.Playlist
import com.hires.player.Track

private enum class LibTab(val label: String) {
    Songs("Músicas"), Favorites("Favoritas"), Playlists("Playlists"),
    Albums("Álbuns"), Artists("Artistas"), Folders("Pastas")
}

@Composable
fun HiResApp(vm: PlayerViewModel, hasPermission: Boolean, onRequestPermission: () -> Unit) {
    HiResTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!hasPermission) PermissionScreen(onRequestPermission) else Library(vm)
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tr("Dosec Waffles Music"), style = MaterialTheme.typography.headlineSmall, color = Gold)
        Spacer(Modifier.height(12.dp))
        Text(
            tr("Para mostrar suas músicas, o app precisa de acesso aos arquivos de áudio do celular."),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text(tr("Permitir acesso às músicas")) }
    }
}

/** Tudo o que uma linha de música pode fazer. */
class TrackActions(
    val play: (List<Track>, Int) -> Unit,
    val shuffle: (List<Track>) -> Unit,
    val playNext: (Track) -> Unit,
    val addToQueue: (Track) -> Unit,
    val isFavorite: (Long) -> Boolean,
    val toggleFavorite: (Track) -> Unit,
    val addToPlaylist: (List<Track>) -> Unit,
    val analyze: (Track) -> Unit,
    val info: (Track) -> Unit,
)

@Composable
private fun Library(vm: PlayerViewModel) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Group?>(null) }
    var openPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var nowPlaying by rememberSaveable { mutableStateOf(false) }
    var showEq by rememberSaveable { mutableStateOf(false) }
    var pickFor by remember { mutableStateOf<List<Track>?>(null) }
    var creatingPlaylist by remember { mutableStateOf(false) }
    var analyzeTrack by remember { mutableStateOf<Track?>(null) }
    var infoTrack by remember { mutableStateOf<Track?>(null) }
    var critiqueTrack by remember { mutableStateOf<Track?>(null) }
    var choosingLanguage by remember { mutableStateOf(false) }
    var supporting by remember { mutableStateOf(false) }

    // Posição de cada lista: fica guardada ao abrir o player, um álbum ou artista e voltar
    val songsState = rememberLazyListState()
    val favoritesState = rememberLazyListState()
    val albumsState = rememberLazyGridState()
    val artistsState = rememberLazyListState()
    val foldersState = rememberLazyListState()
    val playlistsState = rememberLazyListState()
    val detailStates = remember { mutableMapOf<String, LazyListState>() }

    val byId = remember(tracks) { tracks.associateBy { it.id } }
    val albums = remember(tracks) { MusicRepository.albums(tracks) }
    val artists = remember(tracks) { MusicRepository.artists(tracks) }
    val folders = remember(tracks) { MusicRepository.folders(tracks) }
    val favoriteTracks = remember(tracks, library.favorites) { library.favorites.mapNotNull { byId[it] } }
    val openPlaylist = library.playlists.firstOrNull { it.id == openPlaylistId }

    val inSub = detail != null || openPlaylist != null || searching
    fun goBack() {
        when {
            openPlaylist != null -> openPlaylistId = null
            detail != null -> detail = null
            else -> { searching = false; query = "" }
        }
    }
    BackHandler(enabled = !nowPlaying && !showEq && inSub) { goBack() }

    val tv = rememberIsTv()
    val overlayOpen = (nowPlaying && ui.current != null) || showEq || analyzeTrack != null || infoTrack != null || critiqueTrack != null
    val libraryState = rememberSaveableStateHolder()

    val actions = TrackActions(
        // Na TV, escolher uma música já abre o player (no celular fica na lista)
        play = { list, i -> vm.playList(list, i); if (tv) nowPlaying = true },
        shuffle = { list -> vm.playList(list, 0, shuffle = true); if (tv) nowPlaying = true },
        playNext = vm::playNext,
        addToQueue = vm::addToQueue,
        isFavorite = { id -> id in library.favorites },
        toggleFavorite = vm::toggleFavorite,
        addToPlaylist = { pickFor = it },
        analyze = { analyzeTrack = it },
        info = { infoTrack = it },
    )

    Box(Modifier.fillMaxSize()) {
        // Na TV, a biblioteca sai de cena enquanto o player está aberto: assim o controle
        // remoto não "escapa" para itens escondidos atrás dele. A posição das listas é mantida.
        if (!(tv && overlayOpen)) libraryState.SaveableStateProvider("biblioteca") {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Cabeçalho
            Row(
                Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (inSub) {
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = ::goBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Voltar")) }
                } else {
                    Spacer(Modifier.width(12.dp))
                }
                if (searching && detail == null && openPlaylist == null) {
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text(tr("Buscar música, artista ou álbum")) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                        ),
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Text(
                        openPlaylist?.name ?: detail?.title ?: tr("Biblioteca"),
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    // Atalho para o player, fácil de alcançar pelo controle remoto
                    if (tv && ui.current != null) {
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { nowPlaying = true }) {
                            Icon(Icons.Filled.MusicNote, tr("Abrir o player"), tint = Gold)
                        }
                    }
                    if (!inSub) {
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { showEq = true }) {
                            Icon(
                                Icons.Filled.GraphicEq, tr("Equalizador"),
                                tint = if (ui.eq.enabled || ui.widthOn) Gold else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { searching = true }) { Icon(Icons.Filled.Search, tr("Buscar")) }
                        // Apoiar o projeto do DOSEC (PIX)
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { supporting = true }) {
                            Icon(Icons.Filled.VolunteerActivism, tr("Apoiar o projeto do DOSEC"), tint = Gold)
                        }
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { choosingLanguage = true }) {
                            Icon(Icons.Filled.Language, tr("Idioma"))
                        }
                        // Alterna entre tema claro e escuro (fica salvo)
                        val themeCtx = androidx.compose.ui.platform.LocalContext.current
                        IconButton(
                            modifier = Modifier.tvFocus(CircleShape),
                            onClick = { AppTheme.set(themeCtx, !AppTheme.dark) }
                        ) {
                            Icon(
                                if (AppTheme.dark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                                if (AppTheme.dark) tr("Usar tema claro") else tr("Usar tema escuro")
                            )
                        }
                    }
                }
            }

            Box(Modifier.weight(1f)) {
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Gold)
                    }
                    tracks.isEmpty() -> EmptyState(
                        tr("Nenhuma música encontrada"),
                        tr("Copie seus arquivos FLAC, WAV ou MP3 para a pasta Music do celular e abra o app de novo.")
                    )
                    openPlaylist != null -> PlaylistDetail(
                        playlist = openPlaylist,
                        tracks = openPlaylist.trackIds.mapNotNull { byId[it] },
                        missing = openPlaylist.trackIds.count { it !in byId },
                        ui = ui,
                        actions = actions,
                        onRename = { vm.renamePlaylist(openPlaylist.id, it) },
                        onDelete = { vm.deletePlaylist(openPlaylist.id); openPlaylistId = null },
                        onRemove = { i -> vm.removeFromPlaylist(openPlaylist.id, i) },
                        onMove = { from, to -> vm.movePlaylistTrack(openPlaylist.id, from, to) },
                        state = detailStates.getOrPut("playlist:" + openPlaylist.id) { LazyListState() },
                    )
                    detail != null -> DetailView(detail!!, ui, actions, detailStates.getOrPut(detail!!.key) { LazyListState() })
                    searching -> {
                        val q = query.trim().lowercase()
                        val found = remember(q, tracks) {
                            if (q.isEmpty()) emptyList() else tracks.filter {
                                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                                    it.album.lowercase().contains(q)
                            }
                        }
                        TrackList(found, ui, actions, showHeader = false)
                    }
                    else -> Column {
                        ScrollableTabRow(
                            selectedTabIndex = tab,
                            containerColor = Color.Transparent,
                            contentColor = Gold,
                            edgePadding = 8.dp,
                        ) {
                            LibTab.entries.forEachIndexed { i, t ->
                                Tab(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    text = { Text(com.hires.player.tr(t.label), maxLines = 1) },
                                    unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        when (LibTab.entries[tab]) {
                            LibTab.Songs -> TrackList(tracks, ui, actions, showHeader = true, state = songsState)
                            LibTab.Favorites ->
                                if (favoriteTracks.isEmpty()) EmptyState(
                                    tr("Nenhuma favorita ainda"),
                                    tr("Toque no coração na tela Tocando agora, ou em ⋮ › Favoritar em qualquer música.")
                                ) else TrackList(favoriteTracks, ui, actions, showHeader = true, state = favoritesState)
                            LibTab.Playlists -> PlaylistList(
                                library.playlists, byId,
                                onCreate = { creatingPlaylist = true },
                                onOpen = { openPlaylistId = it.id },
                                state = playlistsState,
                            )
                            LibTab.Albums -> AlbumGrid(albums, albumsState) { detail = it }
                            LibTab.Artists -> GroupList(artists, Icons.Filled.Person, artistsState) { detail = it }
                            LibTab.Folders -> GroupList(folders, Icons.Filled.Folder, foldersState) { detail = it }
                        }
                    }
                }
            }

            if (ui.current != null) {
                MiniPlayer(ui, onOpen = { nowPlaying = true }, onToggle = vm::togglePlay, onNext = vm::next)
            } else {
                Spacer(Modifier.navigationBarsPadding())
            }
        }
        }

        AnimatedVisibility(
            visible = nowPlaying && ui.current != null && !showEq && analyzeTrack == null && infoTrack == null && critiqueTrack == null,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlayingScreen(
                vm, ui,
                isFavorite = ui.current?.id?.let { it in library.favorites } == true,
                onAddToPlaylist = { t -> pickFor = listOf(t) },
                onOpenEq = { showEq = true },
                onAnalyze = { t -> analyzeTrack = t },
                onInfo = { t -> infoTrack = t },
                onCritique = { t -> critiqueTrack = t },
                onClose = { nowPlaying = false },
            )
        }

        AnimatedVisibility(
            visible = showEq,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
        ) {
            EqualizerScreen(
                state = ui.eq,
                bitPerfectOn = ui.bitPerfectOn,
                onChange = vm::setEq,
                widthOn = ui.widthOn,
                widthAmount = ui.widthAmount,
                onWidth = vm::setWidth,
                onClose = { showEq = false },
            )
        }

        // Sobre a música, o álbum e o artista (dados da internet salvos offline)
        infoTrack?.let { t ->
            InfoScreen(track = t, library = tracks, onClose = { infoTrack = null })
        }

        // Crítica do álbum e da música (traduzida para o idioma do app)
        critiqueTrack?.let { t ->
            CritiqueScreen(track = t, onClose = { critiqueTrack = null })
        }

        // Analisador de espectro (por cima de tudo)
        analyzeTrack?.let { t ->
            AnalyzerScreen(
                track = t,
                knownBits = if (ui.current?.id == t.id) ui.quality.bits else 0,
                onClose = { analyzeTrack = null },
            )
        }
    }

    // Escolher playlist para adicionar
    pickFor?.let { toAdd ->
        PlaylistPicker(
            playlists = library.playlists,
            count = toAdd.size,
            onPick = { p -> vm.addToPlaylist(p.id, toAdd); pickFor = null },
            onCreate = { name -> val id = vm.createPlaylist(name); vm.addToPlaylist(id, toAdd); pickFor = null },
            onDismiss = { pickFor = null },
        )
    }
    if (supporting) SupportDialog(onDismiss = { supporting = false })
    if (choosingLanguage) {
        LanguageDialog(
            current = com.hires.player.L.lang,
            onPick = { code -> vm.setLanguage(code); choosingLanguage = false },
            onDismiss = { choosingLanguage = false },
        )
    }
    if (creatingPlaylist) {
        NameDialog(
            title = tr("Nova playlist"),
            initial = "",
            confirm = tr("Criar"),
            onConfirm = { name -> openPlaylistId = vm.createPlaylist(name); creatingPlaylist = false },
            onDismiss = { creatingPlaylist = false },
        )
    }
}

/** Escolha do idioma do app. */
@Composable
private fun LanguageDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Idioma")) },
        text = {
            Column {
                com.hires.player.L.names.forEach { (code, name) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .tvFocus()
                            .clickable { onPick(code) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = code == current, onClick = { onPick(code) })
                        Spacer(Modifier.width(8.dp))
                        Text(name, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fechar")) } },
    )
}

@Composable
private fun EmptyState(title: String, body: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlayShuffleRow(tracks: List<Track>, actions: TrackActions) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(onClick = { actions.play(tracks, 0) }, modifier = Modifier.weight(1f), enabled = tracks.isNotEmpty()) {
            Icon(Icons.Filled.PlayArrow, null)
            Spacer(Modifier.width(6.dp))
            Text(tr("Tocar"))
        }
        OutlinedButton(
            onClick = { actions.shuffle(tracks) },
            modifier = Modifier.weight(1f),
            enabled = tracks.isNotEmpty(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
        ) {
            Icon(Icons.Filled.Shuffle, null)
            Spacer(Modifier.width(6.dp))
            Text(tr("Aleatório"))
        }
    }
}

@Composable
private fun TrackList(
    tracks: List<Track>,
    ui: PlayerUi,
    actions: TrackActions,
    showHeader: Boolean,
    state: LazyListState = rememberLazyListState(),
) {
    val header = if (showHeader && tracks.isNotEmpty()) 1 else 0
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(bottom = 8.dp)) {
            if (header == 1) {
                item { PlayShuffleRow(tracks, actions) }
            }
            itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
                TrackRow(t, isCurrent = ui.current?.id == t.id, actions = actions, showArt = true) {
                    actions.play(tracks, i)
                }
            }
        }
        FastScroller(state, tracks.size, headerItems = header, label = { tracks[it].title }, modifier = Modifier.align(Alignment.CenterEnd))
    }
}

@Composable
private fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    actions: TrackActions,
    showArt: Boolean,
    leading: String? = null,
    extraMenu: (@Composable (close: () -> Unit) -> Unit)? = null,
    onClick: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val fav = actions.isFavorite(track.id)
    Row(
        Modifier
            .fillMaxWidth()
            .tvFocus().clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showArt) {
            ArtImage(track, Modifier.size(48.dp))
        } else {
            Text(
                leading ?: if (track.trackNumber > 0) track.trackNumber.toString() else "–",
                style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(28.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) Gold else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                FormatTag(track)
                Spacer(Modifier.width(6.dp))
                if (fav) {
                    Icon(Icons.Filled.Favorite, tr("Favorita"), tint = Gold, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    "${track.artist} · ${formatTime(track.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box {
            IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, tr("Opções"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(tr("Tocar a seguir")) }, onClick = { menu = false; actions.playNext(track) })
                DropdownMenuItem(text = { Text(tr("Adicionar à fila")) }, onClick = { menu = false; actions.addToQueue(track) })
                DropdownMenuItem(
                    text = { Text(if (fav) tr("Remover dos favoritos") else tr("Favoritar")) },
                    leadingIcon = {
                        Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                            tint = if (fav) Gold else MaterialTheme.colorScheme.onSurfaceVariant)
                    },
                    onClick = { menu = false; actions.toggleFavorite(track) }
                )
                DropdownMenuItem(
                    text = { Text(tr("Adicionar à playlist…")) },
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null) },
                    onClick = { menu = false; actions.addToPlaylist(listOf(track)) }
                )
                DropdownMenuItem(
                    text = { Text(tr("Sobre a música, álbum e artista")) },
                    leadingIcon = { Icon(Icons.Filled.Info, null) },
                    onClick = { menu = false; actions.info(track) }
                )
                DropdownMenuItem(
                    text = { Text(tr("Analisar espectro")) },
                    leadingIcon = { Icon(Icons.Filled.Insights, null) },
                    onClick = { menu = false; actions.analyze(track) }
                )
                if (extraMenu != null) {
                    HorizontalDivider()
                    extraMenu { menu = false }
                }
            }
        }
    }
}

@Composable
private fun FormatTag(track: Track) {
    val lossless = track.isLossless
    Text(
        track.formatLabel,
        style = TechStyle.copy(fontSize = MaterialTheme.typography.labelSmall.fontSize),
        color = if (lossless) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .background(
                if (lossless) Gold.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(3.dp)
            )
            .padding(horizontal = 4.dp, vertical = 1.dp)
    )
}

@Composable
private fun AlbumGrid(albums: List<Group>, state: LazyGridState = rememberLazyGridState(), onOpen: (Group) -> Unit) {
    Box(Modifier.fillMaxSize()) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        state = state,
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 24.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(albums, key = { it.key }) { album ->
            Column(Modifier.tvFocus().clickable { onOpen(album) }.padding(4.dp)) {
                ArtImage(album.tracks.first(), Modifier.fillMaxWidth().aspectRatio(1f), corner = 8.dp)
                Spacer(Modifier.height(8.dp))
                Text(album.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    album.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
    FastScroller(state, albums.size, label = { albums[it].title }, modifier = Modifier.align(Alignment.CenterEnd))
    }
}

@Composable
private fun GroupList(groups: List<Group>, icon: ImageVector, state: LazyListState = rememberLazyListState(), onOpen: (Group) -> Unit) {
    Box(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize(), state = state) {
        items(groups, key = { it.key }) { g ->
            ListRow(
                title = g.title,
                subtitle = g.subtitle,
                leading = {
                    Box(
                        Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(22.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                },
                onClick = { onOpen(g) }
            )
        }
    }
    FastScroller(state, groups.size, label = { groups[it].title }, modifier = Modifier.align(Alignment.CenterEnd))
    }
}

@Composable
private fun ListRow(title: String, subtitle: String, leading: @Composable () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .tvFocus().clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---- Playlists -----------------------------------------------------------------------------

@Composable
private fun PlaylistList(
    playlists: List<Playlist>,
    byId: Map<Long, Track>,
    onCreate: () -> Unit,
    onOpen: (Playlist) -> Unit,
    state: LazyListState = rememberLazyListState(),
) {
    LazyColumn(Modifier.fillMaxSize(), state = state) {
        item {
            ListRow(
                title = tr("Nova playlist"),
                subtitle = tr("Crie e adicione músicas pelo menu ⋮ de cada faixa"),
                leading = {
                    Box(
                        Modifier.size(52.dp).background(Gold.copy(alpha = 0.15f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Add, null, tint = Gold) }
                },
                onClick = onCreate
            )
        }
        items(playlists, key = { it.id }) { p ->
            val first = p.trackIds.firstNotNullOfOrNull { byId[it] }
            val total = p.trackIds.sumOf { byId[it]?.durationMs ?: 0L }
            ListRow(
                title = p.name,
                subtitle = "${p.trackIds.size} ${if (p.trackIds.size == 1) tr("faixa") else tr("faixas")} · ${formatTime(total)}",
                leading = { ArtImage(first, Modifier.size(52.dp)) },
                onClick = { onOpen(p) }
            )
        }
    }
}

@Composable
private fun PlaylistDetail(
    playlist: Playlist,
    tracks: List<Track>,
    missing: Int,
    ui: PlayerUi,
    actions: TrackActions,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onRemove: (Int) -> Unit,
    onMove: (Int, Int) -> Unit,
    state: LazyListState = rememberLazyListState(),
) {
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    // Posição real na playlist (ignora faixas que sumiram do aparelho)
    val positions = remember(playlist, tracks) {
        val ids = playlist.trackIds
        tracks.map { t -> ids.indexOf(t.id) }
    }

    LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(bottom = 8.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtImage(tracks.firstOrNull(), Modifier.size(96.dp), corner = 8.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(playlist.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        trf("%1\$s faixas · %2\$s", tracks.size, formatTime(tracks.sumOf { it.durationMs })),
                        style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (missing > 0) {
                        Text(
                            trf("%1\$s não encontradas no aparelho", missing),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row {
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { renaming = true }) { Icon(Icons.Filled.Edit, tr("Renomear")) }
                        IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { deleting = true }) { Icon(Icons.Filled.Delete, tr("Excluir playlist")) }
                    }
                }
            }
            PlayShuffleRow(tracks, actions)
            if (tracks.isEmpty()) {
                Text(
                    tr("Playlist vazia. Use ⋮ › Adicionar à playlist em qualquer música."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
        itemsIndexed(tracks, key = { i, t -> "${i}-${t.id}" }) { i, t ->
            val pos = positions[i]
            TrackRow(
                t,
                isCurrent = ui.current?.id == t.id,
                actions = actions,
                showArt = false,
                leading = "${i + 1}",
                extraMenu = { close ->
                    if (pos > 0) DropdownMenuItem(text = { Text(tr("Mover para cima")) }, onClick = { close(); onMove(pos, pos - 1) })
                    if (pos in 0 until playlist.trackIds.size - 1)
                        DropdownMenuItem(text = { Text(tr("Mover para baixo")) }, onClick = { close(); onMove(pos, pos + 1) })
                    DropdownMenuItem(
                        text = { Text(tr("Remover da playlist")) },
                        leadingIcon = { Icon(Icons.Filled.Close, null) },
                        onClick = { close(); if (pos >= 0) onRemove(pos) }
                    )
                }
            ) { actions.play(tracks, i) }
        }
    }

    if (renaming) {
        NameDialog(tr("Renomear playlist"), playlist.name, tr("Salvar"),
            onConfirm = { onRename(it); renaming = false }, onDismiss = { renaming = false })
    }
    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text(trf("Excluir \"%1\$s\"?", playlist.name)) },
            text = { Text(tr("A playlist será apagada. As músicas continuam no aparelho.")) },
            confirmButton = { TextButton(onClick = { deleting = false; onDelete() }) { Text(tr("Excluir"), color = Gold) } },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text(tr("Cancelar")) } },
        )
    }
}

@Composable
private fun PlaylistPicker(
    playlists: List<Playlist>,
    count: Int,
    onPick: (Playlist) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var newName by remember { mutableStateOf<String?>(null) }
    if (newName != null) {
        NameDialog(tr("Nova playlist"), "", tr("Criar e adicionar"),
            onConfirm = { onCreate(it) }, onDismiss = { newName = null })
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (count == 1) tr("Adicionar à playlist") else trf("Adicionar %1\$s músicas", count)) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                item {
                    Row(
                        Modifier.fillMaxWidth().tvFocus().clickable { newName = "" }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Add, null, tint = Gold)
                        Spacer(Modifier.width(12.dp))
                        Text(tr("Nova playlist"), color = Gold, fontWeight = FontWeight.Medium)
                    }
                }
                items(playlists, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().tvFocus().clickable { onPick(p) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.AutoMirrored.Filled.QueueMusic, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(12.dp))
                        Text(p.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${p.trackIds.size}", style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Cancelar")) } },
    )
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text(tr("Nome da playlist")) },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Done
                ),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(confirm, color = Gold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancelar")) } },
    )
}

// ---- Álbum, artista e pasta ------------------------------------------------------------------

@Composable
private fun DetailView(group: Group, ui: PlayerUi, actions: TrackActions, state: LazyListState = rememberLazyListState()) {
    val isAlbum = group.key.startsWith("album:")
    LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(bottom = 8.dp)) {
        item {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                if (isAlbum) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ArtImage(group.tracks.first(), Modifier.size(120.dp), corner = 8.dp)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(group.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(group.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            val total = group.tracks.sumOf { it.durationMs }
                            Text(
                                trf("%1\$s faixas · %2\$s · %3\$s", group.tracks.size, formatTime(total), group.tracks.first().formatLabel),
                                style = TechStyle,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            TextButton(onClick = { actions.addToPlaylist(group.tracks) }, contentPadding = PaddingValues(0.dp)) {
                                Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null, tint = Gold)
                                Spacer(Modifier.width(6.dp))
                                Text(tr("Adicionar à playlist"), color = Gold)
                            }
                        }
                    }
                } else {
                    Text(group.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            PlayShuffleRow(group.tracks, actions)
        }
        itemsIndexed(group.tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(t, isCurrent = ui.current?.id == t.id, actions = actions, showArt = !isAlbum) {
                actions.play(group.tracks, i)
            }
        }
    }
}

@Composable
private fun MiniPlayer(ui: PlayerUi, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    val track = ui.current ?: return
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.navigationBarsPadding()) {
            val progress = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Gold,
                trackColor = MaterialTheme.colorScheme.outline,
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .tvFocus().clickable(onClick = onOpen)
                    .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(track, Modifier.size(44.dp), playing = ui.isPlaying)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        ui.quality.label().ifEmpty { track.artist } + (if (ui.eq.enabled) tr(" · EQ") else "") + (if (ui.widthOn) tr(" · Palco") else ""),
                        style = TechStyle,
                        color = if (ui.quality.isHiRes) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onToggle) {
                    Icon(if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, tr("Tocar ou pausar"))
                }
                IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onNext) { Icon(Icons.Filled.SkipNext, tr("Próxima")) }
            }
        }
    }
}

@Composable
internal fun QueueList(ui: PlayerUi, onJump: (Int) -> Unit, onRemove: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        itemsIndexed(ui.queue) { i, t ->
            val current = i == ui.index
            Row(
                Modifier
                    .fillMaxWidth()
                    .tvFocus().clickable { onJump(i) }
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(t, Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (current) Gold else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        t.artist, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                    )
                }
                if (!current) {
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { onRemove(i) }) {
                        Icon(Icons.Filled.Close, tr("Remover da fila"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Spacer(Modifier.width(48.dp))
                }
            }
        }
    }
}
