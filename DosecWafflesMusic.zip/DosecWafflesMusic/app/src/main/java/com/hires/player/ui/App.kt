package com.hires.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hires.player.Group
import com.hires.player.MusicRepository
import com.hires.player.PlayerUi
import com.hires.player.PlayerViewModel
import com.hires.player.Playlist
import com.hires.player.Track

private enum class LibTab(val label: String) {
    Songs("Músicas"), Favorites("Favoritas"), Playlists("Playlists"),
    Albums("Álbuns"), Artists("Artistas"), Folders("Pastas")
}

@Composable
fun HiResApp(vm: PlayerViewModel, hasPermission: Boolean, onRequestPermission: () -> Unit) {
    HiResTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!hasPermission) PermissionScreen(onRequestPermission) else Library(vm)
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Dosec Waffles Music", style = MaterialTheme.typography.headlineSmall, color = Gold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Para mostrar suas músicas, o app precisa de acesso aos arquivos de áudio do celular.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text("Permitir acesso às músicas") }
    }
}

/** Tudo o que uma linha de música pode fazer. */
class TrackActions(
    val play: (List<Track>, Int) -> Unit,
    val shuffle: (List<Track>) -> Unit,
    val playNext: (Track) -> Unit,
    val addToQueue: (Track) -> Unit,
    val isFavorite: (Long) -> Boolean,
    val toggleFavorite: (Track) -> Unit,
    val addToPlaylist: (List<Track>) -> Unit,
)

@Composable
private fun Library(vm: PlayerViewModel) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Group?>(null) }
    var openPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var nowPlaying by rememberSaveable { mutableStateOf(false) }
    var showEq by rememberSaveable { mutableStateOf(false) }
    var pickFor by remember { mutableStateOf<List<Track>?>(null) }
    var creatingPlaylist by remember { mutableStateOf(false) }

    val byId = remember(tracks) { tracks.associateBy { it.id } }
    val albums = remember(tracks) { MusicRepository.albums(tracks) }
    val artists = remember(tracks) { MusicRepository.artists(tracks) }
    val folders = remember(tracks) { MusicRepository.folders(tracks) }
    val favoriteTracks = remember(tracks, library.favorites) { library.favorites.mapNotNull { byId[it] } }
    val openPlaylist = library.playlists.firstOrNull { it.id == openPlaylistId }

    val inSub = detail != null || openPlaylist != null || searching
    fun goBack() {
        when {
            openPlaylist != null -> openPlaylistId = null
            detail != null -> detail = null
            else -> { searching = false; query = "" }
        }
    }
    BackHandler(enabled = !nowPlaying && !showEq && inSub) { goBack() }

    val actions = TrackActions(
        play = { list, i -> vm.playList(list, i) },
        shuffle = { list -> vm.playList(list, 0, shuffle = true) },
        playNext = vm::playNext,
        addToQueue = vm::addToQueue,
        isFavorite = { id -> id in library.favorites },
        toggleFavorite = vm::toggleFavorite,
        addToPlaylist = { pickFor = it },
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Cabeçalho
            Row(
                Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (inSub) {
                    IconButton(onClick = ::goBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                } else {
                    Spacer(Modifier.width(12.dp))
                }
                if (searching && detail == null && openPlaylist == null) {
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Buscar música, artista ou álbum") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                        ),
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Text(
                        openPlaylist?.name ?: detail?.title ?: "Biblioteca",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (!inSub) {
                        IconButton(onClick = { showEq = true }) {
                            Icon(
                                Icons.Filled.GraphicEq, "Equalizador",
                                tint = if (ui.eq.enabled) Gold else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Buscar") }
                    }
                }
            }

            Box(Modifier.weight(1f)) {
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Gold)
                    }
                    tracks.isEmpty() -> EmptyState(
                        "Nenhuma música encontrada",
                        "Copie seus arquivos FLAC, WAV ou MP3 para a pasta Music do celular e abra o app de novo."
                    )
                    openPlaylist != null -> PlaylistDetail(
                        playlist = openPlaylist,
                        tracks = openPlaylist.trackIds.mapNotNull { byId[it] },
                        missing = openPlaylist.trackIds.count { it !in byId },
                        ui = ui,
                        actions = actions,
                        onRename = { vm.renamePlaylist(openPlaylist.id, it) },
                        onDelete = { vm.deletePlaylist(openPlaylist.id); openPlaylistId = null },
                        onRemove = { i -> vm.removeFromPlaylist(openPlaylist.id, i) },
                        onMove = { from, to -> vm.movePlaylistTrack(openPlaylist.id, from, to) },
                    )
                    detail != null -> DetailView(detail!!, ui, actions)
                    searching -> {
                        val q = query.trim().lowercase()
                        val found = remember(q, tracks) {
                            if (q.isEmpty()) emptyList() else tracks.filter {
                                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                                    it.album.lowercase().contains(q)
                            }
                        }
                        TrackList(found, ui, actions, showHeader = false)
                    }
                    else -> Column {
                        ScrollableTabRow(
                            selectedTabIndex = tab,
                            containerColor = Color.Transparent,
                            contentColor = Gold,
                            edgePadding = 8.dp,
                        ) {
                            LibTab.entries.forEachIndexed { i, t ->
                                Tab(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    text = { Text(t.label, maxLines = 1) },
                                    unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        when (LibTab.entries[tab]) {
                            LibTab.Songs -> TrackList(tracks, ui, actions, showHeader = true)
                            LibTab.Favorites ->
                                if (favoriteTracks.isEmpty()) EmptyState(
                                    "Nenhuma favorita ainda",
                                    "Toque no coração na tela Tocando agora, ou em ⋮ › Favoritar em qualquer música."
                                ) else TrackList(favoriteTracks, ui, actions, showHeader = true)
                            LibTab.Playlists -> PlaylistList(
                                library.playlists, byId,
                                onCreate = { creatingPlaylist = true },
                                onOpen = { openPlaylistId = it.id },
                            )
                            LibTab.Albums -> AlbumGrid(albums) { detail = it }
                            LibTab.Artists -> GroupList(artists, Icons.Filled.Person) { detail = it }
                            LibTab.Folders -> GroupList(folders, Icons.Filled.Folder) { detail = it }
                        }
                    }
                }
            }

            if (ui.current != null) {
                MiniPlayer(ui, onOpen = { nowPlaying = true }, onToggle = vm::togglePlay, onNext = vm::next)
            } else {
                Spacer(Modifier.navigationBarsPadding())
            }
        }

        AnimatedVisibility(
            visible = nowPlaying && ui.current != null && !showEq,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlayingScreen(
                vm, ui,
                isFavorite = ui.current?.id?.let { it in library.favorites } == true,
                onAddToPlaylist = { t -> pickFor = listOf(t) },
                onOpenEq = { showEq = true },
                onClose = { nowPlaying = false },
            )
        }

        AnimatedVisibility(
            visible = showEq,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
        ) {
            EqualizerScreen(
                state = ui.eq,
                bitPerfectOn = ui.bitPerfectOn,
                onChange = vm::setEq,
                onClose = { showEq = false },
            )
        }
    }

    // Escolher playlist para adicionar
    pickFor?.let { toAdd ->
        PlaylistPicker(
            playlists = library.playlists,
            count = toAdd.size,
            onPick = { p -> vm.addToPlaylist(p.id, toAdd); pickFor = null },
            onCreate = { name -> val id = vm.createPlaylist(name); vm.addToPlaylist(id, toAdd); pickFor = null },
            onDismiss = { pickFor = null },
        )
    }
    if (creatingPlaylist) {
        NameDialog(
            title = "Nova playlist",
            initial = "",
            confirm = "Criar",
            onConfirm = { name -> openPlaylistId = vm.createPlaylist(name); creatingPlaylist = false },
            onDismiss = { creatingPlaylist = false },
        )
    }
}

@Composable
private fun EmptyState(title: String, body: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlayShuffleRow(tracks: List<Track>, actions: TrackActions) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(onClick = { actions.play(tracks, 0) }, modifier = Modifier.weight(1f), enabled = tracks.isNotEmpty()) {
            Icon(Icons.Filled.PlayArrow, null)
            Spacer(Modifier.width(6.dp))
            Text("Tocar")
        }
        OutlinedButton(
            onClick = { actions.shuffle(tracks) },
            modifier = Modifier.weight(1f),
            enabled = tracks.isNotEmpty(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
        ) {
            Icon(Icons.Filled.Shuffle, null)
            Spacer(Modifier.width(6.dp))
            Text("Aleatório")
        }
    }
}

@Composable
private fun TrackList(tracks: List<Track>, ui: PlayerUi, actions: TrackActions, showHeader: Boolean) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 8.dp)) {
        if (showHeader && tracks.isNotEmpty()) {
            item { PlayShuffleRow(tracks, actions) }
        }
        itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(t, isCurrent = ui.current?.id == t.id, actions = actions, showArt = true) {
                actions.play(tracks, i)
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    actions: TrackActions,
    showArt: Boolean,
    leading: String? = null,
    extraMenu: (@Composable (close: () -> Unit) -> Unit)? = null,
    onClick: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val fav = actions.isFavorite(track.id)
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showArt) {
            ArtImage(track, Modifier.size(48.dp))
        } else {
            Text(
                leading ?: if (track.trackNumber > 0) track.trackNumber.toString() else "–",
                style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(28.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) Gold else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                FormatTag(track)
                Spacer(Modifier.width(6.dp))
                if (fav) {
                    Icon(Icons.Filled.Favorite, "Favorita", tint = Gold, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    "${track.artist} · ${formatTime(track.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, "Opções", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Tocar a seguir") }, onClick = { menu = false; actions.playNext(track) })
                DropdownMenuItem(text = { Text("Adicionar à fila") }, onClick = { menu = false; actions.addToQueue(track) })
                DropdownMenuItem(
                    text = { Text(if (fav) "Remover dos favoritos" else "Favoritar") },
                    leadingIcon = {
                        Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                            tint = if (fav) Gold else MaterialTheme.colorScheme.onSurfaceVariant)
                    },
                    onClick = { menu = false; actions.toggleFavorite(track) }
                )
                DropdownMenuItem(
                    text = { Text("Adicionar à playlist…") },
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null) },
                    onClick = { menu = false; actions.addToPlaylist(listOf(track)) }
                )
                if (extraMenu != null) {
                    HorizontalDivider()
                    extraMenu { menu = false }
                }
            }
        }
    }
}

@Composable
private fun FormatTag(track: Track) {
    val lossless = track.isLossless
    Text(
        track.formatLabel,
        style = TechStyle.copy(fontSize = MaterialTheme.typography.labelSmall.fontSize),
        color = if (lossless) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .background(
                if (lossless) Gold.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(3.dp)
            )
            .padding(horizontal = 4.dp, vertical = 1.dp)
    )
}

@Composable
private fun AlbumGrid(albums: List<Group>, onOpen: (Group) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(albums, key = { it.key }) { album ->
            Column(Modifier.clickable { onOpen(album) }) {
                ArtImage(album.tracks.first(), Modifier.fillMaxWidth().aspectRatio(1f), corner = 8.dp)
                Spacer(Modifier.height(8.dp))
                Text(album.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    album.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun GroupList(groups: List<Group>, icon: ImageVector, onOpen: (Group) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(groups, key = { it.key }) { g ->
            ListRow(
                title = g.title,
                subtitle = g.subtitle,
                leading = {
                    Box(
                        Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(22.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                },
                onClick = { onOpen(g) }
            )
        }
    }
}

@Composable
private fun ListRow(title: String, subtitle: String, leading: @Composable () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---- Playlists -----------------------------------------------------------------------------

@Composable
private fun PlaylistList(
    playlists: List<Playlist>,
    byId: Map<Long, Track>,
    onCreate: () -> Unit,
    onOpen: (Playlist) -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ListRow(
                title = "Nova playlist",
                subtitle = "Crie e adicione músicas pelo menu ⋮ de cada faixa",
                leading = {
                    Box(
                        Modifier.size(52.dp).background(Gold.copy(alpha = 0.15f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Add, null, tint = Gold) }
                },
                onClick = onCreate
            )
        }
        items(playlists, key = { it.id }) { p ->
            val first = p.trackIds.firstNotNullOfOrNull { byId[it] }
            val total = p.trackIds.sumOf { byId[it]?.durationMs ?: 0L }
            ListRow(
                title = p.name,
                subtitle = "${p.trackIds.size} ${if (p.trackIds.size == 1) "faixa" else "faixas"} · ${formatTime(total)}",
                leading = { ArtImage(first, Modifier.size(52.dp)) },
                onClick = { onOpen(p) }
            )
        }
    }
}

@Composable
private fun PlaylistDetail(
    playlist: Playlist,
    tracks: List<Track>,
    missing: Int,
    ui: PlayerUi,
    actions: TrackActions,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onRemove: (Int) -> Unit,
    onMove: (Int, Int) -> Unit,
) {
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    // Posição real na playlist (ignora faixas que sumiram do aparelho)
    val positions = remember(playlist, tracks) {
        val ids = playlist.trackIds
        tracks.map { t -> ids.indexOf(t.id) }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 8.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtImage(tracks.firstOrNull(), Modifier.size(96.dp), corner = 8.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(playlist.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${tracks.size} faixas · ${formatTime(tracks.sumOf { it.durationMs })}",
                        style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (missing > 0) {
                        Text(
                            "$missing não encontradas no aparelho",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row {
                        IconButton(onClick = { renaming = true }) { Icon(Icons.Filled.Edit, "Renomear") }
                        IconButton(onClick = { deleting = true }) { Icon(Icons.Filled.Delete, "Excluir playlist") }
                    }
                }
            }
            PlayShuffleRow(tracks, actions)
            if (tracks.isEmpty()) {
                Text(
                    "Playlist vazia. Use ⋮ › Adicionar à playlist em qualquer música.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
        itemsIndexed(tracks, key = { i, t -> "$i-${t.id}" }) { i, t ->
            val pos = positions[i]
            TrackRow(
                t,
                isCurrent = ui.current?.id == t.id,
                actions = actions,
                showArt = false,
                leading = "${i + 1}",
                extraMenu = { close ->
                    if (pos > 0) DropdownMenuItem(text = { Text("Mover para cima") }, onClick = { close(); onMove(pos, pos - 1) })
                    if (pos in 0 until playlist.trackIds.size - 1)
                        DropdownMenuItem(text = { Text("Mover para baixo") }, onClick = { close(); onMove(pos, pos + 1) })
                    DropdownMenuItem(
                        text = { Text("Remover da playlist") },
                        leadingIcon = { Icon(Icons.Filled.Close, null) },
                        onClick = { close(); if (pos >= 0) onRemove(pos) }
                    )
                }
            ) { actions.play(tracks, i) }
        }
    }

    if (renaming) {
        NameDialog("Renomear playlist", playlist.name, "Salvar",
            onConfirm = { onRename(it); renaming = false }, onDismiss = { renaming = false })
    }
    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Excluir \"${playlist.name}\"?") },
            text = { Text("A playlist será apagada. As músicas continuam no aparelho.") },
            confirmButton = { TextButton(onClick = { deleting = false; onDelete() }) { Text("Excluir", color = Gold) } },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun PlaylistPicker(
    playlists: List<Playlist>,
    count: Int,
    onPick: (Playlist) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var newName by remember { mutableStateOf<String?>(null) }
    if (newName != null) {
        NameDialog("Nova playlist", "", "Criar e adicionar",
            onConfirm = { onCreate(it) }, onDismiss = { newName = null })
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (count == 1) "Adicionar à playlist" else "Adicionar $count músicas") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { newName = "" }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Add, null, tint = Gold)
                        Spacer(Modifier.width(12.dp))
                        Text("Nova playlist", color = Gold, fontWeight = FontWeight.Medium)
                    }
                }
                items(playlists, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.AutoMirrored.Filled.QueueMusic, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(12.dp))
                        Text(p.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${p.trackIds.size}", style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Nome da playlist") },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Done
                ),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(confirm, color = Gold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ---- Álbum, artista e pasta ------------------------------------------------------------------

@Composable
private fun DetailView(group: Group, ui: PlayerUi, actions: TrackActions) {
    val isAlbum = group.key.startsWith("album:")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 8.dp)) {
        item {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                if (isAlbum) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ArtImage(group.tracks.first(), Modifier.size(120.dp), corner = 8.dp)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(group.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(group.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            val total = group.tracks.sumOf { it.durationMs }
                            Text(
                                "${group.tracks.size} faixas · ${formatTime(total)} · ${group.tracks.first().formatLabel}",
                                style = TechStyle,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            TextButton(onClick = { actions.addToPlaylist(group.tracks) }, contentPadding = PaddingValues(0.dp)) {
                                Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null, tint = Gold)
                                Spacer(Modifier.width(6.dp))
                                Text("Adicionar à playlist", color = Gold)
                            }
                        }
                    }
                } else {
                    Text(group.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            PlayShuffleRow(group.tracks, actions)
        }
        itemsIndexed(group.tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(t, isCurrent = ui.current?.id == t.id, actions = actions, showArt = !isAlbum) {
                actions.play(group.tracks, i)
            }
        }
    }
}

@Composable
private fun MiniPlayer(ui: PlayerUi, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    val track = ui.current ?: return
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.navigationBarsPadding()) {
            val progress = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Gold,
                trackColor = MaterialTheme.colorScheme.outline,
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpen)
                    .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(track, Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        ui.quality.label().ifEmpty { track.artist } + if (ui.eq.enabled) " · EQ" else "",
                        style = TechStyle,
                        color = if (ui.quality.isHiRes) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onToggle) {
                    Icon(if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Tocar ou pausar")
                }
                IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, "Próxima") }
            }
        }
    }
}

@Composable
internal fun QueueList(ui: PlayerUi, onJump: (Int) -> Unit, onRemove: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        itemsIndexed(ui.queue) { i, t ->
            val current = i == ui.index
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onJump(i) }
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(t, Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (current) Gold else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        t.artist, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                    )
                }
                if (!current) {
                    IconButton(onClick = { onRemove(i) }) {
                        Icon(Icons.Filled.Close, "Remover da fila", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Spacer(Modifier.width(48.dp))
                }
            }
        }
    }
}
