package com.hires.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hires.player.Group
import com.hires.player.MusicRepository
import com.hires.player.PlayerUi
import com.hires.player.PlayerViewModel
import com.hires.player.Track

private enum class LibTab(val label: String) { Songs("Músicas"), Albums("Álbuns"), Artists("Artistas"), Folders("Pastas") }

@Composable
fun HiResApp(vm: PlayerViewModel, hasPermission: Boolean, onRequestPermission: () -> Unit) {
    HiResTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!hasPermission) {
                PermissionScreen(onRequestPermission)
            } else {
                Library(vm)
            }
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Dosec Waffles Music", style = MaterialTheme.typography.headlineSmall, color = Gold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Para mostrar suas músicas, o app precisa de acesso aos arquivos de áudio do celular.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text("Permitir acesso às músicas") }
    }
}

@Composable
private fun Library(vm: PlayerViewModel) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Group?>(null) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var nowPlaying by rememberSaveable { mutableStateOf(false) }

    val albums = remember(tracks) { MusicRepository.albums(tracks) }
    val artists = remember(tracks) { MusicRepository.artists(tracks) }
    val folders = remember(tracks) { MusicRepository.folders(tracks) }

    BackHandler(enabled = !nowPlaying && (detail != null || searching)) {
        if (detail != null) detail = null else { searching = false; query = "" }
    }

    val actions = TrackActions(
        play = { list, i -> vm.playList(list, i) },
        shuffle = { list -> vm.playList(list, 0, shuffle = true) },
        playNext = vm::playNext,
        addToQueue = vm::addToQueue,
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Cabeçalho
            Row(
                Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (detail != null || searching) {
                    IconButton(onClick = {
                        if (detail != null) detail = null else { searching = false; query = "" }
                    }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                } else {
                    Spacer(Modifier.width(12.dp))
                }
                if (searching && detail == null) {
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Buscar música, artista ou álbum") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                        ),
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Text(
                        detail?.title ?: "Biblioteca",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (detail == null) {
                        IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Buscar") }
                    }
                }
            }

            Box(Modifier.weight(1f)) {
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Gold)
                    }
                    tracks.isEmpty() -> EmptyLibrary()
                    detail != null -> DetailView(detail!!, ui, actions)
                    searching -> {
                        val q = query.trim().lowercase()
                        val found = remember(q, tracks) {
                            if (q.isEmpty()) emptyList() else tracks.filter {
                                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                                    it.album.lowercase().contains(q)
                            }
                        }
                        TrackList(found, ui, actions, showHeader = false)
                    }
                    else -> Column {
                        TabRow(
                            selectedTabIndex = tab,
                            containerColor = Color.Transparent,
                            contentColor = Gold,
                        ) {
                            LibTab.entries.forEachIndexed { i, t ->
                                Tab(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    text = { Text(t.label, maxLines = 1) },
                                    unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        when (LibTab.entries[tab]) {
                            LibTab.Songs -> TrackList(tracks, ui, actions, showHeader = true)
                            LibTab.Albums -> AlbumGrid(albums) { detail = it }
                            LibTab.Artists -> GroupList(artists, Icons.Filled.Person) { detail = it }
                            LibTab.Folders -> GroupList(folders, Icons.Filled.Folder) { detail = it }
                        }
                    }
                }
            }

            if (ui.current != null) {
                MiniPlayer(ui, onOpen = { nowPlaying = true }, onToggle = vm::togglePlay, onNext = vm::next)
            } else {
                Spacer(Modifier.navigationBarsPadding())
            }
        }

        AnimatedVisibility(
            visible = nowPlaying && ui.current != null,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlayingScreen(vm, ui, onClose = { nowPlaying = false })
        }
    }
}

class TrackActions(
    val play: (List<Track>, Int) -> Unit,
    val shuffle: (List<Track>) -> Unit,
    val playNext: (Track) -> Unit,
    val addToQueue: (Track) -> Unit,
)

@Composable
private fun EmptyLibrary() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Nenhuma música encontrada", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Copie seus arquivos FLAC, WAV ou MP3 para a pasta Music do celular e abra o app de novo.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun PlayShuffleRow(tracks: List<Track>, actions: TrackActions) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(onClick = { actions.play(tracks, 0) }, modifier = Modifier.weight(1f)) {
            Icon(Icons.Filled.PlayArrow, null)
            Spacer(Modifier.width(6.dp))
            Text("Tocar")
        }
        OutlinedButton(
            onClick = { actions.shuffle(tracks) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
        ) {
            Icon(Icons.Filled.Shuffle, null)
            Spacer(Modifier.width(6.dp))
            Text("Aleatório")
        }
    }
}

@Composable
private fun TrackList(tracks: List<Track>, ui: PlayerUi, actions: TrackActions, showHeader: Boolean) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 8.dp)) {
        if (showHeader && tracks.isNotEmpty()) {
            item { PlayShuffleRow(tracks, actions) }
        }
        itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(t, isCurrent = ui.current?.id == t.id, actions = actions, showArt = true) {
                actions.play(tracks, i)
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    actions: TrackActions,
    showArt: Boolean,
    onClick: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showArt) {
            ArtImage(track, Modifier.size(48.dp))
        } else {
            Text(
                if (track.trackNumber > 0) track.trackNumber.toString() else "–",
                style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(28.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) Gold else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                FormatTag(track)
                Spacer(Modifier.width(6.dp))
                Text(
                    "${track.artist} · ${formatTime(track.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, "Opções", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Tocar a seguir") }, onClick = { menu = false; actions.playNext(track) })
                DropdownMenuItem(text = { Text("Adicionar à fila") }, onClick = { menu = false; actions.addToQueue(track) })
            }
        }
    }
}

@Composable
private fun FormatTag(track: Track) {
    val lossless = track.isLossless
    Text(
        track.formatLabel,
        style = TechStyle.copy(fontSize = MaterialTheme.typography.labelSmall.fontSize),
        color = if (lossless) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .background(
                if (lossless) Gold.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(3.dp)
            )
            .padding(horizontal = 4.dp, vertical = 1.dp)
    )
}

@Composable
private fun AlbumGrid(albums: List<Group>, onOpen: (Group) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(albums, key = { it.key }) { album ->
            Column(Modifier.clickable { onOpen(album) }) {
                ArtImage(album.tracks.first(), Modifier.fillMaxWidth().aspectRatio(1f), corner = 8.dp)
                Spacer(Modifier.height(8.dp))
                Text(album.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    album.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun GroupList(groups: List<Group>, icon: ImageVector, onOpen: (Group) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(groups, key = { it.key }) { g ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(g) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(g.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        g.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun DetailView(group: Group, ui: PlayerUi, actions: TrackActions) {
    val isAlbum = group.key.startsWith("album:")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 8.dp)) {
        item {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                if (isAlbum) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ArtImage(group.tracks.first(), Modifier.size(120.dp), corner = 8.dp)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(group.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(group.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            val total = group.tracks.sumOf { it.durationMs }
                            Text(
                                "${group.tracks.size} faixas · ${formatTime(total)} · ${group.tracks.first().formatLabel}",
                                style = TechStyle,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    Text(group.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            PlayShuffleRow(group.tracks, actions)
        }
        itemsIndexed(group.tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(t, isCurrent = ui.current?.id == t.id, actions = actions, showArt = !isAlbum) {
                actions.play(group.tracks, i)
            }
        }
    }
}

@Composable
private fun MiniPlayer(ui: PlayerUi, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    val track = ui.current ?: return
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.navigationBarsPadding()) {
            val progress = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Gold,
                trackColor = MaterialTheme.colorScheme.outline,
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpen)
                    .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(track, Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        ui.quality.label().ifEmpty { track.artist },
                        style = TechStyle,
                        color = if (ui.quality.isHiRes) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onToggle) {
                    Icon(if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Tocar ou pausar")
                }
                IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, "Próxima") }
            }
        }
    }
}

@Composable
internal fun QueueList(ui: PlayerUi, onJump: (Int) -> Unit, onRemove: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        itemsIndexed(ui.queue) { i, t ->
            val current = i == ui.index
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onJump(i) }
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(t, Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (current) Gold else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        t.artist, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                    )
                }
                if (!current) {
                    IconButton(onClick = { onRemove(i) }) {
                        Icon(Icons.Filled.Close, "Remover da fila", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Spacer(Modifier.width(48.dp))
                }
            }
        }
    }
}
