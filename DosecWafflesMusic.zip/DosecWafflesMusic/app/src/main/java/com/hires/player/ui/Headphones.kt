package com.hires.player.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hires.player.EqState
import com.hires.player.HeadphoneEntry
import com.hires.player.HeadphoneEq
import com.hires.player.SavedHeadphone
import com.hires.player.tr
import com.hires.player.trf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * "Meu fone": correções do AutoEQ salvas no aparelho e a busca "Procurar meu fone".
 * Escolher um fone aplica a correção no equalizador (e liga o equalizador).
 */
@Composable
fun HeadphoneCard(state: EqState, onChange: (EqState) -> Unit) {
    val ctx = LocalContext.current
    var saved by remember { mutableStateOf(HeadphoneEq.saved(ctx)) }
    var searching by remember { mutableStateOf(false) }

    fun apply(h: SavedHeadphone) {
        onChange(state.copy(gains = h.gains.copyOf(), preamp = h.preamp, preset = h.presetName, enabled = true))
    }

    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .border(
                1.dp,
                if (saved.any { it.presetName == state.preset } && state.enabled) Gold else MaterialTheme.colorScheme.outline,
                RoundedCornerShape(10.dp)
            )
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Headphones, null, tint = Gold, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(tr("MEU FONE · CORREÇÃO AUTOEQ"), style = TechStyle, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            tr("Corrige o som do seu modelo de fone com base em medições de laboratório, para ele soar neutro e equilibrado."),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (saved.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(saved, key = { it.name }) { h ->
                    FilterChip(
                        selected = state.enabled && state.preset == h.presetName,
                        onClick = { apply(h) },
                        label = { Text(h.name, maxLines = 1) },
                        trailingIcon = {
                            Icon(
                                Icons.Filled.Close, tr("Remover"),
                                modifier = Modifier.size(16.dp).clickable {
                                    HeadphoneEq.remove(ctx, h.name)
                                    saved = HeadphoneEq.saved(ctx)
                                }
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        modifier = Modifier.tvFocus(RoundedCornerShape(8.dp))
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { searching = true }, modifier = Modifier.tvFocus()) {
            Icon(Icons.Filled.Search, null)
            Spacer(Modifier.width(6.dp))
            Text(tr("Procurar meu fone"))
        }
    }

    if (searching) {
        HeadphoneSearchDialog(
            onPicked = { h ->
                saved = HeadphoneEq.saved(ctx)
                apply(h)
                searching = false
            },
            onDismiss = { searching = false },
        )
    }
}

@Composable
private fun HeadphoneSearchDialog(onPicked: (SavedHeadphone) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<HeadphoneEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var downloading by remember { mutableStateOf<String?>(null) }

    // Busca enquanto digita (com uma pequena pausa)
    LaunchedEffect(query) {
        if (query.trim().length < 2) { results = emptyList(); error = null; return@LaunchedEffect }
        delay(300)
        loading = true
        val r = withContext(Dispatchers.IO) { runCatching { HeadphoneEq.search(ctx, query) } }
        loading = false
        r.onSuccess { results = it; error = null }
            .onFailure { error = tr("Sem internet. A lista de fones é baixada na primeira busca e depois fica salva no aparelho.") }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Procurar meu fone")) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(tr("Marca e modelo, ex.: Sony WH-1000XM4")) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                when {
                    downloading != null -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Gold)
                        Spacer(Modifier.width(10.dp))
                        Text(trf("Baixando a correção de %1\$s…", downloading!!))
                    }
                    loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Gold)
                        Spacer(Modifier.width(10.dp))
                        Text(tr("Procurando…"))
                    }
                    error != null -> Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    query.trim().length >= 2 && results.isEmpty() ->
                        Text(tr("Nenhum fone com esse nome. Tente só o modelo (ex.: ZSN Pro)."), style = MaterialTheme.typography.bodySmall)
                }
                if (results.isNotEmpty() && downloading == null) {
                    LazyColumn(Modifier.heightIn(max = 340.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                        items(results, key = { it.path }) { e ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .tvFocus()
                                    .clickable {
                                        downloading = e.name
                                        scope.launch {
                                            val r = withContext(Dispatchers.IO) { runCatching { HeadphoneEq.download(ctx, e) } }
                                            downloading = null
                                            r.onSuccess(onPicked).onFailure {
                                                error = tr("Não foi possível baixar a correção. Confira a internet e tente de novo.")
                                            }
                                        }
                                    }
                                    .padding(vertical = 8.dp)
                            ) {
                                Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(
                                    kindLabel(e.kind),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            HorizontalDivider()
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    tr("Correções baseadas em medições de laboratório (projeto AutoEQ)."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fechar")) } },
    )
}

private fun kindLabel(kind: String) = when (kind) {
    "in-ear" -> tr("Intra-auricular")
    "earbud" -> tr("Earbud")
    else -> tr("Fone grande (headphone)")
}
