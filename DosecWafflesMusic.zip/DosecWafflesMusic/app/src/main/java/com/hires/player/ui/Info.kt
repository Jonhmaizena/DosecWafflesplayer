package com.hires.player.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hires.player.AlbumInfo
import com.hires.player.ArtistInfo
import com.hires.player.InfoDownloader
import com.hires.player.Lookup
import com.hires.player.OnlineInfo
import com.hires.player.SongInfo
import com.hires.player.Track
import com.hires.player.tr
import com.hires.player.trf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * "Sobre": artista, álbum e música, com dados da internet (MusicBrainz, Wikipedia, LRCLIB)
 * que ficam salvos no aparelho para uso offline.
 */
@Composable
fun InfoScreen(track: Track, library: List<Track>, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    var online by remember { mutableStateOf(OnlineInfo.enabled(ctx)) }
    var reload by remember { mutableIntStateOf(0) }
    var artist by remember(track.id) { mutableStateOf<Lookup<ArtistInfo>?>(null) }
    var album by remember(track.id) { mutableStateOf<Lookup<AlbumInfo>?>(null) }
    var song by remember(track.id) { mutableStateOf<Lookup<SongInfo>?>(null) }
    val lang = com.hires.player.L.lang

    LaunchedEffect(track.id, reload, online, lang) {
        artist = null; album = null; song = null
        withContext(Dispatchers.IO) {
            coroutineScope {
                val a = async { OnlineInfo.artist(ctx, track.artist, online) }
                val b = async { OnlineInfo.album(ctx, track.artist, track.album, online) }
                val c = async {
                    // A letra é buscada junto, para ficar salva offline
                    OnlineInfo.lyrics(ctx, track, online)
                    OnlineInfo.song(ctx, track, online)
                }
                artist = a.await()
                album = b.await()
                song = c.await()
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Voltar"))
                }
                Column(Modifier.weight(1f)) {
                    Text(tr("Sobre a música"), style = MaterialTheme.typography.titleLarge)
                    Text(
                        "${track.title} · ${track.artist}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (online) {
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { reload++ }) {
                        Icon(Icons.Filled.Refresh, tr("Atualizar"))
                    }
                }
            }

            Column(
                Modifier.align(Alignment.CenterHorizontally).widthIn(max = 760.dp).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ArtistCard(track.artist, artist)
                AlbumCard(track, album)
                SongCard(track, song)
                OfflineCard(library, online) { on ->
                    OnlineInfo.setEnabled(ctx, on)
                    online = on
                }
            }
        }
    }
}

@Composable
private fun InfoCard(icon: ImageVector, heading: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(heading, style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun <T> LookupState(result: Lookup<T>?, found: @Composable (T) -> Unit) {
    when (result) {
        null -> Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Gold)
            Spacer(Modifier.width(10.dp))
            Text(tr("Buscando informações…"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        is Lookup.Found -> {
            found(result.value)
            if (result.fromCache) {
                Spacer(Modifier.height(6.dp))
                Text(tr("Salvo no aparelho · funciona offline"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Lookup.NotFound -> Text(tr("Nada encontrado nas bases de música para este nome."), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Lookup.Offline -> Text(tr("Sem internet e sem informações salvas ainda."), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Genres(genres: List<String>) {
    if (genres.isEmpty()) return
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        genres.forEach { g ->
            Text(
                g,
                style = MaterialTheme.typography.labelMedium,
                color = Gold,
                modifier = Modifier
                    .background(Gold.copy(alpha = 0.12f), RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun Fact(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.padding(vertical = 2.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(130.dp))
        Text(value, modifier = Modifier.weight(1f))
    }
}

/** Texto longo que abre e fecha ao tocar. */
@Composable
private fun LongText(text: String, link: String) {
    if (text.isBlank()) return
    var open by remember(text) { mutableStateOf(false) }
    val ctx = LocalContext.current
    Spacer(Modifier.height(8.dp))
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        maxLines = if (open) Int.MAX_VALUE else 6,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.tvFocus().clickable { open = !open }
    )
    Row {
        if (!open) TextButton(onClick = { open = true }) { Text(tr("Ler mais"), color = Gold) }
        if (link.isNotBlank()) {
            TextButton(onClick = {
                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }) { Text(tr("Wikipedia"), color = Gold) }
        }
    }
}

private fun typeLabel(type: String) = when (type.lowercase()) {
    "person" -> tr("Artista solo")
    "group" -> tr("Banda ou grupo")
    "orchestra" -> tr("Orquestra")
    "choir" -> tr("Coral")
    "album" -> tr("Álbum")
    "single" -> tr("Single")
    "ep" -> "EP"
    "" -> ""
    else -> type
}

@Composable
private fun ArtistCard(name: String, result: Lookup<ArtistInfo>?) {
    InfoCard(Icons.Filled.Person, tr("ARTISTA")) {
        LookupState(result) { a ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                val photo = remember(a.imagePath) {
                    a.imagePath.takeIf { it.isNotBlank() }?.let { p -> runCatching { BitmapFactory.decodeFile(p)?.asImageBitmap() }.getOrNull() }
                }
                if (photo != null) {
                    Image(photo, a.name, contentScale = ContentScale.Crop, modifier = Modifier.size(84.dp).clip(CircleShape))
                    Spacer(Modifier.width(14.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(a.name.ifBlank { name }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    val years = when {
                        a.begin.isNotBlank() && a.end.isNotBlank() -> "${a.begin.take(4)}–${a.end.take(4)}"
                        a.begin.isNotBlank() -> trf("desde %1\$s", a.begin.take(4))
                        else -> ""
                    }
                    Text(
                        listOf(typeLabel(a.type), a.country, years).filter { it.isNotBlank() }.joinToString(" · "),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Genres(a.genres)
            LongText(a.bio, a.wikiUrl)
        }
    }
}

@Composable
private fun AlbumCard(track: Track, result: Lookup<AlbumInfo>?) {
    InfoCard(Icons.Filled.Album, tr("ÁLBUM")) {
        LookupState(result) { a ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                ArtImage(track, Modifier.size(84.dp), corner = 8.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(a.artist, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
            Fact(tr("Lançamento"), a.date)
            Fact(tr("Tipo"), typeLabel(a.type))
            Fact(tr("Gravadora"), a.label)
            Fact(tr("Faixas"), if (a.trackCount > 0) a.trackCount.toString() else "")
            Spacer(Modifier.height(6.dp))
            Genres(a.genres)
            LongText(a.description, a.wikiUrl)
        }
    }
}

@Composable
private fun SongCard(track: Track, result: Lookup<SongInfo>?) {
    InfoCard(Icons.Filled.MusicNote, tr("MÚSICA")) {
        LookupState(result) { s ->
            Text(s.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(s.artist, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Fact(tr("Primeiro lançamento"), s.firstRelease)
            Fact(tr("Duração"), if (s.lengthMs > 0) formatTime(s.lengthMs) else "")
            Fact("ISRC", s.isrc)
            Fact(tr("Letra"), if (s.hasLyrics) tr("Salva no aparelho (LRCLIB)") else "")
            Spacer(Modifier.height(6.dp))
            Genres(s.genres)
        }
    }
}

@Composable
private fun OfflineCard(library: List<Track>, online: Boolean, onOnline: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val p by InfoDownloader.progress.collectAsStateWithLifecycle()
    Column(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Buscar informações na internet"), fontWeight = FontWeight.Medium)
                Text(
                    tr("Envia só o nome do artista, do álbum e da música para MusicBrainz, Wikipedia e LRCLIB."),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = online,
                onCheckedChange = onOnline,
                colors = SwitchDefaults.colors(checkedTrackColor = Gold),
                modifier = Modifier.tvFocus(RoundedCornerShape(50))
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(tr("USO OFFLINE"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(
            tr("O que você abre aqui fica salvo no aparelho. Para ter tudo offline, baixe as informações e as letras da biblioteca inteira de uma vez."),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        if (p.running) {
            LinearProgressIndicator(
                progress = { if (p.total > 0) p.done.toFloat() / p.total else 0f },
                color = Gold,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text(
                trf("Baixando %1\$s de %2\$s · %3\$s", p.done, p.total, p.current),
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            OutlinedButton(onClick = { InfoDownloader.cancel() }, modifier = Modifier.tvFocus()) { Text(tr("Parar")) }
        } else {
            if (p.total > 0 && p.done >= p.total) {
                Text(tr("Biblioteca baixada. As informações funcionam sem internet."), style = MaterialTheme.typography.bodySmall, color = Gold)
                Spacer(Modifier.height(6.dp))
            }
            Button(
                onClick = { InfoDownloader.start(ctx, library) },
                enabled = online && library.isNotEmpty(),
                modifier = Modifier.tvFocus()
            ) { Text(trf("Baixar dados de toda a biblioteca (%1\$s músicas)", library.size)) }
            Text(
                tr("Pode levar alguns minutos: o MusicBrainz aceita uma consulta por segundo."),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}
