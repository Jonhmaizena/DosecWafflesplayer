package com.hires.player

import android.content.Context
import android.graphics.Bitmap
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Resultado da análise de um arquivo. */
data class SpectrumReport(
    val spectrogram: Bitmap,
    val sampleRate: Int,
    val channels: Int,
    val codec: String,
    val declaredBits: Int,
    val effectiveBits: Int,        // 0 = não deu para verificar
    val cutoffHz: Int,
    val abruptCutoff: Boolean,
    val verdict: Verdict,
    val title: String,
    val details: List<String>,
    val analyzedSeconds: Int,
) {
    enum class Verdict { AUTHENTIC, SUSPECT, FAKE, LOSSY, INCONCLUSIVE }
}

/**
 * Analisador de espectro: decodifica o arquivo, calcula a FFT e procura as marcas que
 * arquivos "mentirosos" deixam.
 *
 * - Corte abrupto em ~16, ~19 ou ~20 kHz: sinal de MP3/AAC convertido para FLAC/WAV.
 * - Arquivo de 88,2/96/192 kHz sem nada acima de ~22 kHz: Hi-Res falso (CD convertido).
 * - Arquivo de 24 bits cujas amostras só usam 16 bits: 24-bit falso.
 *
 * É uma análise técnica indicativa: gravações antigas ou masterizações com poucos
 * agudos também podem ter corte baixo, por isso o app só aponta "falso" quando o
 * corte é abrupto, como os codificadores com perdas fazem.
 */
object SpectrumAnalyzer {

    private const val FFT_SIZE = 4096
    private const val COLUMNS = 480
    private const val ROWS = 256
    private const val MAX_SECONDS = 300   // analisa até 5 minutos
    private const val BIT_CHECK_SAMPLES = 4_000_000

    fun analyze(context: Context, uri: Uri, knownBits: Int, onProgress: (Float) -> Unit): SpectrumReport {
        // Profundidade de bits declarada no arquivo (o que o arquivo "diz" ter)
        val declaredBits = if (knownBits > 0) knownBits else readDeclaredBits(context, uri)
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        val trackIndex = (0 until extractor.trackCount).firstOrNull {
            extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
        } ?: error("O arquivo não tem áudio")
        extractor.selectTrack(trackIndex)
        val format = extractor.getTrackFormat(trackIndex)
        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
        val analyzeSeconds = if (durationUs > 0) min(MAX_SECONDS.toLong(), durationUs / 1_000_000).toInt().coerceAtLeast(1) else MAX_SECONDS

        // Pede saída em float para conseguir enxergar os bits reais (24-bit)
        format.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_FLOAT)
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val fft = Fft(FFT_SIZE)
        val window = FloatArray(FFT_SIZE) { (0.5 - 0.5 * cos(2 * PI * it / (FFT_SIZE - 1))).toFloat() }
        val frame = FloatArray(FFT_SIZE)
        var filled = 0
        val bins = FFT_SIZE / 2
        val avgPower = DoubleArray(bins)
        var frames = 0

        val expectedFrames = max(1, (analyzeSeconds.toLong() * sampleRate / FFT_SIZE).toInt())
        val framesPerColumn = max(1, expectedFrames / COLUMNS)
        val columns = ArrayList<FloatArray>()
        var column = FloatArray(ROWS)
        var inColumn = 0

        var outEncoding = AudioFormat.ENCODING_PCM_16BIT
        var checked = 0L
        var beyond16 = 0L
        var peak = 0f
        val maxSamples = analyzeSeconds.toLong() * sampleRate
        var monoSamples = 0L
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var done = false

        fun pushMono(v: Float) {
            frame[filled++] = v
            if (filled == FFT_SIZE) {
                filled = 0
                val power = fft.powerSpectrum(frame, window)
                for (b in 0 until bins) avgPower[b] += power[b]
                frames++
                // coluna do espectrograma: o máximo de cada faixa de frequência no período
                val perRow = bins / ROWS
                for (r in 0 until ROWS) {
                    var m = 0f
                    for (k in r * perRow until (r + 1) * perRow) if (power[k] > m) m = power[k]
                    if (m > column[r]) column[r] = m
                }
                if (++inColumn >= framesPerColumn) {
                    columns += column; column = FloatArray(ROWS); inColumn = 0
                }
                onProgress((frames.toFloat() / expectedFrames).coerceAtMost(1f))
            }
        }

        try {
            while (!done) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0 || monoSamples >= maxSamples) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) outEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    outIdx >= 0 -> {
                        val out = codec.getOutputBuffer(outIdx)!!.order(ByteOrder.nativeOrder())
                        out.position(info.offset); out.limit(info.offset + info.size)
                        if (outEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val fb = out.asFloatBuffer()
                            val total = fb.remaining()
                            var i = 0
                            while (i + channels <= total && monoSamples < maxSamples) {
                                var sum = 0f
                                for (c in 0 until channels) {
                                    val v = fb.get(i + c)
                                    sum += v
                                    val a = abs(v); if (a > peak) peak = a
                                    if (checked < BIT_CHECK_SAMPLES && v != 0f) {
                                        checked++
                                        val s = v * 32768f
                                        if (abs(s - s.roundToInt()) > 1e-3f) beyond16++
                                    }
                                }
                                pushMono(sum / channels); monoSamples++
                                i += channels
                            }
                        } else {
                            val sb = out.asShortBuffer()
                            val total = sb.remaining()
                            var i = 0
                            while (i + channels <= total && monoSamples < maxSamples) {
                                var sum = 0f
                                for (c in 0 until channels) {
                                    val v = sb.get(i + c) / 32768f
                                    sum += v
                                    val a = abs(v); if (a > peak) peak = a
                                }
                                pushMono(sum / channels); monoSamples++
                                i += channels
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) done = true
                    }
                }
            }
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            runCatching { extractor.release() }
        }
        if (inColumn > 0) columns += column
        if (frames == 0) error("Não foi possível decodificar o áudio")

        // ---- Espectro médio e corte -------------------------------------------------
        val nyquist = sampleRate / 2.0
        val hzPerBin = nyquist / bins
        val db = DoubleArray(bins) { 10 * log10(avgPower[it] / frames + 1e-20) }
        val smooth = DoubleArray(bins) { b ->
            var s = 0.0; var n = 0
            for (k in max(0, b - 6)..min(bins - 1, b + 6)) { s += db[k]; n++ }
            s / n
        }
        val from1k = (1000 / hzPerBin).toInt().coerceAtMost(bins - 1)
        val refBand = smooth.copyOfRange(from1k, min(bins, (5000 / hzPerBin).toInt() + 1)).sorted()
        val reference = refBand[refBand.size / 2]
        val dynamic = reference - smooth.copyOfRange(from1k, bins).minOrNull()!!

        // Procura, acima de 10 kHz, o ponto onde o espectro despenca mais rápido.
        // Codificadores com perdas e conversões de taxa deixam uma "parede" de 40–60 dB
        // em menos de 1,2 kHz; gravações naturais perdem agudos aos poucos.
        val span = (600 / hzPerBin).toInt().coerceAtLeast(2)
        val searchFrom = (10_000 / hzPerBin).toInt().coerceAtLeast(span)
        var bestBin = -1
        var bestDrop = 0.0
        for (b in searchFrom until bins - span - 1) {
            val drop = smooth[b - span] - smooth[b + span]
            if (drop > bestDrop) { bestDrop = drop; bestBin = b }
        }
        val abrupt = bestDrop > 20.0 && bestBin > 0
        // Sem parede: o conteúdo vai até o limite do arquivo
        val cutoffBin = if (abrupt) bestBin else bins - 1
        val cutoffHz = (cutoffBin * hzPerBin).toInt()
        val dropDb = bestDrop

        // ---- Bits efetivos --------------------------------------------------------------
        val effectiveBits = when {
            outEncoding != AudioFormat.ENCODING_PCM_FLOAT || checked < 10_000 -> 0
            beyond16.toDouble() / checked > 0.001 -> 24
            else -> 16
        }

        // ---- Veredito ------------------------------------------------------------------
        val codecName = PlaybackService.codecName(mime)
        val lossless = mime in setOf("audio/flac", "audio/raw", "audio/alac", "audio/x-wav", "audio/wav") ||
            codecName in setOf("FLAC", "ALAC", "PCM", "WAV")
        val k = cutoffHz / 1000.0
        fun khz(v: Double) = String.format(java.util.Locale("pt", "BR"), "%.1f kHz", v)
        val details = mutableListOf<String>()
        details += "Conteúdo de áudio até ${khz(k)} (limite do arquivo: ${khz(nyquist / 1000)})"
        details += if (abrupt) "Queda abrupta de ${dropDb.roundToInt()} dB em ${khz(k)}: parede típica de filtro digital"
        else "Sem corte abrupto: os agudos vão até o limite do arquivo"

        var verdict: SpectrumReport.Verdict
        var title: String
        when {
            peak < 0.003f || dynamic < 15 -> {
                verdict = SpectrumReport.Verdict.INCONCLUSIVE
                title = "Inconclusivo: trecho muito baixo ou sem variação de frequência"
            }
            !lossless -> {
                verdict = SpectrumReport.Verdict.LOSSY
                title = "$codecName é um formato com perdas por natureza" + when {
                    k < 16.5 -> " (qualidade de ~128 kbps)"
                    k < 19.5 -> " (qualidade de ~192–256 kbps)"
                    else -> " (qualidade alta, ~320 kbps)"
                }
            }
            sampleRate > 48000 && abrupt && k < 16.5 -> {
                verdict = SpectrumReport.Verdict.FAKE
                title = "Hi-Res falso: feito a partir de um MP3 de ~128 kbps"
            }
            sampleRate > 48000 && k <= 22.5 -> {
                verdict = SpectrumReport.Verdict.FAKE
                title = "Hi-Res falso: conteúdo de CD convertido para ${formatRate(sampleRate)}"
            }
            sampleRate > 48000 && k <= 24.5 -> {
                verdict = SpectrumReport.Verdict.SUSPECT
                title = "Suspeito: parece um arquivo de 48 kHz convertido para ${formatRate(sampleRate)}"
            }
            sampleRate > 48000 -> {
                verdict = SpectrumReport.Verdict.AUTHENTIC
                title = "Hi-Res real: há conteúdo até ${khz(k)}"
            }
            abrupt && k < 16.5 -> {
                verdict = SpectrumReport.Verdict.FAKE
                title = "Falso: provável MP3 de ~128 kbps convertido para $codecName"
            }
            abrupt && k < 17.5 -> {
                verdict = SpectrumReport.Verdict.FAKE
                title = "Falso: provável MP3 de ~160–192 kbps convertido para $codecName"
            }
            abrupt && k < 19.0 -> {
                verdict = SpectrumReport.Verdict.SUSPECT
                title = "Suspeito: corte típico de MP3/AAC de ~256 kbps"
            }
            abrupt && k < 20.0 -> {
                verdict = SpectrumReport.Verdict.SUSPECT
                title = "Suspeito: corte típico de MP3 320 kbps ou AAC"
            }
            else -> {
                verdict = SpectrumReport.Verdict.AUTHENTIC
                title = "Autêntico: sem sinais de compressão com perdas"
                if (abrupt) details += "A parede perto de ${khz(k)} é o filtro normal no fim da faixa de áudio do arquivo"
            }
        }

        if (lossless && declaredBits > 16 && effectiveBits == 16 && verdict != SpectrumReport.Verdict.INCONCLUSIVE) {
            details += "Declara $declaredBits bits, mas só usa 16: 24-bit falso"
            if (verdict == SpectrumReport.Verdict.AUTHENTIC) {
                verdict = SpectrumReport.Verdict.SUSPECT
                title = "Suspeito: 24-bit falso (16 bits preenchidos com zeros)"
            }
        } else if (effectiveBits == 24) {
            details += "Usa mais de 16 bits de resolução de verdade"
        } else if (effectiveBits == 0 && declaredBits > 16) {
            details += "Não foi possível verificar os bits neste aparelho"
        }

        return SpectrumReport(
            spectrogram = render(columns),
            sampleRate = sampleRate,
            channels = channels,
            codec = codecName,
            declaredBits = declaredBits,
            effectiveBits = effectiveBits,
            cutoffHz = cutoffHz,
            abruptCutoff = abrupt,
            verdict = verdict,
            title = title,
            details = details,
            analyzedSeconds = (monoSamples / sampleRate).toInt(),
        )
    }

    private fun readDeclaredBits(context: Context, uri: Uri): Int {
        if (android.os.Build.VERSION.SDK_INT < 31) return 0
        val r = android.media.MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE)?.toIntOrNull() ?: 0
        } catch (e: Exception) { 0 } finally { runCatching { r.release() } }
    }

    /** Desenha o espectrograma: tempo na horizontal, frequência na vertical (graves embaixo). */
    private fun render(columns: List<FloatArray>): Bitmap {
        val w = columns.size.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, ROWS, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * ROWS)
        for (x in columns.indices) {
            val col = columns[x]
            for (r in 0 until ROWS) {
                val dbv = 10 * log10(col[r] + 1e-12)
                // -110 dB (preto) até -10 dB (amarelo claro)
                val t = ((dbv + 110) / 100).coerceIn(0.0, 1.0)
                pixels[(ROWS - 1 - r) * w + x] = palette(t)
            }
        }
        bmp.setPixels(pixels, 0, w, 0, 0, w, ROWS)
        return bmp
    }

    /** Escala de cores: preto → azul → roxo → laranja → amarelo. */
    private fun palette(t: Double): Int {
        val stops = arrayOf(
            doubleArrayOf(0.00, 0.0, 0.0, 0.0),
            doubleArrayOf(0.25, 20.0, 30.0, 110.0),
            doubleArrayOf(0.50, 130.0, 30.0, 140.0),
            doubleArrayOf(0.75, 240.0, 110.0, 40.0),
            doubleArrayOf(1.00, 255.0, 245.0, 160.0),
        )
        for (i in 1 until stops.size) {
            if (t <= stops[i][0]) {
                val a = stops[i - 1]; val b = stops[i]
                val f = (t - a[0]) / (b[0] - a[0])
                val r = (a[1] + (b[1] - a[1]) * f).toInt()
                val g = (a[2] + (b[2] - a[2]) * f).toInt()
                val bl = (a[3] + (b[3] - a[3]) * f).toInt()
                return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        return 0xFFFFF5A0.toInt()
    }

    /** FFT radix-2 iterativa, com tabelas pré-calculadas. */
    private class Fft(private val n: Int) {
        private val cosT = DoubleArray(n / 2) { cos(2 * PI * it / n) }
        private val sinT = DoubleArray(n / 2) { -sin(2 * PI * it / n) }
        private val rev = IntArray(n).also { r ->
            val bits = Integer.numberOfTrailingZeros(n)
            for (i in 0 until n) r[i] = Integer.reverse(i) ushr (32 - bits)
        }
        private val re = DoubleArray(n)
        private val im = DoubleArray(n)
        private val out = FloatArray(n / 2)

        fun powerSpectrum(x: FloatArray, window: FloatArray): FloatArray {
            for (i in 0 until n) { re[rev[i]] = (x[i] * window[i]).toDouble(); im[rev[i]] = 0.0 }
            var size = 2
            while (size <= n) {
                val half = size / 2
                val step = n / size
                var start = 0
                while (start < n) {
                    var k = 0
                    for (j in start until start + half) {
                        val wr = cosT[k]; val wi = sinT[k]
                        val tr = wr * re[j + half] - wi * im[j + half]
                        val ti = wr * im[j + half] + wi * re[j + half]
                        re[j + half] = re[j] - tr; im[j + half] = im[j] - ti
                        re[j] += tr; im[j] += ti
                        k += step
                    }
                    start += size
                }
                size *= 2
            }
            // normaliza para que um seno de amplitude 1 fique perto de 0 dB
            val norm = 4.0 / (n * n)
            for (b in 0 until n / 2) out[b] = ((re[b] * re[b] + im[b] * im[b]) * norm).toFloat()
            return out
        }
    }
}
