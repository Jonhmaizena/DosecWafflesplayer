package com.hires.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.hires.player.ui.AppTheme
import com.hires.player.ui.HiResApp
import com.hires.player.ui.SplashOverlay

class MainActivity : ComponentActivity() {

    private val vm: PlayerViewModel by viewModels()
    private val hasPermission = mutableStateOf(false)

    // Cada valor novo mostra o logo de abertura de novo
    private val splashToken = mutableIntStateOf(0)
    private var stoppedAt = 0L

    private val audioPermission =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val granted = result[audioPermission] == true || isGranted(audioPermission)
            hasPermission.value = granted
            if (granted) vm.loadLibrary()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        L.init(this) // idioma salvo (ou o do aparelho) antes de montar qualquer texto
        // Tema claro: ícones escuros na barra de status e de navegação
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)

        vm.connect()
        hasPermission.value = isGranted(audioPermission)
        if (hasPermission.value) vm.loadLibrary() else askPermissions()

        AppTheme.load(this)
        setContent {
            // Ícones da barra de status/navegação acompanham o tema (escuros no claro, claros no escuro)
            androidx.compose.runtime.LaunchedEffect(AppTheme.dark) {
                val t = android.graphics.Color.TRANSPARENT
                val style = if (AppTheme.dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            Box(Modifier.fillMaxSize()) {
                HiResApp(
                    vm = vm,
                    hasPermission = hasPermission.value,
                    onRequestPermission = ::askPermissions,
                )
                SplashOverlay(splashToken.intValue)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = android.os.SystemClock.elapsedRealtime()
    }

    override fun onRestart() {
        super.onRestart()
        // Voltando ao app depois de um tempo fora (não ao voltar rápido de um ajuste do sistema)
        if (android.os.SystemClock.elapsedRealtime() - stoppedAt > 30_000) splashToken.intValue++
    }

    override fun onResume() {
        super.onResume()
        vm.refreshOutput()
    }

    private fun askPermissions() {
        val perms = buildList {
            add(audioPermission)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun isGranted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
}
