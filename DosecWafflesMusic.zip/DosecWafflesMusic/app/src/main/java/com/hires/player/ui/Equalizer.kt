package com.hires.player.ui

import com.hires.player.tr
import com.hires.player.trf
import androidx.activity.compose.BackHandler
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.hires.player.EqBands
import com.hires.player.EqPresets
import com.hires.player.EqState
import java.util.Locale
import kotlin.math.roundToInt

private const val CUSTOM = "Personalizado"

@Composable
fun EqualizerScreen(
    state: EqState,
    bitPerfectOn: Boolean,
    onChange: (EqState) -> Unit,
    widthOn: Boolean,
    widthAmount: Float,
    onWidth: (Boolean, Float) -> Unit,
    onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    val on = state.enabled
    val focus = LocalFocusManager.current

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Voltar")) }
                Text(tr("Equalizador e Palco"), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Switch(
                    checked = on,
                    onCheckedChange = { onChange(state.copy(enabled = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Gold),
                    modifier = Modifier.padding(end = 12.dp)
                )
            }

            // Estado e relação com o bit-perfect
            Column(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .border(1.dp, if (on) Gold else MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                    .padding(14.dp)
            ) {
                Text(
                    if (on) tr("LIGADO · 15 BANDAS + LIMITADOR") else tr("DESLIGADO · SINAL PURO"),
                    style = TechStyle,
                    color = if (on) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    when {
                        on -> tr("O som passa pelo equalizador. O bit-perfect fica desativado enquanto ele estiver ligado.")
                        bitPerfectOn -> tr("Nenhum processamento no caminho. Ao ligar o equalizador, o bit-perfect será desativado.")
                        else -> tr("Nenhum processamento no caminho do áudio. O bit-perfect pode ser usado.")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (state.error.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(state.error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }

            Spacer(Modifier.height(12.dp))
            PalcoCard(widthOn, widthAmount, bitPerfectOn && !on, onWidth)

            Spacer(Modifier.height(16.dp))
            Text(
                tr("PREDEFINIÇÕES DO EQUALIZADOR"), style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(6.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(EqPresets.all) { preset ->
                    FilterChip(
                        selected = state.preset == preset.name,
                        onClick = {
                            val maxBoost = preset.gains.maxOrNull()?.coerceAtLeast(0f) ?: 0f
                            onChange(
                                state.copy(
                                    gains = preset.gains.copyOf(),
                                    preset = preset.name,
                                    // reserva de headroom para não saturar nos reforços
                                    preamp = -(maxBoost / 2f).roundToInt().toFloat(),
                                    enabled = true,
                                )
                            )
                        },
                        label = { Text(com.hires.player.tr(preset.name)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        )
                    )
                }
                if (state.preset == CUSTOM) {
                    item {
                        FilterChip(selected = true, onClick = {}, label = { Text(com.hires.player.tr(CUSTOM)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Gold,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            ))
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("PRÉ-AMPLIFICAÇÃO"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f))
                Text(db(state.preamp), style = TechStyle, color = if (on) Gold else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Slider(
                value = state.preamp,
                onValueChange = { onChange(state.copy(preamp = (it * 2).roundToInt() / 2f)) },
                valueRange = EqBands.PREAMP_MIN..EqBands.PREAMP_MAX,
                enabled = on,
                colors = sliderColors(),
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("BANDAS (dB)"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f))
                TextButton(
                    enabled = on,
                    onClick = { onChange(state.copy(gains = FloatArray(EqBands.COUNT), preamp = 0f, preset = "Plano")) }
                ) { Text(tr("Zerar"), color = if (on) Gold else MaterialTheme.colorScheme.onSurfaceVariant) }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp),
            ) {
                for (i in 0 until EqBands.COUNT) {
                    Column(Modifier.width(46.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            db(state.gains[i], short = true), style = TechStyle,
                            color = if (on && state.gains[i] != 0f) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Slider(
                            value = state.gains[i],
                            onValueChange = { v ->
                                val g = state.gains.copyOf().also { it[i] = (v * 2).roundToInt() / 2f }
                                onChange(state.copy(gains = g, preset = CUSTOM))
                            },
                            valueRange = -EqBands.MAX_DB..EqBands.MAX_DB,
                            enabled = on,
                            colors = sliderColors(),
                            modifier = Modifier
                                // Controle remoto: ↑/↓ mudam a banda, ←/→ passam para a banda vizinha
                                .onPreviewKeyEvent { e ->
                                    if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                                    fun nudge(d: Float) {
                                        val g = state.gains.copyOf()
                                        g[i] = (g[i] + d).coerceIn(-EqBands.MAX_DB, EqBands.MAX_DB)
                                        onChange(state.copy(gains = g, preset = CUSTOM))
                                    }
                                    when (e.key) {
                                        Key.DirectionUp -> { if (on) nudge(0.5f); on }
                                        Key.DirectionDown -> { if (on) nudge(-0.5f); on }
                                        Key.DirectionLeft -> focus.moveFocus(FocusDirection.Left)
                                        Key.DirectionRight -> focus.moveFocus(FocusDirection.Right)
                                        else -> false
                                    }
                                }
                                .tvFocus()
                                .vertical()
                                .width(220.dp)
                                .height(44.dp)
                        )
                        Text(
                            EqBands.label(EqBands.centers[i]), style = TechStyle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(
                tr("O limitador segura picos acima de −1 dBFS quando há reforço de bandas. Se ouvir distorção, reduza a pré-amplificação."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

/**
 * Palco: abre ou fecha a imagem estéreo, separando a voz (centro) dos instrumentos
 * (laterais). Graves continuam no centro. Ligado, desativa o bit-perfect.
 */
@Composable
private fun PalcoCard(
    on: Boolean,
    amount: Float,
    bitPerfectOn: Boolean,
    onWidth: (Boolean, Float) -> Unit,
) {
    // Valor local durante o arraste; o serviço recebe ao soltar
    var drag by remember(amount) { mutableFloatStateOf(amount) }
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .border(1.dp, if (on) Gold else MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("PALCO · SEPARAÇÃO ESTÉREO"), style = TechStyle,
                    color = if (on) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold)
                Text(
                    if (on) "${(drag * 100).roundToInt()}% · ${palcoLabel(drag)}" else tr("Desligado · imagem original"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = on,
                onCheckedChange = { onWidth(it, drag) },
                colors = SwitchDefaults.colors(checkedTrackColor = Gold),
                modifier = Modifier.tvFocus(RoundedCornerShape(50))
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(tr("Sutil") to 1.2f, tr("Amplo") to 1.4f, tr("Máximo") to 1.7f).forEach { (name, v) ->
                FilterChip(
                    selected = on && kotlin.math.abs(drag - v) < 0.01f,
                    onClick = { drag = v; onWidth(true, v) },
                    label = { Text(name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Gold,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                    modifier = Modifier.tvFocus(RoundedCornerShape(8.dp))
                )
            }
        }
        Slider(
            value = drag,
            onValueChange = { drag = (it * 20).roundToInt() / 20f },
            onValueChangeFinished = { onWidth(on, drag) },
            valueRange = 0.5f..2f,
            steps = 29,
            enabled = on,
            colors = sliderColors(),
            modifier = Modifier
                .onPreviewKeyEvent { e ->
                    if (e.type != KeyEventType.KeyDown || !on) return@onPreviewKeyEvent false
                    val d = when (e.key) {
                        Key.DirectionRight -> 0.05f
                        Key.DirectionLeft -> -0.05f
                        else -> return@onPreviewKeyEvent false
                    }
                    drag = ((drag + d) * 20).roundToInt().div(20f).coerceIn(0.5f, 2f)
                    onWidth(true, drag)
                    true
                }
                .tvFocus()
        )
        Row {
            Text(tr("Estreito"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text(tr("Original"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Text(tr("Amplo"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            when {
                on -> tr("Afasta os instrumentos das laterais e deixa a voz mais destacada no centro. Os graves ficam no centro. O bit-perfect fica desativado enquanto o Palco estiver ligado.")
                bitPerfectOn -> tr("Ao ligar o Palco, o bit-perfect será desativado.")
                else -> tr("Aumenta a sensação de separação entre voz e instrumentos. Melhor percebido em fones de ouvido.")
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun palcoLabel(w: Float) = when {
    w < 0.95f -> tr("mais estreito")
    w <= 1.05f -> tr("original")
    w < 1.35f -> tr("um pouco mais aberto")
    w < 1.65f -> tr("aberto")
    else -> tr("bem aberto")
}

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = Gold,
    activeTrackColor = Gold,
    inactiveTrackColor = MaterialTheme.colorScheme.outline,
)

private fun db(v: Float, short: Boolean = false): String {
    val s = if (v % 1f == 0f) v.toInt().toString() else String.format(Locale.US, "%.1f", v)
    val signed = if (v > 0) "+${s}" else s
    return if (short) signed else trf("%1\$s dB", signed)
}

/** Gira um Slider para a vertical (mínimo embaixo, máximo em cima). */
private fun Modifier.vertical(): Modifier = this
    .graphicsLayer {
        rotationZ = 270f
        transformOrigin = TransformOrigin(0f, 0f)
    }
    .layout { measurable, constraints ->
        val placeable = measurable.measure(
            Constraints(
                minWidth = constraints.minHeight,
                maxWidth = constraints.maxHeight,
                minHeight = constraints.minWidth,
                maxHeight = constraints.maxWidth,
            )
        )
        layout(placeable.height, placeable.width) {
            placeable.place(-placeable.width, 0)
        }
    }
