package com.hires.player.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hires.player.L
import com.hires.player.Lookup
import com.hires.player.OnlineInfo
import com.hires.player.RecAlbum
import com.hires.player.Recomendacoes
import com.hires.player.Recs
import com.hires.player.Track
import com.hires.player.tr
import com.hires.player.trf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gaveta de recomendações: álbuns relacionados ao que está tocando (com internet).
 * Tocar num álbum mostra onde ouvir (biblioteca, Tidal, Qobuz, Spotify, Deezer) ou comprar.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecommendationsSheet(
    track: Track,
    library: List<Track>,
    onOpenInLibrary: (RecAlbum) -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var result by remember(track.artist) { mutableStateOf<Lookup<Recs>?>(null) }
    var picked by remember { mutableStateOf<RecAlbum?>(null) }

    LaunchedEffect(track.artist) {
        result = Recomendacoes.load(ctx, track, library, OnlineInfo.enabled(ctx))
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, null, tint = Gold)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(tr("Recomendações"), style = MaterialTheme.typography.titleLarge)
                    Text(
                        trf("Álbuns relacionados a %1\$s", track.artist),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            when (val r = result) {
                null -> Row(Modifier.padding(horizontal = 20.dp, vertical = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Gold)
                    Spacer(Modifier.width(12.dp))
                    Text(tr("Procurando álbuns parecidos…"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Lookup.Offline -> Hint(tr("As recomendações precisam de internet. Conecte-se e abra de novo."))
                Lookup.NotFound -> Hint(tr("Não encontramos este artista para recomendar álbuns parecidos."))
                is Lookup.Found -> {
                    val recs = r.value
                    if (recs.similar.isNotEmpty()) {
                        Shelf(tr("VOCÊ TAMBÉM PODE GOSTAR"), recs.similar) { picked = it }
                    }
                    if (recs.sameArtist.isNotEmpty()) {
                        Shelf(trf("MAIS DE %1\$s", recs.artist.uppercase(L.locale)), recs.sameArtist) { picked = it }
                    }
                    if (recs.similar.isEmpty() && recs.sameArtist.isEmpty()) {
                        Hint(tr("Não há recomendações para este artista por enquanto."))
                    }
                    Text(
                        if (r.fromCache) tr("Recomendações salvas · atualizadas a cada 3 dias. Dados: Deezer.")
                        else tr("Dados: Deezer."),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }

    picked?.let { a ->
        AlbumActions(a, onOpenInLibrary = { picked = null; onOpenInLibrary(a) }, onDismiss = { picked = null })
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 24.dp)
    )
}

@Composable
private fun Shelf(title: String, albums: List<RecAlbum>, onPick: (RecAlbum) -> Unit) {
    Text(
        title,
        style = TechStyle,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(horizontal = 20.dp)
    )
    Spacer(Modifier.height(8.dp))
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(albums, key = { it.id }) { a ->
            Column(
                Modifier
                    .width(140.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .tvFocus(RoundedCornerShape(10.dp))
                    .clickable { onPick(a) }
            ) {
                Box {
                    RemoteImage(a.cover, Modifier.size(140.dp).clip(RoundedCornerShape(10.dp)))
                    if (a.inLibrary) {
                        Row(
                            Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp)
                                .background(Gold, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.LibraryMusic, null, Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(3.dp))
                            Text(tr("Na biblioteca"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(a.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    listOf(a.artist, a.year).filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
    Spacer(Modifier.height(20.dp))
}

/** Onde ouvir ou comprar o álbum escolhido. */
@Composable
private fun AlbumActions(a: RecAlbum, onOpenInLibrary: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val q = OnlineInfo.urlEncode("${a.artist} ${a.title}")
    fun open(url: String) {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        onDismiss()
    }
    val store = when (L.lang) { "en" -> "us-en"; "es" -> "es-es"; else -> "br-pt" }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { RemoteImage(a.cover, Modifier.size(120.dp).clip(RoundedCornerShape(10.dp))) },
        title = { Text(a.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(listOf(a.artist, a.year).filter { it.isNotBlank() }.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                if (a.inLibrary) {
                    OutlinedButton(onClick = onOpenInLibrary, modifier = Modifier.fillMaxWidth().tvFocus()) {
                        Icon(Icons.Filled.LibraryMusic, null, Modifier.size(18.dp), tint = Gold)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("Abrir na biblioteca"))
                    }
                }
                Text(tr("OUVIR EM"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                listOf(
                    "Tidal" to "https://tidal.com/search?q=$q",
                    "Qobuz" to "https://play.qobuz.com/search?q=$q",
                    "Spotify" to "https://open.spotify.com/search/$q",
                    "Deezer" to a.link,
                ).forEach { (name, url) ->
                    OutlinedButton(onClick = { open(url) }, modifier = Modifier.fillMaxWidth().tvFocus()) { Text(name) }
                }
                OutlinedButton(
                    onClick = { open("https://www.qobuz.com/$store/search?q=$q") },
                    modifier = Modifier.fillMaxWidth().tvFocus()
                ) {
                    Icon(Icons.Filled.ShoppingCart, null, Modifier.size(18.dp), tint = Gold)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Comprar em alta resolução (Qobuz)"))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fechar")) } },
    )
}

/** Capa vinda da internet, guardada no cache do aparelho. */
@Composable
fun RemoteImage(url: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(RemoteImages.memory(url), url) {
        if (value == null) value = withContext(Dispatchers.IO) { RemoteImages.load(ctx, url) }
    }
    val b = bmp
    if (b != null) {
        Image(b, null, contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Album, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private object RemoteImages {
    private val mem = LruCache<String, ImageBitmap>(48)

    fun memory(url: String): ImageBitmap? = if (url.isBlank()) null else mem.get(url)

    fun load(context: Context, url: String): ImageBitmap? {
        if (url.isBlank()) return null
        mem.get(url)?.let { return it }
        val dir = File(context.cacheDir, "capas_web").apply { mkdirs() }
        val f = File(dir, OnlineInfo.hash(url) + ".jpg")
        if (!f.exists()) {
            runCatching {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10_000
                c.readTimeout = 20_000
                try {
                    if (c.responseCode in 200..299) {
                        val tmp = File(f.path + ".tmp")
                        c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                        tmp.renameTo(f)
                    }
                } finally {
                    c.disconnect()
                }
            }
        }
        val bmp = runCatching { BitmapFactory.decodeFile(f.path)?.asImageBitmap() }.getOrNull() ?: return null
        mem.put(url, bmp)
        return bmp
    }
}
