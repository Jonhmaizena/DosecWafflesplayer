package com.hires.player

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/**
 * Idioma do app: português (padrão), inglês ou espanhol.
 *
 * Os textos ficam escritos em português no código; [tr] e [trf] procuram a tradução
 * nos dicionários de [Translations]. Se faltar uma tradução, aparece o texto em português.
 * Como [lang] é um estado do Compose, a tela inteira se atualiza ao trocar o idioma.
 */
object L {
    const val PT = "pt"
    const val EN = "en"
    const val ES = "es"

    var lang by mutableStateOf(PT)
        private set

    private var loaded = false

    /** Idioma salvo; na primeira vez, segue o idioma do aparelho (inglês ou espanhol), senão português. */
    fun init(context: Context) {
        if (loaded) return
        loaded = true
        val prefs = context.getSharedPreferences("idioma", Context.MODE_PRIVATE)
        val saved = prefs.getString("lang", null)
        lang = saved ?: when (Locale.getDefault().language) {
            "en" -> EN
            "es" -> ES
            else -> PT
        }
    }

    fun set(context: Context, code: String) {
        lang = if (code == EN || code == ES) code else PT
        context.getSharedPreferences("idioma", Context.MODE_PRIVATE).edit().putString("lang", lang).apply()
    }

    /** Formato de números (vírgula ou ponto decimal) de acordo com o idioma. */
    val locale: Locale
        get() = when (lang) {
            EN -> Locale.US
            ES -> Locale("es", "ES")
            else -> Locale("pt", "BR")
        }

    val names = listOf(PT to "Português", EN to "English", ES to "Español")

    fun t(pt: String): String = when (lang) {
        EN -> Translations.en[pt] ?: pt
        ES -> Translations.es[pt] ?: pt
        else -> pt
    }

    fun f(pt: String, vararg args: Any?): String =
        try { String.format(locale, t(pt), *args) } catch (e: Exception) { String.format(locale, pt, *args) }
}

/** Traduz um texto fixo. */
fun tr(pt: String): String = L.t(pt)

/** Traduz um texto com partes variáveis (%1$s, %2$s...). */
fun trf(pt: String, vararg args: Any?): String = L.f(pt, *args)
