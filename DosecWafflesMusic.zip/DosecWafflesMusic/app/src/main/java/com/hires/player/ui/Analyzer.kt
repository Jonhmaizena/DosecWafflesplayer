package com.hires.player.ui

import com.hires.player.tr
import com.hires.player.trf
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hires.player.SpectrumAnalyzer
import com.hires.player.SpectrumReport
import com.hires.player.SpectrumReport.Verdict
import com.hires.player.Track
import com.hires.player.formatRate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private val VerdictGreen = Color(0xFF2EBD5A)
private val VerdictAmber = Color(0xFFF5A623)
private val VerdictRed = Color(0xFFE5484D)
private val VerdictGray = Color(0xFF8A99B0)

/** Tela do analisador de espectro: espectrograma + veredito de autenticidade. */
@Composable
fun AnalyzerScreen(track: Track, knownBits: Int, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    var progress by remember(track.id) { mutableFloatStateOf(0f) }
    var report by remember(track.id) { mutableStateOf<SpectrumReport?>(null) }
    var error by remember(track.id) { mutableStateOf<String?>(null) }

    LaunchedEffect(track.id) {
        val result = withContext(Dispatchers.Default) {
            runCatching {
                var last = 0f
                SpectrumAnalyzer.analyze(ctx, track.uri, knownBits) { p ->
                    if (p - last >= 0.01f || p >= 1f) { last = p; progress = p }
                }
            }
        }
        result.onSuccess { report = it }.onFailure { error = it.message ?: tr("Não foi possível analisar este arquivo") }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Voltar"))
                }
                Column(Modifier.weight(1f)) {
                    Text(tr("Analisador de espectro"), style = MaterialTheme.typography.titleLarge)
                    Text(
                        "${track.title} · ${track.artist}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }

            Column(
                Modifier.align(Alignment.CenterHorizontally).widthIn(max = 720.dp).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val r = report
                when {
                    error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
                    r == null -> {
                        Text(trf("Analisando o arquivo… %1\$s%%", (progress * 100).toInt()), fontWeight = FontWeight.Medium)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth(),
                            color = Gold,
                            trackColor = MaterialTheme.colorScheme.outline,
                        )
                        Text(
                            tr("O app decodifica o arquivo inteiro (até 5 minutos) e mede a energia de cada frequência."),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    else -> {
                        VerdictCard(r)
                        Spectrogram(r)
                        Facts(r)
                        Text(
                            tr("Análise técnica indicativa. Gravações antigas ou com poucos agudos podem ter pouca energia ") +
                                tr("nas altas frequências; o app só aponta \"falso\" quando encontra a parede abrupta ") +
                                tr("que codificadores com perdas e conversões de taxa deixam."),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VerdictCard(r: SpectrumReport) {
    val (color, label) = when (r.verdict) {
        Verdict.AUTHENTIC -> VerdictGreen to tr("AUTÊNTICO")
        Verdict.SUSPECT -> VerdictAmber to tr("SUSPEITO")
        Verdict.FAKE -> VerdictRed to tr("FALSO")
        Verdict.LOSSY -> VerdictAmber to tr("COM PERDAS")
        Verdict.INCONCLUSIVE -> VerdictGray to tr("INCONCLUSIVO")
    }
    Column(
        Modifier
            .fillMaxWidth()
            .border(2.dp, color, RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(22.dp).background(color.copy(alpha = 0.25f), CircleShape))
                Box(Modifier.size(14.dp).background(color, CircleShape))
            }
            Spacer(Modifier.width(10.dp))
            Text(label, style = TechStyle, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(Modifier.height(6.dp))
        Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        r.details.forEach {
            Text("• ${it}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Spectrogram(r: SpectrumReport) {
    val image = remember(r) { r.spectrogram.asImageBitmap() }
    val nyquist = r.sampleRate / 2
    val step = when {
        nyquist <= 24_000 -> 5_000
        nyquist <= 48_000 -> 10_000
        else -> 20_000
    }
    Column {
        Text("ESPECTROGRAMA", style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().height(240.dp)) {
            // Eixo de frequência
            BoxWithConstraints(Modifier.width(48.dp).fillMaxHeight()) {
                val h = maxHeight
                var f = 0
                while (f <= nyquist) {
                    val y = h * (1f - f.toFloat() / nyquist)
                    Text(
                        if (f == 0) "0" else "${f / 1000}k",
                        style = TechStyle,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.offset(y = (y - 8.dp).coerceIn(0.dp, h - 16.dp))
                    )
                    f += step
                }
            }
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Image(image, tr("Espectrograma"), contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                // Linha tracejada no ponto de corte encontrado
                if (r.abruptCutoff) {
                    Canvas(Modifier.fillMaxSize()) {
                        val y = size.height * (1f - r.cutoffHz.toFloat() / nyquist)
                        drawLine(
                            color = Color.White,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 3f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))
                        )
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 48.dp, top = 4.dp)) {
            Text(tr("início"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text("${r.analyzedSeconds / 60}:${"%02d".format(r.analyzedSeconds % 60)}", style = TechStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (r.abruptCutoff) {
            Text(
                trf("Linha tracejada: corte em %1\$s kHz", String.format(com.hires.player.L.locale, "%.1f", r.cutoffHz / 1000.0)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 48.dp, top = 2.dp)
            )
        }
    }
}

@Composable
private fun Facts(r: SpectrumReport) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Text(tr("DADOS DO ARQUIVO"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Fact(tr("Formato"), r.codec)
        Fact(tr("Taxa de amostragem"), formatRate(r.sampleRate))
        Fact(tr("Canais"), if (r.channels == 2) tr("Estéreo") else "${r.channels}")
        Fact(tr("Bits declarados"), if (r.declaredBits > 0) "${r.declaredBits}-bit" else tr("não informado"))
        Fact(
            tr("Bits usados de verdade"),
            when (r.effectiveBits) {
                0 -> tr("não verificável neste aparelho")
                16 -> "16-bit"
                else -> tr("mais de 16 bits")
            }
        )
        Fact(tr("Conteúdo até"), String.format(com.hires.player.L.locale, "%.1f kHz", r.cutoffHz / 1000.0))
        Fact(tr("Trecho analisado"), "${r.analyzedSeconds} s")
    }
}

@Composable
private fun Fact(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(170.dp)
        )
        Text(value, style = TechStyle, modifier = Modifier.weight(1f))
    }
}
