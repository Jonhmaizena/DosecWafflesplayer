package com.hires.player.ui

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Verdadeiro quando o app está rodando numa Android TV (ou Google TV). */
fun Context.isTv(): Boolean {
    val ui = getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
}

@Composable
fun rememberIsTv(): Boolean {
    val ctx = LocalContext.current
    return remember { ctx.isTv() }
}

/**
 * Destaque do item selecionado pelo controle remoto: contorno azul e fundo levemente
 * azulado. Vem antes do `.clickable` para enxergar o foco dele. No celular, onde
 * ninguém navega pelo direcional, nunca aparece.
 */
fun Modifier.tvFocus(shape: Shape = RoundedCornerShape(10.dp)): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    this
        .onFocusChanged { focused = it.isFocused || it.hasFocus }
        .border(if (focused) 3.dp else 0.dp, if (focused) Gold else Color.Transparent, shape)
        .background(if (focused) Gold.copy(alpha = 0.12f) else Color.Transparent, shape)
}
