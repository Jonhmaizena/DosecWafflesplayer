package com.hires.player

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Um álbum recomendado. */
data class RecAlbum(
    val id: Long,
    val title: String,
    val artist: String,
    val cover: String,
    val year: String,
    val link: String,
    /** Já existe na biblioteca do aparelho. */
    val inLibrary: Boolean,
)

data class Recs(
    val artist: String,
    val sameArtist: List<RecAlbum>,
    val similar: List<RecAlbum>,
)

/**
 * Recomendações de álbuns relacionados ao que está tocando (precisa de internet).
 * Usa a API pública do Deezer: artistas relacionados e os álbuns mais ouvidos de cada um.
 * Só o nome do artista é enviado.
 */
object Recomendacoes {
    private const val MAX_AGE = 3L * 24 * 3600 * 1000
    private const val API = "https://api.deezer.com/"

    private fun dir(context: Context) = File(context.filesDir, "recomendacoes").apply { mkdirs() }

    private fun getJson(path: String): JSONObject? {
        val j = OnlineInfo.http(API + path)?.let { JSONObject(it) } ?: return null
        if (j.has("error")) throw java.io.IOException(j.optJSONObject("error")?.optString("message") ?: "Deezer")
        return j
    }

    private fun data(j: JSONObject?): List<JSONObject> =
        j?.optJSONArray("data")?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } }.orEmpty()

    /** Tira "(Deluxe)", "[Remastered]" etc. para comparar títulos. */
    private fun base(title: String) = OnlineInfo.normalize(title.replace(Regex("""\s*[(\[].*?[)\]]"""), ""))

    suspend fun load(context: Context, track: Track, library: List<Track>, online: Boolean): Lookup<Recs> = withContext(Dispatchers.IO) {
        if (OnlineInfo.isUnknown(track.artist)) return@withContext Lookup.NotFound
        val f = File(dir(context), "${OnlineInfo.hash(track.artist)}.json")
        val cached = runCatching { JSONObject(f.readText()) }.getOrNull()
        val fresh = cached != null && System.currentTimeMillis() - cached.optLong("t") < MAX_AGE
        if (cached != null && (fresh || !online)) {
            return@withContext if (cached.optBoolean("notFound")) Lookup.NotFound
            else Lookup.Found(fromJson(cached, track, library), true)
        }
        if (!online) return@withContext Lookup.Offline
        try {
            val j = fetch(track) ?: JSONObject().put("notFound", true)
            j.put("t", System.currentTimeMillis())
            runCatching { File(f.path + ".tmp").apply { writeText(j.toString()) }.renameTo(f) }
            if (j.optBoolean("notFound")) Lookup.NotFound else Lookup.Found(fromJson(j, track, library), false)
        } catch (e: Exception) {
            cached?.takeIf { !it.optBoolean("notFound") }?.let { Lookup.Found(fromJson(it, track, library), true) } ?: Lookup.Offline
        }
    }

    private suspend fun fetch(track: Track): JSONObject? = coroutineScope {
        val found = data(getJson("search/artist?q=${OnlineInfo.urlEncode(track.artist)}&limit=5"))
        if (found.isEmpty()) return@coroutineScope null
        val want = OnlineInfo.normalize(track.artist)
        val artist = found.firstOrNull { OnlineInfo.normalize(it.optString("name")) == want } ?: found.first()
        val artistId = artist.optLong("id")
        val artistName = artist.optString("name")

        // Mais do mesmo artista (sem o álbum que está tocando)
        val own = async { albumsOf(artistId, artistName, limit = 100) }
        // Artistas relacionados: o álbum mais ouvido de cada um
        val related = data(getJson("artist/$artistId/related?limit=16")).take(14)
        val similar = related.map { r ->
            async {
                runCatching { albumsOf(r.optLong("id"), r.optString("name"), limit = 40).firstOrNull() }.getOrNull()
            }
        }.awaitAll().filterNotNull()

        val current = base(track.album)
        val same = own.await().filter { base(it.optString("title")) != current }.take(12)
        JSONObject()
            .put("artist", artistName)
            .put("same", JSONArray(same))
            .put("similar", JSONArray(similar))
    }

    /** Álbuns de um artista, os mais populares primeiro, sem edições repetidas. */
    private fun albumsOf(id: Long, name: String, limit: Int): List<JSONObject> {
        val list = data(getJson("artist/$id/albums?limit=$limit"))
        val albums = list.filter { it.optString("record_type") == "album" }.ifEmpty { list }
        return albums
            .sortedWith(compareByDescending<JSONObject> { it.optInt("fans") }.thenByDescending { it.optString("release_date") })
            .distinctBy { base(it.optString("title")) }
            .map { a ->
                JSONObject()
                    .put("id", a.optLong("id"))
                    .put("title", a.optString("title"))
                    .put("artist", name)
                    .put("cover", a.optString("cover_big").ifBlank { a.optString("cover_medium") })
                    .put("year", a.optString("release_date").take(4))
                    .put("link", a.optString("link").ifBlank { "https://www.deezer.com/album/${a.optLong("id")}" })
            }
    }

    private fun fromJson(j: JSONObject, track: Track, library: List<Track>): Recs {
        // Álbuns da biblioteca, para marcar "Na sua biblioteca"
        val owned = library.asSequence().map { base(it.album) + "|" + OnlineInfo.normalize(it.artist) }.toHashSet()
        fun list(name: String): List<RecAlbum> {
            val a: JSONArray = j.optJSONArray(name) ?: return emptyList()
            return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
                val title = o.optString("title")
                val artist = o.optString("artist")
                RecAlbum(
                    id = o.optLong("id"),
                    title = title,
                    artist = artist,
                    cover = o.optString("cover"),
                    year = o.optString("year"),
                    link = o.optString("link"),
                    inLibrary = (base(title) + "|" + OnlineInfo.normalize(artist)) in owned,
                )
            }
        }
        return Recs(j.optString("artist").ifBlank { track.artist }, list("same"), list("similar"))
    }
}
