package com.hires.player.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hires.player.CritSection
import com.hires.player.Critica
import com.hires.player.CritiqueDoc
import com.hires.player.L
import com.hires.player.Lookup
import com.hires.player.OnlineInfo
import com.hires.player.Track
import com.hires.player.tr
import com.hires.player.trf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * "Crítica": bastidores, curiosidades e recepção da crítica do álbum e da música que estão
 * tocando, traduzidos para o idioma do app e guardados no aparelho.
 */
@Composable
fun CritiqueScreen(track: Track, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val ctx = LocalContext.current
    val online = remember { OnlineInfo.enabled(ctx) }
    var reload by remember { mutableIntStateOf(0) }
    var album by remember(track.id) { mutableStateOf<Lookup<CritiqueDoc>?>(null) }
    var song by remember(track.id) { mutableStateOf<Lookup<CritiqueDoc>?>(null) }
    var albumStage by remember { mutableStateOf("") }
    var songStage by remember { mutableStateOf("") }
    val lang = L.lang

    LaunchedEffect(track.id, reload, lang) {
        album = null; song = null
        withContext(Dispatchers.IO) {
            album = Critica.album(ctx, track, online) { albumStage = it }
            song = Critica.song(ctx, track, online) { songStage = it }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Voltar"))
                }
                Column(Modifier.weight(1f)) {
                    Text(tr("Crítica"), style = MaterialTheme.typography.titleLarge)
                    Text(
                        "${track.title} · ${track.artist}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (online) {
                    IconButton(modifier = Modifier.tvFocus(CircleShape), onClick = { reload++ }) {
                        Icon(Icons.Filled.Refresh, tr("Atualizar"))
                    }
                }
            }

            Column(
                Modifier.align(Alignment.CenterHorizontally).widthIn(max = 760.dp).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                CritCard(
                    Icons.Filled.Album, tr("ÁLBUM"), track.album, album, albumStage,
                    notFound = tr("Não encontramos crítica publicada sobre este álbum."),
                ) { ArtImage(track, Modifier.size(64.dp), corner = 8.dp) }
                CritCard(
                    Icons.Filled.MusicNote, tr("MÚSICA"), track.title, song, songStage,
                    notFound = tr("Esta música não tem uma página própria com crítica. Veja a crítica do álbum acima."),
                )
                Text(
                    tr("Textos da Wikipedia (licença CC BY-SA) e notas das publicações via Wikidata. A tradução é feita no próprio aparelho."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (!online) {
                    Text(
                        tr("A busca na internet está desligada (Sobre a música › Buscar informações na internet)."),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CritCard(
    icon: ImageVector,
    heading: String,
    title: String,
    result: Lookup<CritiqueDoc>?,
    stage: String,
    notFound: String,
    art: (@Composable () -> Unit)? = null,
) {
    val ctx = LocalContext.current
    fun open(url: String) {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(heading, style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (art != null) {
                art()
                Spacer(Modifier.width(12.dp))
            }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(10.dp))

        when (result) {
            null -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Gold)
                Spacer(Modifier.width(10.dp))
                Text(stage.ifBlank { tr("Buscando a crítica…") }, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Lookup.NotFound -> Text(notFound, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Lookup.Offline -> Text(tr("Sem internet e sem crítica salva ainda."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            is Lookup.Found -> {
                val d = result.value
                // Notas das publicações
                if (d.scores.isNotEmpty()) {
                    Text(tr("NOTAS DA CRÍTICA"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        d.scores.forEach { s ->
                            Column(
                                Modifier
                                    .background(Gold.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(s.value, color = Gold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(s.source, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }

                // Aviso de tradução
                if (d.translated || d.translationFailed) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Translate, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (d.translated) trf("Traduzido automaticamente do %1\$s", langName(d.sourceLang))
                            else trf("Não foi possível traduzir neste aparelho. Texto original em %1\$s.", langName(d.sourceLang)),
                            style = MaterialTheme.typography.labelSmall,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                }

                val groups = listOf(
                    CritSection.SUMMARY to "",
                    CritSection.CONTEXT to tr("BASTIDORES E CURIOSIDADES"),
                    CritSection.RECEPTION to tr("RECEPÇÃO DA CRÍTICA"),
                )
                for ((g, label) in groups) {
                    val secs = d.sections.filter { it.group == g }
                    if (secs.isEmpty()) continue
                    if (label.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(label, style = TechStyle, color = Gold, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                    }
                    secs.forEach { s -> SectionText(s) }
                }
                if (d.sections.isEmpty()) {
                    Text(tr("Há apenas as notas das publicações, sem texto de crítica."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                // Resenhas completas
                Spacer(Modifier.height(12.dp))
                Text(tr("LER A CRÍTICA COMPLETA"), style = TechStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    d.links.forEach { l ->
                        OutlinedButton(onClick = { open(l.url) }, modifier = Modifier.tvFocus()) {
                            Text(l.label)
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, null, Modifier.size(14.dp))
                        }
                    }
                    if (d.wikiUrl.isNotBlank()) {
                        OutlinedButton(onClick = { open(d.wikiUrl) }, modifier = Modifier.tvFocus()) {
                            Text("Wikipedia")
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, null, Modifier.size(14.dp))
                        }
                    }
                }
                if (result.fromCache) {
                    Spacer(Modifier.height(6.dp))
                    Text(tr("Salvo no aparelho · funciona offline"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

private fun langName(code: String) = when (code) {
    "en" -> tr("inglês")
    "es" -> tr("espanhol")
    "pt" -> tr("português")
    else -> code
}

/** Uma seção: título e parágrafos; longa, abre e fecha ao tocar. */
@Composable
private fun SectionText(s: CritSection) {
    var open by remember(s.text) { mutableStateOf(s.group == CritSection.SUMMARY && s.text.length < 900) }
    val paragraphs = remember(s.text) { s.text.split('\n').filter { it.isNotBlank() } }
    val long = s.text.length > 600 || paragraphs.size > 2
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        if (s.heading.isNotBlank()) {
            Text(s.heading, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
        }
        // Fechada: até o primeiro parágrafo de texto (com o subtítulo antes dele, se houver)
        val shown = if (open || !long) paragraphs
        else paragraphs.take(paragraphs.indexOfFirst { !it.startsWith("§ ") }.coerceAtLeast(0) + 1)
        Column(
            Modifier.tvFocus().clickable(enabled = long) { open = !open },
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            shown.forEach { p ->
                if (p.startsWith("§ ")) {
                    Text(p.removePrefix("§ "), style = MaterialTheme.typography.labelLarge, color = Gold)
                } else {
                    Text(
                        p,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = if (open || !long) Int.MAX_VALUE else 5,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (long) {
            TextButton(onClick = { open = !open }) {
                Text(if (open) tr("Mostrar menos") else tr("Ler mais"), color = Gold)
            }
        }
    }
}
