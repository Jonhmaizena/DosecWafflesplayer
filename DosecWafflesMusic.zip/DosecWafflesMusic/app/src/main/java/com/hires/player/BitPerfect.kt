package com.hires.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * Conexão direta ao DAC USB (Android 14+).
 *
 * 1. Bit-perfect: pede ao Android que a saída USB use exatamente a taxa da faixa,
 *    sem mixer, sem reamostragem e sem volume digital.
 * 2. Se o celular não oferecer bit-perfect, tenta o segundo melhor: o mixer do
 *    Android rodando na taxa da faixa, o que evita qualquer reamostragem.
 */
class BitPerfectController(context: Context) {

    enum class Mode { OFF, DIRECT, NATIVE_RATE }

    private val audioManager = context.getSystemService(AudioManager::class.java)
    private var lastApplied: String? = null

    var enabled: Boolean = false

    var mode: Mode = Mode.OFF
        private set

    /** O que o DAC/celular oferecem, para o painel de diagnóstico. */
    var diagnostics: String = ""
        private set

    /** Verdadeiro quando o sistema aceitou o bit-perfect para a faixa atual. */
    val active: Boolean get() = enabled && mode == Mode.DIRECT

    /** Verdadeiro quando o mixer está na taxa da faixa (sem reamostragem), mas não em bit-perfect. */
    val nativeRate: Boolean get() = enabled && mode == Mode.NATIVE_RATE

    fun usbDacConnected(): Boolean =
        audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in USB_TYPES }

    /** Aplica (ou remove) o modo para a faixa atual. Retorna o status e se a configuração mudou. */
    fun apply(sampleRate: Int): Pair<String, Boolean> {
        if (Build.VERSION.SDK_INT < 34) {
            mode = Mode.OFF
            diagnostics = "Android ${Build.VERSION.RELEASE}: a conexão direta exige Android 14 ou mais novo"
            return "Requer Android 14 ou mais novo" to false
        }
        val r = Api34.apply(audioManager, enabled, sampleRate)
        mode = r.mode
        diagnostics = r.diagnostics
        val changed = r.key != null && r.key != lastApplied
        lastApplied = r.key
        return r.status to changed
    }

    fun clear() {
        if (Build.VERSION.SDK_INT >= 34) Api34.clearAll(audioManager)
        lastApplied = null
        mode = Mode.OFF
    }

    private class Result(val status: String, val key: String?, val mode: Mode, val diagnostics: String)

    @RequiresApi(34)
    private object Api34 {
        private val attrs: AudioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        private fun usbOutput(am: AudioManager): AudioDeviceInfo? =
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.type in USB_TYPES }

        fun clearAll(am: AudioManager) {
            usbOutput(am)?.let { runCatching { am.clearPreferredMixerAttributes(attrs, it) } }
        }

        fun apply(am: AudioManager, enabled: Boolean, sampleRate: Int): Result {
            val device = usbOutput(am)
            val all = device?.let {
                runCatching { am.getSupportedMixerAttributes(it) }.getOrDefault(emptyList())
            } ?: emptyList()
            val diag = describe(device, all)

            if (!enabled) {
                device?.let { runCatching { am.clearPreferredMixerAttributes(attrs, it) } }
                return Result("Desligado", "off", Mode.OFF, diag)
            }
            if (device == null) return Result("Conecte um DAC USB", null, Mode.OFF, diag)
            if (sampleRate <= 0) return Result("Aguardando a faixa", null, Mode.OFF, diag)
            if (all.isEmpty()) {
                return Result("O Android não informou os formatos deste DAC", null, Mode.OFF, diag)
            }

            // 1) Bit-perfect na taxa exata da faixa
            val perfect = all.filter {
                it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT && it.format.sampleRate == sampleRate
            }
            if (perfect.isNotEmpty()) {
                // O player entrega PCM float; preferimos o formato que preserva mais bits
                val pick = perfect.maxBy { score(it.format.encoding) }
                if (runCatching { am.setPreferredMixerAttributes(attrs, device, pick) }.getOrDefault(false)) {
                    return Result(
                        "Ativo · ${formatRate(sampleRate)} · ${encodingName(pick.format.encoding)} · ${device.productName}",
                        "bp/$sampleRate/${pick.format.encoding}/${device.id}", Mode.DIRECT, diag
                    )
                }
            }

            // 2) Mixer na taxa da faixa: sem reamostragem, mas ainda passando pelo mixer
            val sameRate = all.filter {
                it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_DEFAULT && it.format.sampleRate == sampleRate
            }
            if (sameRate.isNotEmpty()) {
                val pick = sameRate.maxBy { score(it.format.encoding) }
                if (runCatching { am.setPreferredMixerAttributes(attrs, device, pick) }.getOrDefault(false)) {
                    val why = if (all.none { it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT })
                        "este celular não oferece bit-perfect" else "sem bit-perfect nesta taxa"
                    return Result(
                        "Sem reamostragem · ${formatRate(sampleRate)} · ${encodingName(pick.format.encoding)} · $why",
                        "mix/$sampleRate/${pick.format.encoding}/${device.id}", Mode.NATIVE_RATE, diag
                    )
                }
            }

            device.let { runCatching { am.clearPreferredMixerAttributes(attrs, it) } }
            val reason = when {
                all.none { it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT } ->
                    "Este celular não oferece bit-perfect para DAC USB"
                else -> "O DAC não aceita ${formatRate(sampleRate)} em bit-perfect"
            }
            return Result(reason, "none/${device.id}", Mode.OFF, diag)
        }

        /** Resumo do que o Android oferece para este DAC, agrupado por modo. */
        private fun describe(device: AudioDeviceInfo?, all: List<AudioMixerAttributes>): String {
            if (device == null) return ""
            fun group(behavior: Int): String {
                val list = all.filter { it.mixerBehavior == behavior }
                if (list.isEmpty()) return "nenhum"
                val rates = list.map { it.format.sampleRate }.filter { it > 0 }.distinct().sorted()
                    .joinToString("/") { formatRate(it).removeSuffix(" kHz") }
                val encs = list.map { encodingName(it.format.encoding) }.distinct().joinToString(", ")
                return "$rates kHz ($encs)"
            }
            return "${device.productName}: bit-perfect ${group(AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT)} · " +
                "mixer ${group(AudioMixerAttributes.MIXER_BEHAVIOR_DEFAULT)}"
        }

        private fun score(encoding: Int) = when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> 5
            AudioFormat.ENCODING_PCM_32BIT -> 4
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> 3
            AudioFormat.ENCODING_PCM_16BIT -> 1
            else -> 0
        }

        private fun encodingName(encoding: Int) = when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> "32-bit float"
            AudioFormat.ENCODING_PCM_32BIT -> "32-bit"
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> "24-bit"
            AudioFormat.ENCODING_PCM_16BIT -> "16-bit"
            else -> "PCM"
        }
    }

    companion object {
        val USB_TYPES = setOf(
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY
        )
    }
}

fun formatRate(hz: Int): String {
    if (hz <= 0) return ""
    val khz = hz / 1000.0
    return if (hz % 1000 == 0) "${hz / 1000} kHz"
    else String.format(java.util.Locale("pt", "BR"), "%.1f kHz", khz)
}
