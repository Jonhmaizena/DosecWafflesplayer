package com.hires.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * Modo bit-perfect do Android 14+: pede ao sistema que a saída USB use exatamente
 * a taxa de amostragem da faixa, sem mixer, sem reamostragem e sem volume digital.
 * Só funciona com DAC USB e depende do celular expor esse modo.
 */
class BitPerfectController(context: Context) {

    private val audioManager = context.getSystemService(AudioManager::class.java)
    private var lastApplied: String? = null

    var enabled: Boolean = false

    /** Verdadeiro quando o sistema aceitou o modo bit-perfect para a faixa atual. */
    val active: Boolean get() = enabled && lastApplied != null && lastApplied != "off"

    /** Aplica (ou remove) o modo para a faixa atual. Retorna o texto de status e se mudou algo. */
    fun apply(sampleRate: Int): Pair<String, Boolean> {
        if (Build.VERSION.SDK_INT < 34) return "Requer Android 14 ou mais novo" to false
        val (status, key) = Api34.apply(audioManager, enabled, sampleRate)
        val changed = key != null && key != lastApplied
        lastApplied = key
        return status to changed
    }

    fun clear() {
        if (Build.VERSION.SDK_INT >= 34) Api34.clearAll(audioManager)
        lastApplied = null
    }

    @RequiresApi(34)
    private object Api34 {
        private val attrs: AudioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        private fun usbOutput(am: AudioManager): AudioDeviceInfo? =
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_DEVICE
            }

        fun clearAll(am: AudioManager) {
            usbOutput(am)?.let { runCatching { am.clearPreferredMixerAttributes(attrs, it) } }
        }

        /** Retorna o status e uma chave da configuração aplicada (null se nenhuma). */
        fun apply(am: AudioManager, enabled: Boolean, sampleRate: Int): Pair<String, String?> {
            val device = usbOutput(am)
            if (!enabled) {
                device?.let { runCatching { am.clearPreferredMixerAttributes(attrs, it) } }
                return "Desligado" to "off"
            }
            if (device == null) return "Conecte um DAC USB" to null
            if (sampleRate <= 0) return "Aguardando a faixa" to null

            val options = runCatching { am.getSupportedMixerAttributes(device) }.getOrDefault(emptyList())
                .filter { it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT }
            if (options.isEmpty()) return "Este celular/DAC não oferece bit-perfect" to null

            val sameRate = options.filter { it.format.sampleRate == sampleRate }
            if (sameRate.isEmpty()) {
                return "O DAC não aceita ${formatRate(sampleRate)} em bit-perfect" to null
            }
            // O player entrega PCM float; preferimos o formato que preserva mais bits.
            val pick = sameRate.maxBy { score(it.format.encoding) }
            val ok = runCatching { am.setPreferredMixerAttributes(attrs, device, pick) }.getOrDefault(false)
            return if (ok) {
                "Ativo · ${formatRate(sampleRate)} · ${encodingName(pick.format.encoding)} · ${device.productName}" to
                    "$sampleRate/${pick.format.encoding}/${device.id}"
            } else {
                "O sistema recusou o bit-perfect" to null
            }
        }

        private fun score(encoding: Int) = when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> 5
            AudioFormat.ENCODING_PCM_32BIT -> 4
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> 3
            AudioFormat.ENCODING_PCM_16BIT -> 1
            else -> 0
        }

        private fun encodingName(encoding: Int) = when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> "32-bit float"
            AudioFormat.ENCODING_PCM_32BIT -> "32-bit"
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> "24-bit"
            AudioFormat.ENCODING_PCM_16BIT -> "16-bit"
            else -> "PCM"
        }
    }
}

fun formatRate(hz: Int): String {
    if (hz <= 0) return ""
    val khz = hz / 1000.0
    return if (hz % 1000 == 0) "${hz / 1000} kHz"
    else String.format(java.util.Locale("pt", "BR"), "%.1f kHz", khz)
}
