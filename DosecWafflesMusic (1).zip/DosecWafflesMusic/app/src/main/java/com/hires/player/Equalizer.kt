package com.hires.player

import android.content.Context
import android.media.audiofx.DynamicsProcessing
import android.os.Bundle

/** Bandas ISO de 2/3 de oitava, de 25 Hz a 16 kHz. */
object EqBands {
    val centers = floatArrayOf(
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
        1000f, 1600f, 2500f, 4000f, 6300f, 10000f, 16000f,
    )
    const val COUNT = 15
    const val MAX_DB = 15f
    const val PREAMP_MIN = -12f
    const val PREAMP_MAX = 6f

    /** Limite superior de cada banda: a média geométrica com a próxima banda. */
    val cutoffs: FloatArray = FloatArray(COUNT) { i ->
        if (i == COUNT - 1) 20000f
        else kotlin.math.sqrt(centers[i] * centers[i + 1])
    }

    fun label(hz: Float): String =
        if (hz >= 1000f) {
            val k = hz / 1000f
            if (k % 1f == 0f) "${k.toInt()}k" else String.format(java.util.Locale.US, "%.1fk", k)
        } else hz.toInt().toString()
}

data class EqPreset(val name: String, val gains: FloatArray)

object EqPresets {
    //                         25  40  63 100 160 250 400 630  1k 1.6k 2.5k 4k 6.3k 10k 16k
    val all = listOf(
        EqPreset("Plano", floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Graves", floatArrayOf(7f, 6.5f, 6f, 4.5f, 3f, 1.5f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Sub-grave", floatArrayOf(9f, 8f, 5f, 2f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Agudos", floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0.5f, 1.5f, 3f, 4.5f, 5.5f, 6f, 6f)),
        EqPreset("Vocal", floatArrayOf(-3f, -3f, -2f, -1f, 0f, 1f, 2.5f, 3.5f, 4f, 3.5f, 2.5f, 1f, 0f, -0.5f, -1f)),
        EqPreset("Rock", floatArrayOf(5f, 4.5f, 4f, 2.5f, 0.5f, -1f, -1.5f, -1f, 0.5f, 2f, 3.5f, 4.5f, 5f, 5f, 4.5f)),
        EqPreset("Pop", floatArrayOf(-1f, -0.5f, 0.5f, 2f, 3.5f, 4f, 3f, 1.5f, 0f, -0.5f, -0.5f, 0f, 1f, 1.5f, 2f)),
        EqPreset("Jazz", floatArrayOf(3f, 3f, 2.5f, 2f, 1f, -1f, -1.5f, -1f, 0f, 1f, 2f, 2.5f, 3f, 3f, 3f)),
        EqPreset("Clássica", floatArrayOf(4f, 3.5f, 3f, 2f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 2.5f, 3.5f, 4f)),
        EqPreset("Eletrônica", floatArrayOf(6f, 5.5f, 5f, 3f, 0.5f, -1f, -2f, -1f, 0f, 1f, 2f, 3.5f, 4.5f, 5f, 5f)),
        EqPreset("Loudness", floatArrayOf(6f, 5f, 4f, 2.5f, 1f, 0f, -0.5f, -1f, -1f, -0.5f, 0.5f, 2f, 3.5f, 4.5f, 5f)),
        EqPreset("Fone Hi-Fi", floatArrayOf(2f, 2f, 1.5f, 1f, 0.5f, 0f, 0f, -0.5f, 0f, 0.5f, 1f, 0.5f, -1f, 0f, 1f)),
    )

    fun byName(name: String) = all.firstOrNull { it.name == name }
}

data class EqState(
    val enabled: Boolean = false,
    val preamp: Float = 0f,
    val gains: FloatArray = FloatArray(EqBands.COUNT),
    val preset: String = "Plano",
    val error: String = "",
) {
    fun toBundle(b: Bundle) {
        b.putBoolean(K_ON, enabled)
        b.putFloat(K_PRE, preamp)
        b.putFloatArray(K_GAINS, gains)
        b.putString(K_PRESET, preset)
        b.putString(K_ERR, error)
    }

    companion object {
        private const val K_ON = "eq_on"
        private const val K_PRE = "eq_pre"
        private const val K_GAINS = "eq_gains"
        private const val K_PRESET = "eq_preset"
        private const val K_ERR = "eq_err"

        fun fromBundle(b: Bundle) = EqState(
            enabled = b.getBoolean(K_ON, false),
            preamp = b.getFloat(K_PRE, 0f),
            gains = b.getFloatArray(K_GAINS)?.takeIf { it.size == EqBands.COUNT } ?: FloatArray(EqBands.COUNT),
            preset = b.getString(K_PRESET, "Plano"),
            error = b.getString(K_ERR, ""),
        )
    }
}

/**
 * Equalizador gráfico de 15 bandas sobre o DynamicsProcessing do Android,
 * com pré-amplificação e limitador para evitar distorção ao reforçar bandas.
 *
 * Desligado, o efeito é liberado por completo: não fica nenhum processamento
 * no caminho do áudio, o que permite o modo bit-perfect.
 */
class EqController(context: Context) {

    private val prefs = context.getSharedPreferences("equalizador", Context.MODE_PRIVATE)
    private var effect: DynamicsProcessing? = null
    private var sessionId = 0

    var state: EqState = loadState()
        private set

    fun attach(audioSessionId: Int) {
        sessionId = audioSessionId
        apply()
    }

    fun update(newState: EqState) {
        state = newState.copy(error = "")
        saveState()
        apply()
    }

    fun release() {
        effect?.let { runCatching { it.setEnabled(false); it.release() } }
        effect = null
    }

    private fun apply() {
        if (!state.enabled || sessionId == 0) {
            release()
            return
        }
        try {
            val fx = effect ?: create().also { effect = it }
            fx.setInputGainAllChannelsTo(state.preamp)
            for (i in 0 until EqBands.COUNT) {
                fx.setPreEqBandAllChannelsTo(
                    i, DynamicsProcessing.EqBand(true, EqBands.cutoffs[i], state.gains[i])
                )
            }
            fx.setEnabled(true)
        } catch (e: Exception) {
            release()
            state = state.copy(enabled = false, error = "Este aparelho não aceitou o equalizador")
        }
    }

    private fun create(): DynamicsProcessing {
        val config = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            /* channelCount = */ 2,
            /* preEqInUse = */ true, /* preEqBandCount = */ EqBands.COUNT,
            /* mbcInUse = */ false, /* mbcBandCount = */ 0,
            /* postEqInUse = */ false, /* postEqBandCount = */ 0,
            /* limiterInUse = */ true,
        ).setPreferredFrameDuration(10f).build()

        val fx = DynamicsProcessing(0, sessionId, config)
        // Limitador suave em -1 dBFS: segura picos quando há reforço de bandas
        fx.setLimiterAllChannelsTo(
            DynamicsProcessing.Limiter(
                /* inUse = */ true, /* enabled = */ true, /* linkGroup = */ 0,
                /* attackTime = */ 1f, /* releaseTime = */ 60f,
                /* ratio = */ 10f, /* threshold = */ -1f, /* postGain = */ 0f,
            )
        )
        return fx
    }

    private fun loadState(): EqState {
        val gains = FloatArray(EqBands.COUNT) { prefs.getFloat("g$it", 0f) }
        return EqState(
            enabled = prefs.getBoolean("on", false),
            preamp = prefs.getFloat("pre", 0f),
            gains = gains,
            preset = prefs.getString("preset", "Plano") ?: "Plano",
        )
    }

    private fun saveState() {
        prefs.edit().apply {
            putBoolean("on", state.enabled)
            putFloat("pre", state.preamp)
            putString("preset", state.preset)
            state.gains.forEachIndexed { i, g -> putFloat("g$i", g) }
        }.apply()
    }
}
