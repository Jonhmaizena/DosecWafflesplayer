package com.hires.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.BaseColumns
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Track(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val trackNumber: Int,
    val discNumber: Int,
    val mimeType: String,
    val fileName: String,
    val folder: String,
    val sizeBytes: Long,
) {
    /** Rótulo curto do formato do arquivo (FLAC, WAV, MP3…). */
    val formatLabel: String
        get() = when (mimeType.lowercase()) {
            "audio/flac", "audio/x-flac" -> "FLAC"
            "audio/wav", "audio/x-wav", "audio/vnd.wave" -> "WAV"
            "audio/aiff", "audio/x-aiff" -> "AIFF"
            "audio/mpeg", "audio/mp3" -> "MP3"
            "audio/ogg", "application/ogg" -> "OGG"
            "audio/opus" -> "OPUS"
            "audio/mp4", "audio/x-m4a", "audio/m4a", "audio/aac" -> "M4A"
            else -> fileName.substringAfterLast('.', "").uppercase().ifEmpty { "ÁUDIO" }
        }

    val isLossless: Boolean
        get() = formatLabel in setOf("FLAC", "WAV", "AIFF")

    /** [defaultArt] aparece na notificação quando o arquivo não tem capa embutida. */
    fun toMediaItem(defaultArt: Uri? = null): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setRequestMetadata(
            MediaItem.RequestMetadata.Builder().setMediaUri(uri).build()
        )
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setTrackNumber(trackNumber)
                .setArtworkUri(defaultArt)
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .build()
        )
        .build()

    companion object {
        /** Usado quando a fila tem um item que ainda não está na biblioteca carregada. */
        fun fromMediaItem(item: MediaItem): Track {
            val md = item.mediaMetadata
            return Track(
                id = item.mediaId.toLongOrNull() ?: -1L,
                uri = item.localConfiguration?.uri ?: Uri.EMPTY,
                title = md.title?.toString() ?: "Faixa",
                artist = md.artist?.toString() ?: "",
                album = md.albumTitle?.toString() ?: "",
                albumId = -1L,
                durationMs = 0L,
                trackNumber = md.trackNumber ?: 0,
                discNumber = 0,
                mimeType = "",
                fileName = "",
                folder = "",
                sizeBytes = 0L,
            )
        }
    }
}

data class Group(val key: String, val title: String, val subtitle: String, val tracks: List<Track>)

object MusicRepository {

    private val LOSSLESS_MIMES = listOf(
        "audio/flac", "audio/x-flac", "audio/wav", "audio/x-wav", "audio/aiff", "audio/x-aiff"
    )

    fun load(context: Context): List<Track> {
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            BaseColumns._ID,
            MediaStore.MediaColumns.TITLE,
            MediaStore.Audio.AudioColumns.ARTIST,
            MediaStore.Audio.AudioColumns.ALBUM,
            MediaStore.Audio.AudioColumns.ALBUM_ID,
            MediaStore.Audio.AudioColumns.DURATION,
            MediaStore.Audio.AudioColumns.TRACK,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.SIZE,
        )
        val placeholders = LOSSLESS_MIMES.joinToString(",") { "?" }
        val selection = "${MediaStore.Audio.AudioColumns.IS_MUSIC} != 0 OR " +
            "${MediaStore.MediaColumns.MIME_TYPE} IN ($placeholders)"
        val args = LOSSLESS_MIMES.toTypedArray()

        val result = ArrayList<Track>()
        context.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(BaseColumns._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.MediaColumns.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.DURATION)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.TRACK)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iPath = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)

            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val rawTrack = c.getInt(iTrack)
                val name = c.getString(iName) ?: ""
                val artist = c.getString(iArtist)
                result += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    title = c.getString(iTitle)?.takeIf { it.isNotBlank() }
                        ?: name.substringBeforeLast('.'),
                    artist = if (artist.isNullOrBlank() || artist == "<unknown>") "Artista desconhecido" else artist,
                    album = c.getString(iAlbum)?.takeIf { it.isNotBlank() } ?: "Álbum desconhecido",
                    albumId = c.getLong(iAlbumId),
                    durationMs = c.getLong(iDur),
                    trackNumber = rawTrack % 1000,
                    discNumber = rawTrack / 1000,
                    mimeType = c.getString(iMime) ?: "",
                    fileName = name,
                    folder = (c.getString(iPath) ?: "").trimEnd('/').ifEmpty { "Raiz" },
                    sizeBytes = c.getLong(iSize),
                )
            }
        }
        return result.sortedBy { it.title.lowercase() }
    }

    fun albums(tracks: List<Track>): List<Group> =
        tracks.groupBy { it.albumId }.map { (id, list) ->
            val sorted = list.sortedWith(compareBy<Track>({ it.discNumber }, { it.trackNumber }, { it.title }))
            val artists = list.map { it.artist }.distinct()
            Group(
                key = "album:$id",
                title = list.first().album,
                subtitle = if (artists.size == 1) artists.first() else "Vários artistas",
                tracks = sorted,
            )
        }.sortedBy { it.title.lowercase() }

    fun artists(tracks: List<Track>): List<Group> =
        tracks.groupBy { it.artist }.map { (artist, list) ->
            val albums = list.map { it.albumId }.distinct().size
            Group(
                key = "artist:$artist",
                title = artist,
                subtitle = "${plural(albums, "álbum", "álbuns")} · ${plural(list.size, "faixa", "faixas")}",
                tracks = list.sortedWith(compareBy<Track>({ it.album }, { it.discNumber }, { it.trackNumber })),
            )
        }.sortedBy { it.title.lowercase() }

    fun folders(tracks: List<Track>): List<Group> =
        tracks.groupBy { it.folder }.map { (folder, list) ->
            Group(
                key = "folder:$folder",
                title = folder.substringAfterLast('/'),
                subtitle = "$folder · ${plural(list.size, "faixa", "faixas")}",
                tracks = list.sortedBy { it.fileName.lowercase() },
            )
        }.sortedBy { it.subtitle.lowercase() }

    private fun plural(n: Int, one: String, many: String) = "$n ${if (n == 1) one else many}"
}
