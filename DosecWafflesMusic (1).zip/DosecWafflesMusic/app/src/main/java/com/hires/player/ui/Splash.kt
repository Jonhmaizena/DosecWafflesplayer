package com.hires.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.hires.player.R
import kotlinx.coroutines.delay

/**
 * Logo do Maizeninha Audio Player na abertura: 2 s parado + 0,4 s de dissolução.
 * Aparece sempre que o app é aberto; [showToken] muda a cada nova abertura.
 */
@Composable
fun SplashOverlay(showToken: Int) {
    var visible by remember { mutableStateOf(true) }
    LaunchedEffect(showToken) {
        visible = true
        delay(2000)
        visible = false
    }
    AnimatedVisibility(visible = visible, enter = fadeIn(tween(0)), exit = fadeOut(tween(400))) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painterResource(R.drawable.splash_logo),
                contentDescription = "Maizeninha Audio Player",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp)
            )
        }
    }
}
