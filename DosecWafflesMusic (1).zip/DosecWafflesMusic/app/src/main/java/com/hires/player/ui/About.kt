package com.hires.player.ui

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hires.player.R
import com.hires.player.tr
import com.hires.player.trf

/** "Sobre": nome do app, versão instalada e dados do aparelho. */
@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    // Versão lida do próprio APK instalado (sempre a correta)
    val about: Pair<String, Long> = remember {
        try {
            val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            Pair(info.versionName ?: "?", info.longVersionCode)
        } catch (e: Exception) {
            Pair("?", 0L)
        }
    }
    val version = about.first
    val build = about.second
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss, modifier = Modifier.tvFocus()) { Text(tr("Fechar")) } },
        text = {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Image(
                    painterResource(R.drawable.waffle_disc), null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(96.dp)
                )
                Spacer(Modifier.height(4.dp))
                Text("Dosec Waffles Music", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    trf("Versão %1\$s", version),
                    color = Gold,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .background(Gold.copy(alpha = 0.12f), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                )
                Text(
                    trf("Compilação %1\$s", build),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("Player de música em alta definição feito para a Comunidade do DOSEC."),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    trf("Aparelho: %1\$s %2\$s · Android %3\$s", Build.MANUFACTURER.replaceFirstChar { it.uppercase() }, Build.MODEL, Build.VERSION.RELEASE),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                DosecFooter()
            }
        },
    )
}
