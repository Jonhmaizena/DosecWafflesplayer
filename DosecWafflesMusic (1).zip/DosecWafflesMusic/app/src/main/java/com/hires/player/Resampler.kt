package com.hires.player

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Reamostrador sinc com janela de Kaiser (β = 9, ~90 dB de rejeição), 32 cruzamentos
 * de zero de cada lado, em ponto flutuante de 32 bits. É o mesmo tipo de filtro usado
 * por conversores de estúdio, muito mais limpo que o conversor padrão do Android.
 */
class SincResampler(inRate: Int, outRate: Int, private val channels: Int) {

    private val step = inRate.toDouble() / outRate            // amostras de entrada por saída
    private val fc = min(1.0, outRate.toDouble() / inRate) * 0.97 // corte normalizado (Nyquist = 1)
    private val halfWidth = ZERO_CROSSINGS / fc                // meia largura do filtro em amostras de entrada
    private val reach = ceil(halfWidth).toInt()
    val taps: Int get() = reach * 2

    private val table: FloatArray            // kernel amostrado de 0 a halfWidth
    private var history = FloatArray(0)      // amostras intercaladas ainda necessárias
    private var frames = 0                   // quadros válidos em history
    private var t = 0.0                      // posição da próxima saída, em quadros de history

    init {
        val size = (halfWidth * RES).toInt() + 2
        val i0Beta = besselI0(BETA)
        table = FloatArray(size) { i ->
            val x = i.toDouble() / RES
            if (x >= halfWidth) 0f else {
                val r = x / halfWidth
                val window = besselI0(BETA * sqrt(1 - r * r)) / i0Beta
                (fc * sinc(fc * x) * window).toFloat()
            }
        }
        reset()
    }

    fun reset() {
        // Começa com 'reach' quadros de silêncio para o filtro ter passado disponível
        frames = reach
        history = FloatArray(maxOf(4096, reach * 4) * channels)
        t = reach.toDouble()
    }

    /** Recebe quadros intercalados em float e devolve os quadros reamostrados. */
    fun process(input: FloatArray, inFrames: Int, out: FloatOutput) {
        ensureCapacity(frames + inFrames)
        System.arraycopy(input, 0, history, frames * channels, inFrames * channels)
        frames += inFrames

        val acc = DoubleArray(channels)
        while (t + reach < frames) {
            val center = floor(t).toInt()
            java.util.Arrays.fill(acc, 0.0)
            var j = center - reach + 1
            val end = center + reach
            while (j <= end) {
                val w = kernel(abs(j - t))
                if (w != 0f) {
                    val base = j * channels
                    for (c in 0 until channels) acc[c] += history[base + c] * w
                }
                j++
            }
            for (c in 0 until channels) out.put(acc[c].toFloat())
            t += step
        }

        // Descarta o que não será mais usado, mantendo o passado que o filtro precisa
        val keepFrom = (floor(t).toInt() - reach).coerceAtLeast(0)
        if (keepFrom > 0) {
            System.arraycopy(history, keepFrom * channels, history, 0, (frames - keepFrom) * channels)
            frames -= keepFrom
            t -= keepFrom
        }
    }

    private fun kernel(x: Double): Float {
        val pos = x * RES
        val i = pos.toInt()
        if (i >= table.size - 1) return 0f
        val f = (pos - i).toFloat()
        return table[i] + (table[i + 1] - table[i]) * f
    }

    private fun ensureCapacity(neededFrames: Int) {
        if (neededFrames * channels > history.size) {
            history = history.copyOf(maxOf(neededFrames * channels, history.size * 2))
        }
    }

    fun interface FloatOutput { fun put(v: Float) }

    companion object {
        const val ZERO_CROSSINGS = 32
        private const val RES = 1024
        private const val BETA = 9.0

        private fun sinc(x: Double) = if (x == 0.0) 1.0 else sin(PI * x) / (PI * x)

        private fun besselI0(x: Double): Double {
            var sum = 1.0
            var term = 1.0
            val q = x * x / 4
            var k = 1
            while (term > 1e-12 * sum) {
                term *= q / (k.toDouble() * k)
                sum += term
                k++
            }
            return sum
        }
    }
}

/**
 * Saída de áudio que, quando ligada, converte a faixa para a taxa do mixer do Android
 * com o [SincResampler] antes de entregar ao sistema. Assim o Android não precisa
 * reamostrar com o conversor dele. Desligada, repassa o áudio sem tocar em nada.
 */
@OptIn(UnstableApi::class)
class ResamplingAudioSink(sink: AudioSink) : ForwardingAudioSink(sink) {

    @Volatile var enabled = false
    @Volatile var targetRate = 48000

    /** Descrição do que está acontecendo agora, para o painel. */
    @Volatile var status = ""
        private set
    var onStatusChanged: (() -> Unit)? = null

    private var resampler: SincResampler? = null
    private var inEncoding = C.ENCODING_INVALID
    private var inRate = 48000
    private var channels = 2
    private var floatIn = FloatArray(0)
    private var pending: ByteBuffer = ByteBuffer.allocateDirect(0)
    private var pendingTs = 0L
    private var hasPending = false

    override fun configure(inputFormat: Format, specifiedBufferSize: Int, outputChannels: IntArray?) {
        val enc = inputFormat.pcmEncoding
        val supported = inputFormat.sampleMimeType == MimeTypes.AUDIO_RAW && enc in SUPPORTED
        val inRate = inputFormat.sampleRate
        val active = enabled && supported && targetRate > 0 && inRate > 0 && inRate != targetRate

        if (!active) {
            resampler = null
            status = when {
                !enabled -> "Desligado"
                !supported -> "Formato não suportado; tocando sem conversão"
                inRate == targetRate -> "Sem conversão: a faixa já está em ${formatRate(inRate)}"
                else -> "Inativo"
            }
            onStatusChanged?.invoke()
            super.configure(inputFormat, specifiedBufferSize, outputChannels)
            return
        }

        inEncoding = enc
        this.inRate = inRate
        channels = inputFormat.channelCount
        val rs = SincResampler(inRate, targetRate, channels)
        resampler = rs
        status = "Ativo · ${formatRate(inRate)} → ${formatRate(targetRate)} · sinc ${rs.taps} pontos, 32-bit float"
        onStatusChanged?.invoke()

        val outFormat = inputFormat.buildUpon()
            .setSampleRate(targetRate)
            .setPcmEncoding(C.ENCODING_PCM_FLOAT)
            .build()
        super.configure(outFormat, 0, outputChannels)
    }

    override fun handleBuffer(buffer: ByteBuffer, presentationTimeUs: Long, encodedAccessUnitCount: Int): Boolean {
        // Entrega primeiro o que sobrou da última vez, mesmo que a faixa nova não precise de conversão.
        // Nunca deixamos sobra pendente ao responder "true": a saída do Android exige receber
        // o mesmo buffer até o fim, e uma sobra esquecida na troca de faixa travava a reprodução.
        if (hasPending) {
            if (!super.handleBuffer(pending, pendingTs, 1)) return false
            hasPending = false
        }
        val rs = resampler ?: return super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
        if (!buffer.hasRemaining()) return true

        val frames = toFloat(buffer)
        val outCapacity = ((frames.toDouble() * targetRate / inRate) + 64).toInt() * channels * 4
        if (pending.capacity() < outCapacity) {
            pending = ByteBuffer.allocateDirect(outCapacity * 2).order(ByteOrder.nativeOrder())
        }
        pending.clear()
        val out = pending
        rs.process(floatIn, frames) { v ->
            if (out.remaining() < 4) return@process
            out.putFloat(v)
        }
        pending.flip()
        pendingTs = presentationTimeUs
        hasPending = pending.hasRemaining()
        if (hasPending && super.handleBuffer(pending, pendingTs, 1)) hasPending = false
        // Entrada já consumida; se sobrou saída, o player chama de novo e a sobra é entregue acima
        return !hasPending
    }

    /** Converte o buffer de entrada (16/24/32-bit ou float) para float intercalado. */
    private fun toFloat(buffer: ByteBuffer): Int {
        val b = buffer.order(ByteOrder.LITTLE_ENDIAN)
        val bytesPerSample = when (inEncoding) {
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_24BIT -> 3
            else -> 4
        }
        val samples = b.remaining() / bytesPerSample
        if (floatIn.size < samples) floatIn = FloatArray(samples)
        var i = 0
        when (inEncoding) {
            C.ENCODING_PCM_16BIT -> while (i < samples) { floatIn[i++] = b.short / 32768f }
            C.ENCODING_PCM_24BIT -> while (i < samples) {
                val lo = b.get().toInt() and 0xFF
                val mid = b.get().toInt() and 0xFF
                val hi = b.get().toInt()
                floatIn[i++] = ((hi shl 16) or (mid shl 8) or lo) / 8388608f
            }
            C.ENCODING_PCM_32BIT -> while (i < samples) { floatIn[i++] = b.int / 2147483648f }
            else -> while (i < samples) { floatIn[i++] = b.float }
        }
        buffer.position(buffer.limit())
        return samples / channels
    }

    override fun playToEndOfStream() {
        if (hasPending) {
            if (!super.handleBuffer(pending, pendingTs, 1)) return
            hasPending = false
        }
        super.playToEndOfStream()
    }

    override fun isEnded(): Boolean = !hasPending && super.isEnded()

    override fun hasPendingData(): Boolean = hasPending || super.hasPendingData()

    override fun flush() {
        hasPending = false
        resampler?.reset()
        super.flush()
    }

    override fun reset() {
        hasPending = false
        resampler = null
        super.reset()
    }

    companion object {
        private val SUPPORTED = setOf(
            C.ENCODING_PCM_16BIT, C.ENCODING_PCM_24BIT, C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT
        )
    }
}
