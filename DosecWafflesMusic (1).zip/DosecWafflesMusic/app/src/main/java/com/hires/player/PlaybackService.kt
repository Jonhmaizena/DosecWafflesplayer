package com.hires.player

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.MoreExecutors
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

/**
 * Serviço de reprodução.
 *
 * Decodificação: FFmpeg em software (bit-exato para FLAC, ALAC, WAV, AIFF), com o
 * decodificador do Android como reserva. Saída em PCM float de 32 bits, o que preserva
 * arquivos de 24 bits e desliga todos os processadores de áudio do player: sem
 * equalizador, sem normalização, sem pular silêncio e sem mudança de velocidade.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {

    private var session: MediaLibrarySession? = null
    private lateinit var autoLibrary: AutoLibrary
    // Leitura da biblioteca para o Android Auto fora da thread principal
    private val libraryExecutor = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())
    private lateinit var player: ExoPlayer
    private lateinit var bitPerfect: BitPerfectController
    private lateinit var inspector: OutputInspector
    private lateinit var eq: EqController
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    // Arquivo
    private var codec = ""
    private var srcRate = 0
    private var srcBits = 0
    private var channels = 0
    private var bitrateKbps = 0
    // Cadeia de reprodução
    private var decoderName = ""
    private var outEncoding = C.ENCODING_INVALID
    private var outRate = 0
    private var bpStatus = ""
    private lateinit var resamplingSink: ResamplingAudioSink
    private var resamplerOn = false
    private var userBp = false   // o usuário ligou a conexão direta
    private var autoBp = true    // ligar sozinho ao conectar um DAC USB

    override fun onCreate() {
        super.onCreate()

        // Saída com o reamostrador de alta qualidade (ligado ou desligado pelo usuário)
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                val base = DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
                return ResamplingAudioSink(base).also { sink ->
                    sink.onStatusChanged = { main.post { publishExtras() } }
                    resamplingSink = sink
                }
            }
        }
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
            .setEnableAudioFloatOutput(true)

        player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setSkipSilenceEnabled(false)
            .build()
        player.volume = 1f // volume digital do app sempre em 100%: nenhuma redução de bits

        // Sessão de áudio fixa para o equalizador se prender a ela
        val audioSession = getSystemService(AudioManager::class.java).generateAudioSessionId()
        player.setAudioSessionId(audioSession)
        eq = EqController(this)

        bitPerfect = BitPerfectController(this)
        // Bit-perfect só existe com o equalizador totalmente desligado
        userBp = prefs.getBoolean(KEY_BP, false)
        autoBp = prefs.getBoolean(KEY_BP_AUTO, true)
        refreshDirectMode()
        eq.attach(audioSession)
        bpStatus = if (bitPerfect.enabled) "Aguardando a faixa" else "Desligado"
        inspector = OutputInspector(this)

        // Reamostrador e bit-perfect não convivem: o bit-perfect exige a taxa original
        resamplerOn = prefs.getBoolean(KEY_RS, false)
        configureResampler()

        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) = onNewTrackFormat(tracks)

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                outputRetries = 0
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) skippedInARow = 0
            }

            // Um erro numa faixa não pode parar a fila inteira
            override fun onPlayerError(error: PlaybackException) = recoverFrom(error)
        })
        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioDecoderInitialized(
                eventTime: AnalyticsListener.EventTime,
                decoderName: String,
                initializedTimestampMs: Long,
                initializationDurationMs: Long
            ) {
                this@PlaybackService.decoderName = decoderName
                publishExtras()
            }

            override fun onAudioTrackInitialized(
                eventTime: AnalyticsListener.EventTime,
                audioTrackConfig: AudioSink.AudioTrackConfig
            ) {
                outEncoding = audioTrackConfig.encoding
                outRate = audioTrackConfig.sampleRate
                publishExtras()
            }
        })

        getSystemService(AudioManager::class.java).registerAudioDeviceCallback(deviceCallback, main)

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        autoLibrary = AutoLibrary(this)
        session = MediaLibrarySession.Builder(this, player, SessionCallback())
            .setSessionActivity(openApp)
            .build()
        publishExtras()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(deviceCallback)
        bitPerfect.clear()
        eq.release()
        session?.run {
            player.release()
            release()
        }
        session = null
        io.shutdown()
        libraryExecutor.shutdown()
        super.onDestroy()
    }

    // ---- Recuperação de erros ---------------------------------------------------------------

    private var outputRetries = 0
    private var skippedInARow = 0

    /**
     * Se a saída de áudio falhar (troca de DAC, mudança de taxa), tenta de novo na mesma faixa.
     * Se a faixa em si não tocar (arquivo corrompido ou formato não suportado), pula para a próxima.
     */
    private fun recoverFrom(error: PlaybackException) {
        val audioOutput = error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
        if (audioOutput && outputRetries < 3) {
            outputRetries++
            main.postDelayed({ player.prepare(); player.play() }, 300)
            return
        }
        if (player.hasNextMediaItem() && skippedInARow < player.mediaItemCount) {
            skippedInARow++
            main.post {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    // ---- Formato do arquivo atual ------------------------------------------------------

    private fun onNewTrackFormat(tracks: Tracks) {
        val group = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 } ?: return
        val format = group.getTrackFormat(0)
        val mime = format.sampleMimeType
        val rate = format.sampleRate
        val ch = format.channelCount
        val pcmBits = when (format.pcmEncoding) {
            C.ENCODING_PCM_16BIT -> 16
            C.ENCODING_PCM_24BIT -> 24
            C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 32
            else -> 0
        }
        val uri = player.currentMediaItem?.localConfiguration?.uri

        // FLAC/ALAC não trazem a profundidade de bits no formato; lemos do arquivo.
        io.execute {
            val info = readFileInfo(uri)
            main.post {
                codec = codecName(mime)
                srcRate = if (rate > 0) rate else info.rate
                srcBits = if (isLossy(mime)) 0 else if (pcmBits > 0) pcmBits else info.bits
                channels = ch
                bitrateKbps = info.bitrateKbps
                applyBitPerfect(restartIfChanged = false)
            }
        }
    }

    private data class FileInfo(val bits: Int, val rate: Int, val bitrateKbps: Int)

    private fun readFileInfo(uri: Uri?): FileInfo {
        if (uri == null) return FileInfo(0, 0, 0)
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            fun key(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
            FileInfo(
                bits = if (Build.VERSION.SDK_INT >= 31) key(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE) else 0,
                rate = if (Build.VERSION.SDK_INT >= 31) key(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE) else 0,
                bitrateKbps = key(MediaMetadataRetriever.METADATA_KEY_BITRATE) / 1000,
            )
        } catch (e: Exception) {
            FileInfo(0, 0, 0)
        } finally {
            runCatching { r.release() }
        }
    }

    // ---- Bit-perfect e saída ---------------------------------------------------------------

    /**
     * Decide se a conexão direta fica ligada: pelo usuário, ou sozinha quando há um
     * DAC USB conectado e a opção automática está ativa. Nunca com o equalizador ligado.
     */
    private fun refreshDirectMode() {
        bitPerfect.enabled = !eq.state.enabled &&
            (userBp || (autoBp && bitPerfect.usbDacConnected()))
    }

    private fun applyBitPerfect(restartIfChanged: Boolean) {
        refreshDirectMode()
        configureResampler()
        val (status, changed) = bitPerfect.apply(srcRate)
        bpStatus = status
        publishExtras()
        // A nova configuração da saída só vale quando a trilha de áudio é reaberta.
        if (changed && restartIfChanged && player.mediaItemCount > 0) reopenOutput()
    }

    private fun reopenOutput() {
        val index = player.currentMediaItemIndex
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        player.stop()
        player.seekTo(index, pos)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    /** Liga ou desliga o reamostrador e aponta para a taxa atual do mixer do Android. */
    private fun configureResampler() {
        val mixer = getSystemService(AudioManager::class.java)
            .getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        resamplingSink.targetRate = mixer
        resamplingSink.enabled = resamplerOn && !bitPerfect.enabled
    }

    private fun publishExtras() {
        val s = session ?: return
        val out = runCatching { inspector.inspect(srcRate) }.getOrNull()
        val direct = bitPerfect.active

        val path = when {
            out == null -> ""
            direct -> "Direto ao DAC, sem mixer (bit-perfect)"
            bitPerfect.nativeRate ->
                "Mixer do Android na taxa da faixa (${formatRate(srcRate)}), sem reamostragem → DAC USB"
            resamplingSink.status.startsWith("Ativo") && !out.isBluetooth ->
                "Reamostrado pelo app (sinc, alta qualidade) → mixer do Android em ${formatRate(out.mixerRate)} sem nova reamostragem" +
                    if (eq.state.enabled) " · com equalizador" else ""
            eq.state.enabled -> "Mixer do Android com equalizador" +
                if (out.mixerRate > 0) " em ${formatRate(out.mixerRate)}" else ""
            out.isBluetooth -> "Mixer do Android → recomprimido pelo codec Bluetooth"
            out.mixerRate > 0 && srcRate > 0 && out.mixerRate == srcRate ->
                "Mixer do Android em ${formatRate(out.mixerRate)} · sem reamostragem"
            out.mixerRate > 0 && srcRate > 0 ->
                "Mixer do Android · reamostrado de ${formatRate(srcRate)} para ${formatRate(out.mixerRate)}"
            else -> "Mixer do Android"
        }

        val extras = Bundle().apply {
            putString(EX_CODEC, codec)
            putInt(EX_RATE, srcRate)
            putInt(EX_BITS, srcBits)
            putInt(EX_CHANNELS, channels)
            putInt(EX_BITRATE, bitrateKbps)
            putString(EX_DECODER, decoderLabel(decoderName))
            putString(EX_APP_OUT, appOutputLabel())
            putBoolean(EX_BP_ENABLED, bitPerfect.enabled)
            putBoolean(EX_BP_AUTO, autoBp)
            putBoolean(EX_BP_NATIVE, bitPerfect.nativeRate)
            putString(EX_BP_DIAG, bitPerfect.diagnostics)
            putString(EX_BP_STATUS, bpStatus)
            putBoolean(EX_DIRECT, direct)
            putString(EX_PATH, path)
            putString(
                EX_PROCESSING,
                if (eq.state.enabled) "Equalizador 15 bandas · ${eq.state.preset} · limitador"
                else "Nenhum: sem EQ, efeitos, normalização ou ajuste de velocidade"
            )
            eq.state.toBundle(this)
            putBoolean(EX_RS_ON, resamplerOn)
            putBoolean(EX_RS_ACTIVE, resamplingSink.status.startsWith("Ativo"))
            putString(
                EX_RS_STATUS,
                when {
                    !resamplerOn -> "Desligado"
                    bitPerfect.enabled -> "Pausado: conexão direta ao DAC USB em uso"
                    else -> resamplingSink.status.ifEmpty { "Aguardando a faixa" }
                }
            )
            if (out != null) {
                putString(EX_DEV_TYPE, out.deviceType)
                putString(EX_DAC, out.dacName)
                putInt(EX_DEV_MAX_RATE, out.maxRate)
                putInt(EX_DEV_MAX_BITS, out.maxBits)
                putBoolean(EX_LG_QUAD, out.lgQuadDac)
                putBoolean(EX_LG_PHONE, LgQuadDac.chip() != null)
                putString(EX_LG_STATE, out.quadDacState)
                putString(EX_ROM, out.customRom)
                putString(EX_LG_MODE, out.quadDacMode)
                putBoolean(EX_USB, out.isUsb)
                putBoolean(EX_DIRECT_AVAILABLE, out.directAvailable)
            }
        }
        s.setSessionExtras(extras)
    }

    private fun appOutputLabel(): String {
        if (outRate <= 0) return ""
        val enc = when (outEncoding) {
            C.ENCODING_PCM_FLOAT -> "32-bit float"
            C.ENCODING_PCM_32BIT -> "32-bit"
            C.ENCODING_PCM_24BIT -> "24-bit"
            C.ENCODING_PCM_16BIT -> "16-bit"
            else -> "PCM"
        }
        return "$enc · ${formatRate(outRate)}"
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) =
            main.postDelayed({ applyBitPerfect(restartIfChanged = true) }, 300).let { }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) =
            main.postDelayed({ applyBitPerfect(restartIfChanged = false) }, 300).let { }
    }

    // ---- Sessão --------------------------------------------------------------------------

    private inner class SessionCallback : MediaLibrarySession.Callback {

        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SET_BITPERFECT, Bundle.EMPTY))
                .add(SessionCommand(CMD_REFRESH_OUTPUT, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_EQ, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_RESAMPLER, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_BP_AUTO, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CMD_SET_BITPERFECT -> {
                    val on = args.getBoolean(ARG_ENABLED)
                    // Ligar o bit-perfect desliga o equalizador por completo
                    if (on && eq.state.enabled) eq.update(eq.state.copy(enabled = false))
                    if (on && resamplerOn) {
                        resamplerOn = false
                        prefs.edit().putBoolean(KEY_RS, false).apply()
                        configureResampler()
                    }
                    userBp = on
                    // Desligar à mão também desliga o modo automático, senão ele voltaria sozinho
                    if (!on) autoBp = false
                    prefs.edit().putBoolean(KEY_BP, userBp).putBoolean(KEY_BP_AUTO, autoBp).apply()
                    applyBitPerfect(restartIfChanged = true)
                }
                CMD_SET_BP_AUTO -> {
                    autoBp = args.getBoolean(ARG_ENABLED)
                    prefs.edit().putBoolean(KEY_BP_AUTO, autoBp).apply()
                    applyBitPerfect(restartIfChanged = true)
                }
                CMD_REFRESH_OUTPUT -> { configureResampler(); publishExtras() }
                CMD_SET_RESAMPLER -> {
                    val on = args.getBoolean(ARG_ENABLED)
                    resamplerOn = on
                    prefs.edit().putBoolean(KEY_RS, on).apply()
                    if (on && bitPerfect.enabled) {
                        userBp = false
                        autoBp = false
                        prefs.edit().putBoolean(KEY_BP, false).putBoolean(KEY_BP_AUTO, false).apply()
                        applyBitPerfect(restartIfChanged = false)
                    }
                    configureResampler()
                    // A saída precisa ser reaberta para trocar a taxa entregue ao Android
                    if (player.mediaItemCount > 0) reopenOutput()
                    publishExtras()
                }
                CMD_SET_EQ -> {
                    val newState = EqState.fromBundle(args)
                    // Ligar o equalizador desliga o bit-perfect: os dois não convivem
                    val wasDirect = bitPerfect.enabled
                    eq.update(newState)
                    refreshDirectMode()
                    // Ligar o equalizador desliga a conexão direta (e desligá-lo pode religar a automática)
                    if (wasDirect != bitPerfect.enabled) applyBitPerfect(restartIfChanged = true)
                    else publishExtras()
                }
                else -> return super.onCustomCommand(session, controller, customCommand, args)
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        // Itens vindos do app ou do carro chegam sem o endereço do arquivo; reconstruímos aqui.
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> = libraryExecutor.submit<MutableList<MediaItem>> {
            mediaItems.mapNotNull { autoLibrary.resolve(it) }.toMutableList()
        }

        // Tocar a partir do carro: uma faixa vira a lista inteira; um pedido de voz vira uma busca.
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
            libraryExecutor.submit<MediaSession.MediaItemsWithStartPosition> {
                val (items, index) = autoLibrary.resolveForPlayback(mediaItems, startIndex)
                val safeIndex = if (items.isEmpty()) 0 else index.coerceIn(0, items.size - 1)
                MediaSession.MediaItemsWithStartPosition(
                    items,
                    safeIndex,
                    if (index == startIndex) startPositionMs else androidx.media3.common.C.TIME_UNSET
                )
            }

        // ---- Navegação (Android Auto) ----

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(autoLibrary.root(), params))

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
            libraryExecutor.submit<LibraryResult<ImmutableList<MediaItem>>> {
                val all = autoLibrary.children(parentId)
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(ImmutableList.copyOf(all.subList(from, to)), params)
            }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> = libraryExecutor.submit<LibraryResult<MediaItem>> {
            autoLibrary.item(mediaId)?.let { LibraryResult.ofItem(it, null) }
                ?: LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
        }

        override fun onSearch(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<Void>> {
            libraryExecutor.execute {
                val count = autoLibrary.search(query).size
                main.post { session.notifySearchResultChanged(browser, query, count, params) }
            }
            return Futures.immediateFuture(LibraryResult.ofVoid())
        }

        override fun onGetSearchResult(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
            libraryExecutor.submit<LibraryResult<ImmutableList<MediaItem>>> {
                val all = autoLibrary.searchItems(query)
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(ImmutableList.copyOf(all.subList(from, to)), params)
            }
    }

    companion object {
        const val CMD_SET_BITPERFECT = "hires.SET_BITPERFECT"
        const val CMD_REFRESH_OUTPUT = "hires.REFRESH_OUTPUT"
        const val CMD_SET_EQ = "hires.SET_EQ"
        const val CMD_SET_RESAMPLER = "hires.SET_RESAMPLER"
        const val EX_RS_ON = "rs_on"
        const val EX_RS_STATUS = "rs_status"
        const val EX_RS_ACTIVE = "rs_active"
        private const val KEY_RS = "resampler"
        const val EX_PROCESSING = "processing"
        const val ARG_ENABLED = "enabled"

        const val EX_CODEC = "codec"
        const val EX_RATE = "rate"
        const val EX_BITS = "bits"
        const val EX_CHANNELS = "channels"
        const val EX_BITRATE = "bitrate"
        const val EX_DECODER = "decoder"
        const val EX_APP_OUT = "app_out"
        const val EX_BP_ENABLED = "bp_enabled"
        const val EX_BP_STATUS = "bp_status"
        const val EX_DIRECT = "direct"
        const val EX_DIRECT_AVAILABLE = "direct_available"
        const val EX_PATH = "path"
        const val EX_DEV_TYPE = "dev_type"
        const val EX_DAC = "dac"
        const val EX_DEV_MAX_RATE = "dev_max_rate"
        const val EX_DEV_MAX_BITS = "dev_max_bits"
        const val EX_LG_QUAD = "lg_quad"
        const val EX_LG_PHONE = "lg_phone"
        const val EX_LG_STATE = "lg_state"
        const val EX_ROM = "rom"
        const val EX_LG_MODE = "lg_mode"
        const val EX_USB = "usb"
        private const val KEY_BP = "bitperfect"
        private const val KEY_BP_AUTO = "bitperfect_auto"
        const val CMD_SET_BP_AUTO = "hires.SET_BP_AUTO"
        const val EX_BP_AUTO = "bp_auto"
        const val EX_BP_NATIVE = "bp_native"
        const val EX_BP_DIAG = "bp_diag"

        fun codecName(mime: String?): String = when (mime) {
            MimeTypes.AUDIO_FLAC -> "FLAC"
            MimeTypes.AUDIO_ALAC -> "ALAC"
            MimeTypes.AUDIO_RAW -> "PCM"
            MimeTypes.AUDIO_WAV -> "WAV"
            MimeTypes.AUDIO_MPEG -> "MP3"
            MimeTypes.AUDIO_AAC -> "AAC"
            MimeTypes.AUDIO_OPUS -> "Opus"
            MimeTypes.AUDIO_VORBIS -> "Vorbis"
            null -> ""
            else -> mime.substringAfter('/').uppercase()
        }

        fun isLossy(mime: String?) = mime in setOf(
            MimeTypes.AUDIO_MPEG, MimeTypes.AUDIO_AAC, MimeTypes.AUDIO_OPUS, MimeTypes.AUDIO_VORBIS
        )

        fun decoderLabel(name: String): String = when {
            name.isEmpty() -> ""
            name.contains("ffmpeg", ignoreCase = true) -> "FFmpeg (software, bit-exato)"
            else -> "Android MediaCodec ($name)"
        }
    }
}
